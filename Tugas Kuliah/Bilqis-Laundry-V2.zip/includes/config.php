<?php
// =============================================
//  KONFIGURASI DATABASE – Bilqis Laundry
//  Sesuaikan host/user/password jika perlu
// =============================================

define('DB_HOST',     'sql110.infinityfree.com');
define('DB_USER',     'if0_42084984');
define('DB_PASS',     'z9V3yZSknWyb');
define('DB_NAME',     'if0_42084984_db_laundry');
define('DB_CHARSET',  'utf8mb4');

define('SITE_NAME',   'Bilqis Laundry');
define('WA_NUMBER',   '6282131485350');
define('WA_TEXT_DEF', 'Halo%20Bilqis%20Laundry%2C%20saya%20ingin%20bertanya%20tentang%20layanan.');

// =============================================
//  BASE URL – Otomatis menyesuaikan environment
//  Jika deploy ke root domain → BASE_URL = ''
//  Jika deploy ke subfolder  → BASE_URL = '/nama-subfolder'
// =============================================
if (!defined('BASE_URL')) {
    $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    // Cari posisi folder project di path
    if (preg_match('#(/bilqis_laundry)#i', $scriptDir, $m)) {
        define('BASE_URL', $m[1]);
    } else {
        // Deploy ke root domain, atau subfolder lain
        define('BASE_URL', '');
    }
}
