<?php
// =============================================
//  KOMPONEN: HEADER & NAVBAR
//  Panggil: include_once __DIR__ . '/../includes/header.php';
//  Variabel yang harus di-set sebelum include:
//    $pageTitle    – judul halaman
//    $activeNav    – nama nav yang aktif
// =============================================

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/auth.php';

$pageTitle  = $pageTitle  ?? SITE_NAME;
$activeNav  = $activeNav  ?? '';
$_user      = currentUser();
$_loggedIn  = isLoggedIn();
$_role      = currentRole();
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= htmlspecialchars($pageTitle) ?> – <?= SITE_NAME ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css" />
</head>

<body>

  <!-- ── NAVBAR ── -->
  <nav class="navbar navbar-expand-lg">
    <div class="container">
      <a class="navbar-brand" href="<?= BASE_URL ?>/index.php">
        <i class="bi bi-basket2-fill me-1"></i>Bilqis <span>Laundry</span>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navMenu">
        <ul class="navbar-nav ms-auto gap-1 align-items-lg-center">
          <li class="nav-item">
            <a class="nav-link <?= $activeNav === 'beranda'  ? 'active' : '' ?>" href="<?= BASE_URL ?>/index.php">
              <i class="bi bi-house me-1"></i>Beranda
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?= $activeNav === 'tentang'  ? 'active' : '' ?>" href="<?= BASE_URL ?>/pages/tentang.php">
              <i class="bi bi-info-circle me-1"></i>Tentang
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?= $activeNav === 'layanan'  ? 'active' : '' ?>" href="<?= BASE_URL ?>/pages/layanan.php">
              <i class="bi bi-tags me-1"></i>Layanan
            </a>
          <li class="nav-item">
            <a class="nav-link <?= $activeNav === 'daftar-data'   ? 'active' : '' ?>" href="<?= BASE_URL ?>/pages/daftar-data.php">
              <i class="bi bi-cart me-1"></i>Daftar Pesanan
            </a>
          </li>
          </li>
          <li class="nav-item">
            <a class="nav-link <?= $activeNav === 'kontak'   ? 'active' : '' ?>" href="<?= BASE_URL ?>/pages/kontak.php">
              <i class="bi bi-telephone me-1"></i>Kontak
            </a>
          </li>

          <?php if ($_loggedIn): ?>
            <!-- Sudah login: tampilkan dropdown sesuai role -->
            <?php
            $dashUrl = match ($_role) {
              'admin'     => BASE_URL . '/admin/dashboard.php',
              'petugas'   => BASE_URL . '/petugas/dashboard.php',
              'pelanggan' => BASE_URL . '/pelanggan/dashboard.php',
              default     => BASE_URL . '/index.php',
            };
            $roleLabel = match ($_role) {
              'admin'     => 'Admin',
              'petugas'   => 'Petugas',
              'pelanggan' => 'Pelanggan',
              default     => 'User',
            };
            ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle d-flex align-items-center gap-2" href="#" data-bs-toggle="dropdown">
                <span style="width:30px;height:30px;border-radius:50%;background:linear-gradient(135deg,#0ea5e9,#0284c7);display:inline-flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:.8rem;">
                  <?= strtoupper(substr($_user['nama'], 0, 1)) ?>
                </span>
                <span class="d-none d-lg-inline"><?= htmlspecialchars($_user['nama']) ?></span>
              </a>
              <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 rounded-3">
                <li><span class="dropdown-item-text text-muted" style="font-size:.78rem">Role: <strong><?= $roleLabel ?></strong></span></li>
                <li>
                  <hr class="dropdown-divider my-1" />
                </li>
                <li><a class="dropdown-item" href="<?= $dashUrl ?>"><i class="bi bi-grid-1x2 me-2"></i>Dashboard</a></li>
                <?php if ($_role === 'pelanggan'): ?>
                  <li><a class="dropdown-item" href="<?= BASE_URL ?>/pelanggan/pesanan_baru.php"><i class="bi bi-cart-plus me-2"></i>Buat Pesanan</a></li>
                  <li><a class="dropdown-item" href="<?= BASE_URL ?>/pelanggan/profil.php"><i class="bi bi-person-gear me-2"></i>Profil</a></li>
                <?php endif; ?>
                <li>
                  <hr class="dropdown-divider my-1" />
                </li>
                <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>/auth/logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
              </ul>
            </li>
          <?php else: ?>
            <!-- Belum login: tampilkan tombol Login -->
            <li class="nav-item ms-lg-2">
              <a href="<?= BASE_URL ?>/auth/login.php"
                class="btn btn-primary rounded-pill px-3 py-1"
                style="font-size:.875rem;font-weight:600">
                <i class="bi bi-box-arrow-in-right me-1"></i>Login
              </a>
            </li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </nav>