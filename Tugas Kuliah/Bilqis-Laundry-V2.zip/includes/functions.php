<?php
// =============================================
//  HELPER FUNCTIONS – Bilqis Laundry
// =============================================

require_once __DIR__ . '/db.php';

// ── Format Rupiah ─────────────────────────────
function rupiah(int|float $nominal): string {
    return 'Rp ' . number_format($nominal, 0, ',', '.');
}

// ── Sanitize input ────────────────────────────
function clean(string $str): string {
    return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

// ── JSON response (untuk API) ─────────────────
function jsonResponse(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// ── Ambil semua layanan dari tabel `layanan` ──
function getAllLayanan(): array {
    $db = getDB();
    return $db->query("SELECT * FROM layanan ORDER BY id_layanan")->fetchAll();
}

// ── Ambil semua metode pembayaran ─────────────
function getAllMetodePembayaran(): array {
    $db = getDB();
    return $db->query("SELECT * FROM metode_pembayaran ORDER BY id_metode")->fetchAll();
}

// ── Ambil semua pelanggan ─────────────────────
function getAllPelanggan(): array {
    $db = getDB();
    return $db->query("SELECT * FROM pelanggan ORDER BY nama_pelanggan")->fetchAll();
}

// ── Ambil semua petugas ───────────────────────
function getAllPetugas(): array {
    $db = getDB();
    return $db->query("SELECT * FROM petugas ORDER BY nama_petugas")->fetchAll();
}

// ── Ambil semua status pesanan ────────────────
function getAllStatusPesanan(): array {
    $db = getDB();
    return $db->query("SELECT * FROM status_pesanan ORDER BY id_status")->fetchAll();
}

// ── Hitung total pesanan ──────────────────────
function countPesanan(?string $status = null): int {
    $db = getDB();
    if ($status) {
        $stmt = $db->prepare("
            SELECT COUNT(*) FROM pesanan p
            JOIN status_pesanan s ON p.id_status = s.id_status
            WHERE s.nama_status = ?
        ");
        $stmt->execute([$status]);
    } else {
        $stmt = $db->query("SELECT COUNT(*) FROM pesanan");
    }
    return (int) $stmt->fetchColumn();
}
