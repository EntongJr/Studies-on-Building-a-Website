<?php
// =============================================
//  KOMPONEN: FOOTER
// =============================================
?>

<!-- ── FOOTER ── -->
<footer>
  <div class="container">
    <div class="row g-4">
      <div class="col-md-4">
        <div class="footer-brand mb-3"><i class="bi bi-basket2-fill me-1"></i>Bilqis Laundry</div>
        <p style="font-size:.9rem;line-height:1.7;">Laundry terpercaya melayani masyarakat Kecamatan Sidoarjo dengan pelayanan ramah dan hasil terbaik.</p>
      </div>
      <div class="col-md-2 col-6">
        <h5>Menu</h5>
        <a href="<?= BASE_URL ?>/index.php">Beranda</a>
        <a href="<?= BASE_URL ?>/pages/tentang.php">Tentang</a>
        <a href="<?= BASE_URL ?>/pages/layanan.php">Layanan</a>
        <a href="<?= BASE_URL ?>/pages/kontak.php">Kontak</a>
      </div>
      <div class="col-md-2 col-6">
        <h5>Layanan</h5>
        <a href="<?= BASE_URL ?>/pages/layanan.php">Cuci Basah</a>
        <a href="<?= BASE_URL ?>/pages/layanan.php">Cuci Kering</a>
        <a href="<?= BASE_URL ?>/pages/layanan.php">Cuci Setrika</a>
        <a href="<?= BASE_URL ?>/pages/layanan.php">Setrika</a>
      </div>
      <div class="col-md-4">
        <h5>Kontak</h5>
        <p style="font-size:.9rem;"><i class="bi bi-geo-alt-fill me-2" style="color:var(--sky)"></i>Jl. Diponegoro No. 12, Sidoarjo</p>
        <p style="font-size:.9rem;"><i class="bi bi-whatsapp me-2" style="color:#25D366"></i>0812-3456-7890</p>
        <p style="font-size:.9rem;"><i class="bi bi-clock-fill me-2" style="color:var(--sky)"></i>Senin – Minggu, 07.00–21.00</p>
      </div>
    </div>
    <hr class="footer-divider"/>
    <p class="footer-copy text-center">© <?= date('Y') ?> Bilqis Laundry. Dibuat dengan ❤️ untuk pelanggan setia kami.</p>
  </div>
</footer>

<!-- ── WA FLOAT ── -->
<a href="https://wa.me/<?= WA_NUMBER ?>?text=<?= WA_TEXT_DEF ?>" class="wa-float" target="_blank" title="Chat WhatsApp">
  <i class="bi bi-whatsapp"></i>
</a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
