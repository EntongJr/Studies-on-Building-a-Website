<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/pelanggan_only.php';
require_once __DIR__ . '/../includes/functions.php';

$db   = getDB();
$user = currentUser();
$activeNav = 'dashboard';

// Data pelanggan ini
$pelanggan = $db->prepare("SELECT * FROM pelanggan WHERE id_pelanggan=?");
$pelanggan->execute([$user['id']]);
$profil = $pelanggan->fetch();

// Pesanan pelanggan
$pesanan = $db->prepare("
    SELECT p.*, sp.nama_status
    FROM pesanan p
    JOIN status_pesanan sp ON p.id_status=sp.id_status
    WHERE p.id_pelanggan=?
    ORDER BY p.tanggal_pesanan DESC
    LIMIT 5
");
$pesanan->execute([$user['id']]);
$pesananList = $pesanan->fetchAll();

$totalPesanan = $db->prepare("SELECT COUNT(*) FROM pesanan WHERE id_pelanggan=?");
$totalPesanan->execute([$user['id']]);
$jumlahPesanan = $totalPesanan->fetchColumn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Dashboard – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <i class="bi bi-basket2-fill icon"></i>
    <div>Bilqis Laundry<br><small style="font-size:.7rem;font-weight:400;opacity:.7">Dashboard Pelanggan</small></div>
  </div>
  <nav class="sidebar-nav">
    <a href="<?= BASE_URL ?>/pelanggan/dashboard.php" class="active"><i class="bi bi-grid-1x2"></i> Dashboard</a>
    <a href="<?= BASE_URL ?>/pelanggan/pesanan_baru.php"><i class="bi bi-cart-plus"></i> Buat Pesanan</a>
    <a href="<?= BASE_URL ?>/pelanggan/riwayat.php"><i class="bi bi-clock-history"></i> Riwayat Pesanan</a>
    <a href="<?= BASE_URL ?>/pelanggan/pembayaran.php"><i class="bi bi-cash"></i> Pembayaran</a>
    <a href="<?= BASE_URL ?>/pelanggan/keluhan.php"><i class="bi bi-chat-dots"></i> Keluhan</a>
    <a href="<?= BASE_URL ?>/pelanggan/profil.php"><i class="bi bi-person-gear"></i> Profil</a>
  </nav>
  <div class="sidebar-footer">
    <a href="<?= BASE_URL ?>/auth/logout.php"><i class="bi bi-box-arrow-left"></i> Logout</a>
  </div>
</div>

<div class="topbar">
  <button class="btn btn-sm btn-light menu-toggle" id="menuToggle"><i class="bi bi-list fs-5"></i></button>
  <div class="d-flex align-items-center gap-2">
    <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,#0ea5e9,#0284c7);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:600;">
      <?= strtoupper(substr($user['nama'],0,1)) ?>
    </div>
    <div style="font-size:.85rem">
      <div class="fw-600"><?= htmlspecialchars($user['nama']) ?></div>
      <div class="text-muted" style="font-size:.75rem">Pelanggan</div>
    </div>
  </div>
</div>

<div class="main-content"><div class="page-content">
  <h5 class="fw-700 mb-1">Halo, <?= htmlspecialchars($profil['nama_pelanggan']??$user['nama']) ?>! 👋</h5>
  <p class="text-muted mb-4" style="font-size:.85rem">Selamat datang di dashboard laundry Anda.</p>

  <div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
      <div class="stat-card text-center">
        <div class="stat-icon mx-auto mb-2" style="background:#e0f2fe;color:#0ea5e9"><i class="bi bi-bag-check"></i></div>
        <div class="stat-val"><?= $jumlahPesanan ?></div>
        <div class="stat-lbl">Total Pesanan</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="stat-card text-center">
        <a href="<?= BASE_URL ?>/pelanggan/pesanan_baru.php" class="btn btn-primary rounded-pill w-100 mt-2">
          <i class="bi bi-plus-lg me-1"></i>Buat Pesanan
        </a>
      </div>
    </div>
  </div>

  <!-- Pesanan Terbaru -->
  <div class="card"><div class="card-header d-flex justify-content-between align-items-center">
    <h6 class="mb-0 fw-600">Pesanan Terbaru</h6>
    <a href="<?= BASE_URL ?>/pelanggan/riwayat.php" class="btn btn-sm btn-outline-primary rounded-pill">Lihat Semua</a>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover mb-0">
        <thead class="table-light">
          <tr><th>ID Pesanan</th><th>Status</th><th>Berat</th><th>Total</th><th>Tanggal</th></tr>
        </thead>
        <tbody>
          <?php foreach ($pesananList as $p):
            $s = $p['nama_status'];
            $b = match(true) {
              str_contains($s,'Selesai')||str_contains($s,'Diambil') => 'success',
              str_contains($s,'Diproses')||str_contains($s,'Dicuci') => 'primary',
              str_contains($s,'Menunggu') => 'warning', default => 'secondary'
            };
          ?>
          <tr>
            <td><code><?= htmlspecialchars($p['id_pesanan']) ?></code></td>
            <td><span class="badge bg-<?= $b ?>"><?= htmlspecialchars($s) ?></span></td>
            <td><?= $p['berat_cucian']??'-' ?> kg</td>
            <td><?= $p['total_harga'] ? rupiah((float)$p['total_harga']) : '-' ?></td>
            <td><?= date('d M Y', strtotime($p['tanggal_pesanan'])) ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($pesananList)): ?>
          <tr><td colspan="5" class="text-center text-muted py-4">Belum ada pesanan. <a href="<?= BASE_URL ?>/pelanggan/pesanan_baru.php">Buat pesanan pertama!</a></td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div></div>
</div></div>

<a href="https://wa.me/<?= WA_NUMBER ?>?text=<?= WA_TEXT_DEF ?>" class="wa-float" target="_blank" title="Chat WhatsApp">
  <i class="bi bi-whatsapp"></i>
</a>
<?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
</body></html>
