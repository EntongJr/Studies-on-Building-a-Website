<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/pelanggan_only.php';
require_once __DIR__ . '/../includes/functions.php';

$db   = getDB();
$user = currentUser();
$msg  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $last = $db->query("SELECT id_keluhan FROM keluhan ORDER BY id_keluhan DESC LIMIT 1")->fetchColumn();
  $num  = $last ? (int)substr($last, 3) + 1 : 1;
  $idKeluhan = 'KLH' . str_pad($num, 3, '0', STR_PAD_LEFT);

  $db->prepare("INSERT INTO keluhan (id_keluhan,id_pesanan,isi_keluhan,tanggal_keluhan,status_keluhan) VALUES (?,?,?,NOW(),'baru')")
    ->execute([$idKeluhan, $_POST['id_pesanan'], $_POST['isi_keluhan']]);
  $msg = 'success|Keluhan berhasil dikirim. Tim kami akan segera merespons.';
}

// Pesanan milik pelanggan ini
$pesanan = $db->prepare("SELECT id_pesanan, tanggal_pesanan FROM pesanan WHERE id_pelanggan=? ORDER BY tanggal_pesanan DESC");
$pesanan->execute([$user['id']]);
$pesananList = $pesanan->fetchAll();

// Riwayat keluhan
$keluhan = $db->prepare("
    SELECT k.*, p.tanggal_pesanan
    FROM keluhan k
    JOIN pesanan p ON k.id_pesanan=p.id_pesanan
    WHERE p.id_pelanggan=?
    ORDER BY k.tanggal_keluhan DESC
");
$keluhan->execute([$user['id']]);
$keluhanList = $keluhan->fetchAll();

[$msgType, $msgText] = $msg ? explode('|', $msg, 2) : ['', ''];
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Keluhan – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
</head>

<body>
  <div class="sidebar" id="sidebar">
    <div class="sidebar-brand"><i class="bi bi-basket2-fill icon"></i>
      <div>Bilqis Laundry</div>
    </div>
    <nav class="sidebar-nav">
      <a href="<?= BASE_URL ?>/pelanggan/dashboard.php"><i class="bi bi-grid-1x2"></i> Dashboard</a>
      <a href="<?= BASE_URL ?>/pelanggan/pesanan_baru.php"><i class="bi bi-cart-plus"></i> Buat Pesanan</a>
      <a href="<?= BASE_URL ?>/pelanggan/riwayat.php"><i class="bi bi-clock-history"></i> Riwayat</a>
      <a href="<?= BASE_URL ?>/pelanggan/pembayaran.php"><i class="bi bi-cash"></i> Pembayaran</a>
      <a href="<?= BASE_URL ?>/pelanggan/keluhan.php" class="active"><i class="bi bi-chat-dots"></i> Keluhan</a>
      <a href="<?= BASE_URL ?>/pelanggan/profil.php"><i class="bi bi-person-gear"></i> Profil</a>
    </nav>
    <div class="sidebar-footer"><a href="<?= BASE_URL ?>/auth/logout.php"><i class="bi bi-box-arrow-left"></i> Logout</a></div>
  </div>
  <div class="topbar">
    <button class="btn btn-sm btn-light menu-toggle" id="menuToggle"><i class="bi bi-list fs-5"></i></button>
    <span class="fw-600">Keluhan</span>
  </div>

  <div class="main-content">
    <div class="page-content">
      <h5 class="fw-700 mb-4">Kirim Keluhan</h5>

      <?php if ($msgText): ?>
        <div class="alert alert-<?= $msgType === 'success' ? 'success' : 'danger' ?> alert-dismissible rounded-3">
          <?= htmlspecialchars($msgText) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>

      <div class="row g-4">
        <div class="col-lg-5">
          <div class="card">
            <div class="card-body">
              <h6 class="fw-600 mb-3">Form Keluhan Baru</h6>
              <?php if (empty($pesananList)): ?>
                <p class="text-muted">Anda belum memiliki pesanan. <a href="<?= BASE_URL ?>/pelanggan/pesanan_baru.php">Buat pesanan dulu.</a></p>
              <?php else: ?>
                <form method="POST">
                  <div class="mb-3">
                    <label class="form-label">Pilih Pesanan <span class="text-danger">*</span></label>
                    <select name="id_pesanan" class="form-select" required>
                      <option value="">-- Pilih Pesanan --</option>
                      <?php foreach ($pesananList as $p): ?>
                        <option value="<?= $p['id_pesanan'] ?>">
                          <?= htmlspecialchars($p['id_pesanan']) ?> – <?= date('d M Y', strtotime($p['tanggal_pesanan'])) ?>
                        </option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Isi Keluhan <span class="text-danger">*</span></label>
                    <textarea name="isi_keluhan" class="form-control" rows="5" placeholder="Ceritakan masalah Anda..." required minlength="10"></textarea>
                  </div>
                  <button type="submit" class="btn btn-primary w-100 rounded-pill">
                    <i class="bi bi-send me-1"></i>Kirim Keluhan
                  </button>
                </form>
              <?php endif; ?>
            </div>
          </div>
        </div>

        <div class="col-lg-7">
          <div class="card">
            <div class="card-header">
              <h6 class="mb-0 fw-600">Riwayat Keluhan</h6>
            </div>
            <div class="card-body p-0">
              <?php if (empty($keluhanList)): ?>
                <p class="text-center text-muted py-4">Belum ada keluhan.</p>
              <?php else: ?>
                <div class="list-group list-group-flush">
                  <?php foreach ($keluhanList as $k):
                    $st = strtolower($k['status_keluhan']);
                    $badge = $st === 'selesai' ? 'success' : ($st === 'diproses' ? 'primary' : 'warning');
                  ?>
                    <div class="list-group-item px-3 py-3">
                      <div class="d-flex justify-content-between align-items-start mb-1">
                        <code class="text-muted" style="font-size:.8rem"><?= htmlspecialchars($k['id_pesanan']) ?></code>
                        <span class="badge bg-<?= $badge ?>"><?= htmlspecialchars($k['status_keluhan']) ?></span>
                      </div>
                      <p class="mb-1" style="font-size:.88rem"><?= htmlspecialchars($k['isi_keluhan']) ?></p>
                      <small class="text-muted"><i class="bi bi-clock me-1"></i><?= date('d M Y H:i', strtotime($k['tanggal_keluhan'])) ?></small>
                    </div>
                  <?php endforeach; ?>
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<a href="https://wa.me/<?= WA_NUMBER ?>?text=<?= WA_TEXT_DEF ?>" class="wa-float" target="_blank" title="Chat WhatsApp">
  <i class="bi bi-whatsapp"></i>
</a>
  <?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
</body>

</html>