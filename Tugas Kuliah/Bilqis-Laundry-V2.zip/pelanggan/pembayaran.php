<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/pelanggan_only.php';
require_once __DIR__ . '/../includes/functions.php';

$db   = getDB();
$user = currentUser();

$pembayaran = $db->prepare("
    SELECT py.*, mp.nama_metode, p.total_harga, p.status_pembayaran
    FROM pembayaran py
    JOIN pesanan p ON py.id_pesanan = p.id_pesanan
    JOIN metode_pembayaran mp ON py.id_metode = mp.id_metode
    WHERE p.id_pelanggan = ?
    ORDER BY py.tanggal_bayar DESC
");
$pembayaran->execute([$user['id']]);
$rows = $pembayaran->fetchAll();

$totalBayar = array_sum(array_column($rows, 'jumlah_bayar'));
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Pembayaran – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
</head>

<body>
  <div class="sidebar" id="sidebar">
    <div class="sidebar-brand"><i class="bi bi-basket2-fill icon"></i>
      <div>Bilqis Laundry</div>
    </div>
    <nav class="sidebar-nav">
      <a href="<?= BASE_URL ?>/pelanggan/dashboard.php"><i class="bi bi-grid-1x2"></i> Dashboard</a>
      <a href="<?= BASE_URL ?>/pelanggan/pesanan_baru.php"><i class="bi bi-cart-plus"></i> Buat Pesanan</a>
      <a href="<?= BASE_URL ?>/pelanggan/riwayat.php"><i class="bi bi-clock-history"></i> Riwayat</a>
      <a href="<?= BASE_URL ?>/pelanggan/pembayaran.php" class="active"><i class="bi bi-cash"></i> Pembayaran</a>
      <a href="<?= BASE_URL ?>/pelanggan/keluhan.php"><i class="bi bi-chat-dots"></i> Keluhan</a>
      <a href="<?= BASE_URL ?>/pelanggan/profil.php"><i class="bi bi-person-gear"></i> Profil</a>
    </nav>
    <div class="sidebar-footer"><a href="<?= BASE_URL ?>/auth/logout.php"><i class="bi bi-box-arrow-left"></i> Logout</a></div>
  </div>
  <div class="topbar">
    <button class="btn btn-sm btn-light menu-toggle" id="menuToggle"><i class="bi bi-list fs-5"></i></button>
    <span class="fw-600">Pembayaran</span>
  </div>

  ```php
  <div class="main-content">
    <div class="page-content">

      <h4 class="fw-700 mb-4">
        <i class="bi bi-credit-card-2-front me-2"></i>
        Langkah-Langkah Pembayaran
      </h4>

      <div class="alert alert-warning rounded-4 border-0 shadow-sm mb-4">
        <strong>⚠️ Catatan Penting:</strong><br>
        Pakaian tidak dapat diambil atau diantar sebelum pembayaran dikonfirmasi oleh sistem atau kasir kami.
        Jika menggunakan transfer atau e-wallet Pastikan Status Pesanan Sudah Selesai Baru Melunasi Pembayaran dan mohon sertakan nomor pesanan Anda saat melakukan pembayaran.
      </div>

      <!-- CASH -->
      <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body p-4">

          <h5 class="fw-bold mb-3 text-success">
            💵 Tunai (Cash)
          </h5>

          <p class="text-muted">
            Metode ini berlaku jika Anda mengambil langsung ke outlet atau menggunakan layanan antar-jemput.
          </p>

          <ol class="ps-3">
            <li>Siapkan uang pas sesuai total pembayaran.</li>
            <li>Serahkan pembayaran kepada kasir atau kurir kami.</li>
            <li>Pastikan Anda menerima nota pembayaran resmi.</li>
          </ol>

        </div>
      </div>

      <!-- TRANSFER -->
      <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body p-4">

          <h5 class="fw-bold mb-3 text-primary">
            🏦 Transfer Bank
          </h5>

          <div class="bg-light rounded-4 p-3 mb-3">
            <div><strong>Bank:</strong> BCA</div>
            <div><strong>No Rekening:</strong> 1402-9832-7564</div>
            <div><strong>Atas Nama:</strong> Bilqis Laundry</div>
          </div>

          <ol class="ps-3">
            <li>Buka aplikasi Mobile Banking atau ATM.</li>
            <li>Pilih menu Transfer.</li>
            <li>Masukkan nomor rekening tujuan.</li>
            <li>Masukkan nominal pembayaran sesuai tagihan.</li>
            <li>Simpan bukti transfer.</li>
            <li>Kirim bukti pembayaran ke admin WhatsApp.</li>
          </ol>

        </div>
      </div>

      <!-- QRIS -->
      <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body p-4">

          <h5 class="fw-bold mb-3 text-dark">
            📱 Pembayaran QRIS
          </h5>

          <p class="text-muted">
            Mendukung semua aplikasi pembayaran digital seperti Gopay, Dana, OVO, ShopeePay, dan Mobile Banking.
          </p>

          <ol class="ps-3">
            <li>Scan kode QRIS yang tersedia.</li>
            <li>Buka aplikasi pembayaran Anda.</li>
            <li>Pilih menu Scan atau Bayar.</li>
            <li>Masukkan nominal pembayaran.</li>
            <li>Konfirmasi pembayaran menggunakan PIN.</li>
            <li>Simpan bukti transaksi.</li>
          </ol>

        </div>
      </div>

      <!-- DANA -->
      <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body p-4">

          <h5 class="fw-bold mb-3" style="color:#0ea5e9">
            🦌 DANA
          </h5>

          <div class="bg-light rounded-4 p-3 mb-3">
            <div><strong>Nomor DANA:</strong> 0821-3148-5350</div>
            <div><strong>Atas Nama:</strong> Bilqis Laundry</div>
          </div>

          <ol class="ps-3">
            <li>Buka aplikasi DANA.</li>
            <li>Pilih menu Kirim.</li>
            <li>Masukkan nomor tujuan.</li>
            <li>Masukkan nominal pembayaran.</li>
            <li>Konfirmasi pembayaran menggunakan PIN.</li>
            <li>Kirim bukti pembayaran ke admin.</li>
          </ol>

        </div>
      </div>

      <!-- OVO -->
      <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body p-4">

          <h5 class="fw-bold mb-3" style="color:#7c3aed">
            🟣 OVO
          </h5>

          <div class="bg-light rounded-4 p-3 mb-3">
            <div><strong>Nomor OVO:</strong> 0821-3148-5350</div>
            <div><strong>Atas Nama:</strong> Bilqis Laundry</div>
          </div>

          <ol class="ps-3">
            <li>Buka aplikasi OVO.</li>
            <li>Pilih menu Transfer.</li>
            <li>Pilih transfer ke sesama OVO.</li>
            <li>Masukkan nomor tujuan.</li>
            <li>Masukkan nominal pembayaran.</li>
            <li>Konfirmasi menggunakan PIN OVO.</li>
            <li>Kirim bukti pembayaran ke admin.</li>
          </ol>

        </div>
      </div>

    </div>
  </div>
  ```

<a href="https://wa.me/<?= WA_NUMBER ?>?text=<?= WA_TEXT_DEF ?>" class="wa-float" target="_blank" title="Chat WhatsApp">
  <i class="bi bi-whatsapp"></i>
</a>
  <?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
</body>

</html>