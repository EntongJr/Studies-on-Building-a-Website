<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/pelanggan_only.php';
require_once __DIR__ . '/../includes/functions.php';

$db   = getDB();
$user = currentUser();
$msg  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Generate ID Pesanan
  $last      = $db->query("SELECT id_pesanan FROM pesanan ORDER BY id_pesanan DESC LIMIT 1")->fetchColumn();
  $num       = $last ? (int)substr($last, 3) + 1 : 1;
  $idPesanan = 'PSN' . str_pad($num, 3, '0', STR_PAD_LEFT);

  $idLayanan = $_POST['id_layanan'];
  $berat     = (float)$_POST['berat_cucian'];
  $catatan   = $_POST['catatan'] ?? '';
  $idPromo   = $_POST['id_promo'] ?: null;

  // Ambil data layanan
  $stmtLyr = $db->prepare("SELECT * FROM layanan WHERE id_layanan = ?");
  $stmtLyr->execute([$idLayanan]);
  $lyr = $stmtLyr->fetch();

  $hargaPerKg   = (float)($lyr['harga_perkg']   ?? 0);
  $beratMinimum = (float)($lyr['berat_minimum']  ?? 1);

  // Logika berat: jika berat < berat_minimum, tetap dihitung pakai berat_minimum
  $kelipatan     = ceil($berat / $beratMinimum);
  $total         = $kelipatan * $hargaPerKg;

  // Diskon promo
  if ($idPromo) {
    $stmtPromo = $db->prepare("SELECT * FROM promo WHERE id_promo=? AND tanggal_mulai<=CURDATE() AND tanggal_selesai>=CURDATE()");
    $stmtPromo->execute([$idPromo]);
    $promo = $stmtPromo->fetch();
    if ($promo) $total = $total * (1 - (float)$promo['diskon'] / 100);
  }

  // Status awal: Menunggu
  $status = $db->query("SELECT id_status FROM status_pesanan WHERE nama_status='Menunggu' LIMIT 1")->fetchColumn();
  if (!$status) $status = $db->query("SELECT id_status FROM status_pesanan LIMIT 1")->fetchColumn();

  // Ambil petugas pertama
  $idPetugas = $db->query("SELECT id_petugas FROM petugas LIMIT 1")->fetchColumn();

  // Insert pesanan
  $db->prepare("
        INSERT INTO pesanan
            (id_pesanan, id_pelanggan, id_petugas, id_status, id_promo, tanggal_pesanan, berat_cucian, total_harga, status_pembayaran, catatan)
        VALUES (?,?,?,?,?,NOW(),?,?,'Belum Lunas',?)
    ")->execute([$idPesanan, $user['id'], $idPetugas, $status, $idPromo, $berat, $total, $catatan]);

  // Insert pembayaran
  $idMetode   = $_POST['id_metode'];
  $lastBayar  = $db->query("SELECT id_pembayaran FROM pembayaran ORDER BY id_pembayaran DESC LIMIT 1")->fetchColumn();
  $numBayar   = $lastBayar ? (int)substr($lastBayar, 3) + 1 : 1;
  $idBayar    = 'PAY' . str_pad($numBayar, 3, '0', STR_PAD_LEFT);

  $db->prepare("INSERT INTO pembayaran (id_pembayaran, id_pesanan, id_metode, tanggal_bayar, jumlah_bayar) VALUES (?,?,?,NOW(),?)")
    ->execute([$idBayar, $idPesanan, $idMetode, $total]);

  // Generate ID Detail
  $lastDetail = $db->query("SELECT id_detail FROM detail_pesanan ORDER BY id_detail DESC LIMIT 1")->fetchColumn();
  $numDetail  = $lastDetail ? (int)substr($lastDetail, 3) + 1 : 1;
  $idDetail   = 'DTL' . str_pad($numDetail, 3, '0', STR_PAD_LEFT);

  // Insert detail pesanan
  $db->prepare("INSERT INTO detail_pesanan (id_detail, id_pesanan, id_layanan, subtotal) VALUES (?,?,?,?)")
    ->execute([$idDetail, $idPesanan, $idLayanan, $total]);

  $msg = "success|Pesanan <strong>$idPesanan</strong> berhasil dibuat! Total: " . rupiah($total);
}

$layananList = $db->query("SELECT * FROM layanan ORDER BY nama_layanan")->fetchAll();
$promoAktif  = $db->query("SELECT * FROM promo WHERE tanggal_mulai<=CURDATE() AND tanggal_selesai>=CURDATE()")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Buat Pesanan – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
</head>

<body>

  <div class="sidebar" id="sidebar">
    <div class="sidebar-brand"><i class="bi bi-basket2-fill icon"></i>
      <div>Bilqis Laundry</div>
    </div>
    <nav class="sidebar-nav">
      <a href="<?= BASE_URL ?>/pelanggan/dashboard.php"><i class="bi bi-grid-1x2"></i> Dashboard</a>
      <a href="<?= BASE_URL ?>/pelanggan/pesanan_baru.php" class="active"><i class="bi bi-cart-plus"></i> Buat Pesanan</a>
      <a href="<?= BASE_URL ?>/pelanggan/riwayat.php"><i class="bi bi-clock-history"></i> Riwayat</a>
      <a href="<?= BASE_URL ?>/pelanggan/pembayaran.php"><i class="bi bi-cash"></i> Pembayaran</a>
      <a href="<?= BASE_URL ?>/pelanggan/keluhan.php"><i class="bi bi-chat-dots"></i> Keluhan</a>
      <a href="<?= BASE_URL ?>/pelanggan/profil.php"><i class="bi bi-person-gear"></i> Profil</a>
    </nav>
    <div class="sidebar-footer"><a href="<?= BASE_URL ?>/auth/logout.php"><i class="bi bi-box-arrow-left"></i> Logout</a></div>
  </div>

  <div class="topbar">
    <button class="btn btn-sm btn-light menu-toggle" id="menuToggle"><i class="bi bi-list fs-5"></i></button>
    <span class="fw-600" style="font-size:.9rem">Buat Pesanan Baru</span>
  </div>

  <div class="main-content">
    <div class="page-content">
      <h5 class="fw-700 mb-4">Buat Pesanan Laundry</h5>

      <?php if ($msg): [$t, $m] = explode('|', $msg, 2); ?>
        <div class="alert alert-<?= $t === 'success' ? 'success' : 'danger' ?> alert-dismissible rounded-3">
          <?= $m ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>

      <div class="card" style="max-width:600px">
        <div class="card-body">
          <form method="POST">

            <!-- PILIH LAYANAN -->
            <div class="mb-4">
              <label class="form-label fw-600">Pilih Layanan <span class="text-danger">*</span></label>
              <div class="row g-2">
                <?php foreach ($layananList as $l): ?>
                  <div class="col-12">
                    <label class="d-flex align-items-center gap-3 p-3 border rounded-3"
                      style="cursor:pointer"
                      onclick="setLayanan('<?= $l['id_layanan'] ?>',<?= (float)$l['harga_perkg'] ?>,<?= (float)($l['berat_minimum'] ?? 1) ?>)">
                      <input type="radio" name="id_layanan" value="<?= $l['id_layanan'] ?>"
                        class="form-check-input mt-0 flex-shrink-0" required />
                      <div class="flex-grow-1">
                        <div class="fw-600"><?= htmlspecialchars($l['nama_layanan']) ?></div>
                        <div class="text-muted" style="font-size:.8rem">
                          <?= htmlspecialchars($l['deskripsi'] ?? '') ?>
                          <?php if (!empty($l['berat_minimum'])): ?>
                            <span class="badge bg-info text-dark ms-1">Min. <?= $l['berat_minimum'] ?> kg</span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <div class="text-primary fw-600"><?= rupiah((float)$l['harga_perkg']) ?>/kg</div>
                    </label>
                  </div>
                <?php endforeach; ?>
              </div>
            </div>

            <!-- BERAT -->
            <div class="mb-3">
              <label class="form-label fw-600">Berat Cucian (kg) <span class="text-danger">*</span></label>
              <input type="number" name="berat_cucian" id="berat" class="form-control"
                step="0.1" min="0.1" oninput="hitungTotal()" required />
              <div class="form-text" id="infoMinBerat"></div>
            </div>

            <!-- PROMO -->
            <?php if (!empty($promoAktif)): ?>
              <div class="mb-3">
                <label class="form-label">Promo (opsional)</label>
                <select name="id_promo" class="form-select" onchange="hitungTotal()">
                  <option value="">-- Tanpa Promo --</option>
                  <?php foreach ($promoAktif as $p): ?>
                    <option value="<?= $p['id_promo'] ?>" data-diskon="<?= $p['diskon'] ?>">
                      <?= htmlspecialchars($p['nama_promo']) ?> – Diskon <?= $p['diskon'] ?>%
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
            <?php endif; ?>

            <!-- METODE PEMBAYARAN -->
            <div class="mb-3">
              <label class="form-label fw-600">Metode Pembayaran <span class="text-danger">*</span></label>
              <select name="id_metode" class="form-select" required>
                <option value="">-- Pilih Metode Pembayaran --</option>
                <?php
                $metodeList = $db->query("SELECT * FROM metode_pembayaran ORDER BY nama_metode")->fetchAll();
                foreach ($metodeList as $m):
                ?>
                  <option value="<?= $m['id_metode'] ?>"><?= htmlspecialchars($m['nama_metode']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <!-- CATATAN -->
            <div class="mb-3">
              <label class="form-label">Catatan</label>
              <textarea name="catatan" class="form-control" rows="2" placeholder="Catatan khusus (opsional)"></textarea>
            </div>

            <!-- ESTIMASI HARGA -->
            <div class="p-3 rounded-3 mb-4" style="background:#f0f9ff;border:1.5px solid #bae6fd">
              <div class="d-flex justify-content-between mb-1">
                <span class="text-muted" style="font-size:.85rem">Berat dihitung</span>
                <span class="fw-600" id="previewBerat">0 kg</span>
              </div>
              <div class="d-flex justify-content-between mb-1">
                <span class="text-muted" style="font-size:.85rem">Harga per kg</span>
                <span class="fw-600" id="previewHarga">Rp 0</span>
              </div>
              <hr class="my-2" />
              <div class="d-flex justify-content-between">
                <span class="fw-600">Estimasi Total</span>
                <span class="fw-700 text-primary fs-5" id="previewTotal">Rp 0</span>
              </div>
              <div id="infoDiskon" class="text-success" style="font-size:.8rem;text-align:right;display:none"></div>
            </div>

            <button type="submit" class="btn btn-primary w-100 rounded-pill py-2 fw-600">
              <i class="bi bi-cart-check me-1"></i>Buat Pesanan
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>

<a href="https://wa.me/<?= WA_NUMBER ?>?text=<?= WA_TEXT_DEF ?>" class="wa-float" target="_blank" title="Chat WhatsApp">
  <i class="bi bi-whatsapp"></i>
</a>
  <?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
  <script>
    let hargaPerKg = 0;
    let beratMinimum = 1;

    function setLayanan(id, harga, minBerat) {
      hargaPerKg = harga;
      beratMinimum = minBerat;
      document.getElementById('infoMinBerat').textContent =
        minBerat > 1 ? `⚠️ Minimum berat layanan ini ${minBerat} kg. Kurang dari itu tetap dihitung ${minBerat} kg.` : '';
      hitungTotal();
    }

    function hitungTotal() {
      const berat = parseFloat(document.getElementById('berat').value) || 0;

      // Logika kelipatan berat minimum
      const kelipatan = berat > 0 ? Math.ceil(berat / beratMinimum) : 0;
      const subtotal = kelipatan * hargaPerKg;

      // Diskon promo
      const promo = document.querySelector('select[name=id_promo]');
      let diskon = 0;
      if (promo) {
        const opt = promo.options[promo.selectedIndex];
        diskon = parseFloat(opt.dataset.diskon || 0);
      }

      const total = subtotal * (1 - diskon / 100);

      document.getElementById('previewBerat').textContent =
        berat > 0 ? `${berat} kg (×${kelipatan} kelipatan)` : '0 kg';

      document.getElementById('previewHarga').textContent =
        'Rp ' + hargaPerKg.toLocaleString('id');

      document.getElementById('previewTotal').textContent =
        'Rp ' + total.toLocaleString('id');

      const infoDiskon = document.getElementById('infoDiskon');
      if (diskon > 0) {
        infoDiskon.style.display = 'block';
        infoDiskon.textContent = `Diskon ${diskon}% sudah diterapkan`;
      } else {
        infoDiskon.style.display = 'none';
      }
    }
  </script>
</body>

</html>