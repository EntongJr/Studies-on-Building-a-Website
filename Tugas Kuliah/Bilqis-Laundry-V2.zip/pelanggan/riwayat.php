<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/pelanggan_only.php';
require_once __DIR__ . '/../includes/functions.php';

$db   = getDB();
$user = currentUser();

$pesanan = $db->prepare("
    SELECT p.*, sp.nama_status,
           GROUP_CONCAT(l.nama_layanan SEPARATOR ', ') AS layanan_list
    FROM pesanan p
    JOIN status_pesanan sp ON p.id_status = sp.id_status
    LEFT JOIN detail_pesanan dp ON p.id_pesanan = dp.id_pesanan
    LEFT JOIN layanan l ON dp.id_layanan = l.id_layanan
    WHERE p.id_pelanggan = ?
    GROUP BY p.id_pesanan
    ORDER BY p.tanggal_pesanan DESC
");
$pesanan->execute([$user['id']]);
$rows = $pesanan->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Riwayat Pesanan – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
</head>

<body>
  <div class="sidebar" id="sidebar">
    <div class="sidebar-brand"><i class="bi bi-basket2-fill icon"></i>
      <div>Bilqis Laundry</div>
    </div>
    <nav class="sidebar-nav">
      <a href="<?= BASE_URL ?>/pelanggan/dashboard.php"><i class="bi bi-grid-1x2"></i> Dashboard</a>
      <a href="<?= BASE_URL ?>/pelanggan/pesanan_baru.php"><i class="bi bi-cart-plus"></i> Buat Pesanan</a>
      <a href="<?= BASE_URL ?>/pelanggan/riwayat.php" class="active"><i class="bi bi-clock-history"></i> Riwayat</a>
      <a href="<?= BASE_URL ?>/pelanggan/pembayaran.php"><i class="bi bi-cash"></i> Pembayaran</a>
      <a href="<?= BASE_URL ?>/pelanggan/keluhan.php"><i class="bi bi-chat-dots"></i> Keluhan</a>
      <a href="<?= BASE_URL ?>/pelanggan/profil.php"><i class="bi bi-person-gear"></i> Profil</a>
    </nav>
    <div class="sidebar-footer"><a href="<?= BASE_URL ?>/auth/logout.php"><i class="bi bi-box-arrow-left"></i> Logout</a></div>
  </div>
  <div class="topbar">
    <button class="btn btn-sm btn-light menu-toggle" id="menuToggle"><i class="bi bi-list fs-5"></i></button>
    <span class="fw-600">Riwayat Pesanan</span>
  </div>

  <div class="main-content">
    <div class="page-content">
      <h5 class="fw-700 mb-4">Riwayat Pesanan</h5>

      <div class="card">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table dt-table">
              <thead class="table-light">
                <tr>
                  <th>#</th>
                  <th>ID Pesanan</th>
                  <th>Layanan</th>
                  <th>Status</th>
                  <th>Berat</th>
                  <th>Total</th>
                  <th>Pembayaran</th>
                  <th>Tanggal</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($rows as $i => $p):
                  $s = $p['nama_status'];
                  $b = match (true) {
                    str_contains($s, 'Selesai') || str_contains($s, 'Diambil') => 'success',
                    str_contains($s, 'Diproses') || str_contains($s, 'Dicuci') || str_contains($s, 'Setrika') => 'primary',
                    str_contains($s, 'Menunggu') => 'warning',
                    default => 'secondary'
                  };
                ?>
                  <tr>
                    <td><?= $i + 1 ?></td>
                    <td><code><?= htmlspecialchars($p['id_pesanan']) ?></code></td>
                    <td><?= htmlspecialchars($p['layanan_list'] ?? '-') ?></td>
                    <td><span class="badge bg-<?= $b ?>"><?= htmlspecialchars($s) ?></span></td>
                    <td><?= $p['berat_cucian'] ?? '-' ?> kg</td>
                    <td><?= $p['total_harga'] ? rupiah((float)$p['total_harga']) : '-' ?></td>
                    <td>
                      <?php $bayar = $p['status_pembayaran'] ?? 'Belum Lunas'; ?>
                      <span class="badge bg-<?= $bayar === 'Lunas' ? 'success' : 'danger' ?>"><?= htmlspecialchars($bayar) ?></span>
                    </td>
                    <td><?= date('d M Y', strtotime($p['tanggal_pesanan'])) ?></td>
                  </tr>
                <?php endforeach; ?>
                <?php if (empty($rows)): ?>
                  <tr>
                    <td colspan="8" class="text-center text-muted py-4">Belum ada pesanan.</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

<a href="https://wa.me/<?= WA_NUMBER ?>?text=<?= WA_TEXT_DEF ?>" class="wa-float" target="_blank" title="Chat WhatsApp">
  <i class="bi bi-whatsapp"></i>
</a>    
  <?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
</body>

</html>