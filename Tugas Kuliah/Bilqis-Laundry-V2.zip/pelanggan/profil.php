<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/pelanggan_only.php';
require_once __DIR__ . '/../includes/functions.php';

$db   = getDB();
$user = currentUser();
$msg  = '';

$stmt = $db->prepare("SELECT * FROM pelanggan WHERE id_pelanggan=?");
$stmt->execute([$user['id']]);
$profil = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profil') {
        $db->prepare("UPDATE pelanggan SET nama_pelanggan=?,no_telepon=?,alamat=? WHERE id_pelanggan=?")
           ->execute([$_POST['nama_pelanggan'],$_POST['no_telepon'],$_POST['alamat'],$user['id']]);
        // Update session nama
        $_SESSION['user_nama'] = $_POST['nama_pelanggan'];
        $msg = 'success|Profil berhasil diperbarui.';
    }

    if ($action === 'ganti_password') {
        $lama = $_POST['sandi_lama'] ?? '';
        $baru = $_POST['sandi_baru'] ?? '';
        $konfirm = $_POST['sandi_konfirm'] ?? '';

        if (!password_verify($lama, $profil['sandi'])) {
            $msg = 'error|Password lama tidak sesuai.';
        } elseif (strlen($baru) < 6) {
            $msg = 'error|Password baru minimal 6 karakter.';
        } elseif ($baru !== $konfirm) {
            $msg = 'error|Konfirmasi password tidak cocok.';
        } else {
            $db->prepare("UPDATE pelanggan SET sandi=? WHERE id_pelanggan=?")
               ->execute([password_hash($baru,PASSWORD_DEFAULT),$user['id']]);
            $msg = 'success|Password berhasil diubah.';
        }
    }

    // Refresh profil data
    $stmt->execute([$user['id']]);
    $profil = $stmt->fetch();
}

[$msgType,$msgText] = $msg ? explode('|',$msg,2) : ['',''];
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Profil – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
</head>
<body>
<div class="sidebar" id="sidebar">
  <div class="sidebar-brand"><i class="bi bi-basket2-fill icon"></i><div>Bilqis Laundry</div></div>
  <nav class="sidebar-nav">
    <a href="<?= BASE_URL ?>/pelanggan/dashboard.php"><i class="bi bi-grid-1x2"></i> Dashboard</a>
    <a href="<?= BASE_URL ?>/pelanggan/pesanan_baru.php"><i class="bi bi-cart-plus"></i> Buat Pesanan</a>
    <a href="<?= BASE_URL ?>/pelanggan/riwayat.php"><i class="bi bi-clock-history"></i> Riwayat</a>
    <a href="<?= BASE_URL ?>/pelanggan/pembayaran.php"><i class="bi bi-cash"></i> Pembayaran</a>
    <a href="<?= BASE_URL ?>/pelanggan/keluhan.php"><i class="bi bi-chat-dots"></i> Keluhan</a>
    <a href="<?= BASE_URL ?>/pelanggan/profil.php" class="active"><i class="bi bi-person-gear"></i> Profil</a>
  </nav>
  <div class="sidebar-footer"><a href="<?= BASE_URL ?>/auth/logout.php"><i class="bi bi-box-arrow-left"></i> Logout</a></div>
</div>
<div class="topbar">
  <button class="btn btn-sm btn-light menu-toggle" id="menuToggle"><i class="bi bi-list fs-5"></i></button>
  <span class="fw-600">Profil Saya</span>
</div>

<div class="main-content"><div class="page-content">
  <h5 class="fw-700 mb-4">Edit Profil</h5>

  <?php if ($msgText): ?>
    <div class="alert alert-<?= $msgType==='success'?'success':'danger' ?> alert-dismissible rounded-3">
      <?= htmlspecialchars($msgText) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <div class="row g-4">
    <!-- Update Profil -->
    <div class="col-lg-6">
      <div class="card"><div class="card-body">
        <h6 class="fw-600 mb-3"><i class="bi bi-person me-2 text-primary"></i>Data Pribadi</h6>
        <form method="POST">
          <input type="hidden" name="action" value="update_profil"/>
          <div class="mb-3">
            <label class="form-label">Nama Lengkap</label>
            <input type="text" name="nama_pelanggan" class="form-control" value="<?= htmlspecialchars($profil['nama_pelanggan']) ?>" required/>
          </div>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" value="<?= htmlspecialchars($profil['email']) ?>" disabled/>
            <small class="text-muted">Email tidak bisa diubah.</small>
          </div>
          <div class="mb-3">
            <label class="form-label">No. Telepon</label>
            <input type="text" name="no_telepon" class="form-control" value="<?= htmlspecialchars($profil['no_telepon']??'') ?>"/>
          </div>
          <div class="mb-4">
            <label class="form-label">Alamat</label>
            <textarea name="alamat" class="form-control" rows="3"><?= htmlspecialchars($profil['alamat']??'') ?></textarea>
          </div>
          <button type="submit" class="btn btn-primary rounded-pill px-4">
            <i class="bi bi-save me-1"></i>Simpan Perubahan
          </button>
        </form>
      </div></div>
    </div>

    <!-- Ganti Password -->
    <div class="col-lg-6">
      <div class="card"><div class="card-body">
        <h6 class="fw-600 mb-3"><i class="bi bi-shield-lock me-2 text-warning"></i>Ganti Password</h6>
        <form method="POST">
          <input type="hidden" name="action" value="ganti_password"/>
          <div class="mb-3">
            <label class="form-label">Password Lama</label>
            <input type="password" name="sandi_lama" class="form-control" required/>
          </div>
          <div class="mb-3">
            <label class="form-label">Password Baru</label>
            <input type="password" name="sandi_baru" class="form-control" minlength="6" required/>
          </div>
          <div class="mb-4">
            <label class="form-label">Konfirmasi Password Baru</label>
            <input type="password" name="sandi_konfirm" class="form-control" required/>
          </div>
          <button type="submit" class="btn btn-warning rounded-pill px-4">
            <i class="bi bi-key me-1"></i>Ganti Password
          </button>
        </form>
      </div></div>
    </div>
  </div>
</div></div>

<a href="https://wa.me/<?= WA_NUMBER ?>?text=<?= WA_TEXT_DEF ?>" class="wa-float" target="_blank" title="Chat WhatsApp">
  <i class="bi bi-whatsapp"></i>
</a>    
<?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
</body></html>
