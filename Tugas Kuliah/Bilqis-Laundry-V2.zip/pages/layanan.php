<?php
// =============================================
//  HALAMAN: LAYANAN
// =============================================

require_once __DIR__ . '/../includes/functions.php';

$pageTitle = 'Layanan';
$activeNav = 'layanan';

try {
  $db = getDB();
  $layananList = $db->query("SELECT * FROM layanan ORDER BY id_layanan")->fetchAll();
} catch (Exception $e) {
  $layananList = [];
}

// Ikon default per layanan (fallback)
$ikonMap = [
  'cuci basah'          => 'bi-droplet-fill',
  'cuci kering'         => 'bi-wind',
  'cuci setrika'        => 'bi-thermometer-half',
  'setrika'             => 'bi-layers-fill',
  'cuci lipat'          => 'bi-stack',
];
function getIkon(string $nama): string
{
  $lower = strtolower($nama);
  foreach ($GLOBALS['ikonMap'] as $key => $icon) {
    if (str_contains($lower, $key)) return $icon;
  }
  return 'bi-basket2-fill';
}

include __DIR__ . '/../includes/header.php';
?>

<!-- PAGE HEADER -->
<section class="page-header">
  <div class="container">
    <div class="section-tag">Layanan Kami</div>
    <h1>Paket Harga Laundry</h1>
    <p>Pilih paket yang sesuai kebutuhan Anda. Semua layanan dikerjakan dengan profesional dan penuh tanggung jawab.</p>
  </div>
</section>

<!-- LAYANAN SECTION -->
<section style="padding:80px 0;background:var(--white);">
  <div class="container">
    <div class="row g-4">
      <?php if (!empty($layananList)): ?>
        <?php foreach ($layananList as $lay): ?>
          <div class="col-md-6 col-lg-4">
            <div class="feature-card text-center">
              <div class="feature-icon mx-auto" style="width:70px;height:70px;font-size:2rem;">
                <i class="bi <?= getIkon($lay['nama_layanan']) ?>"></i>
              </div>
              <h4 style="font-weight:800;font-size:1.1rem;margin:16px 0 8px;"><?= clean($lay['nama_layanan']) ?></h4>
              <div style="font-size:1.8rem;font-weight:800;color:var(--sky-dark);margin:12px 0 4px;">
                Rp <?= number_format((float)($lay['harga_perkg'] ?? 0), 0, ',', '.') ?>
              </div>
              <div style="font-size:.83rem;color:var(--text-muted);margin-bottom:12px;">per kilogram</div>
              <?php if (!empty($lay['deskripsi'])): ?>
                <p style="font-size:.88rem;color:var(--text-muted);"><?= clean($lay['deskripsi']) ?></p>
              <?php endif; ?>
              <div style="background:var(--sky-pale);border-radius:12px;padding:8px 16px;font-size:.83rem;font-weight:600;color:var(--sky-dark);display:inline-block;">
                Minimum <?= $lay['berat_minimum'] ?> kg
              </div>
              <div class="mt-3">
                <a href="<?= isLoggedIn() ? BASE_URL . '/pelanggan/pesanan_baru.php' : BASE_URL . '/auth/login.php' ?>" class="btn-primary-sky" style="font-size:.88rem;padding:10px 24px;">
                  <i class="bi bi-cart-plus"></i> Pesan
                </a>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <!-- Fallback statis jika DB belum berisi data -->
        <?php
        $staticLayanan = [
          ['nama' => 'Cuci Basah',         'harga' => 5000, 'min' => 8, 'ikon' => 'bi-droplet-fill',      'desc' => 'Cuci bersih tanpa pengeringan. Cocok untuk pakaian sehari-hari.'],
          ['nama' => 'Cuci Kering',        'harga' => 7000, 'min' => 8, 'ikon' => 'bi-wind',              'desc' => 'Cuci dan keringkan sempurna. Siap pakai lebih cepat.'],
          ['nama' => 'Cuci Lipat Wangi',   'harga' => 6000, 'min' => 3, 'ikon' => 'bi-stack',             'desc' => 'Cuci, keringkan, dan lipat rapi dengan pewangi pilihan.'],
          ['nama' => 'Cuci Setrika Wangi', 'harga' => 8000, 'min' => 3, 'ikon' => 'bi-thermometer-half',  'desc' => 'Layanan lengkap: cuci, keringkan, setrika, dan wangi.'],
          ['nama' => 'Setrika Wangi',      'harga' => 6000, 'min' => 3, 'ikon' => 'bi-layers-fill',       'desc' => 'Khusus setrika pakaian yang sudah dicuci sendiri.'],
        ];
        foreach ($staticLayanan as $lay):
        ?>
          <div class="col-md-6 col-lg-4">
            <div class="feature-card text-center">
              <div class="feature-icon mx-auto" style="width:70px;height:70px;font-size:2rem;">
                <i class="bi <?= $lay['ikon'] ?>"></i>
              </div>
              <h4 style="font-weight:800;font-size:1.1rem;margin:16px 0 8px;"><?= $lay['nama'] ?></h4>
              <div style="font-size:1.8rem;font-weight:800;color:var(--sky-dark);margin:12px 0 4px;">
                Rp <?= number_format($lay['harga'], 0, ',', '.') ?>
              </div>
              <div style="font-size:.83rem;color:var(--text-muted);margin-bottom:12px;">per kilogram</div>
              <p style="font-size:.88rem;color:var(--text-muted);"><?= $lay['desc'] ?></p>
              <div style="background:var(--sky-pale);border-radius:12px;padding:8px 16px;font-size:.83rem;font-weight:600;color:var(--sky-dark);display:inline-block;">
                Minimum <?= $lay['min'] ?> kg
              </div>
              <div class="mt-3">
                <a href="<?= BASE_URL ?>/pages/pesanan.php" class="btn-primary-sky" style="font-size:.88rem;padding:10px 24px;">
                  <i class="bi bi-cart-plus"></i> Pesan
                </a>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <!-- CATATAN HARGA -->
    <div class="mt-5 p-4" style="background:var(--sky-pale);border-radius:20px;border:1.5px solid rgba(135,206,235,.3);">
      <h5 style="font-weight:800;color:var(--text-dark);margin-bottom:14px;"><i class="bi bi-info-circle-fill me-2" style="color:var(--sky-dark)"></i>Catatan Harga</h5>
      <ul style="font-size:.9rem;color:var(--text-muted);line-height:2;margin:0;padding-left:20px;">
        <li>Harga di atas adalah harga per kilogram (kg) untuk masing-masing jenis layanan.</li>
        <li>Jika berat pakaian kurang dari minimum, tetap dihitung sesuai berat minimum.</li>
        <li>Estimasi waktu pengerjaan bisa berubah tergantung antrean dan volume pesanan.</li>
        <li>Untuk kebutuhan express, silakan hubungi kami via WhatsApp.</li>
        <li>Harga dapat berubah sewaktu-waktu. Konfirmasi harga terkini via WhatsApp.</li>
      </ul>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>