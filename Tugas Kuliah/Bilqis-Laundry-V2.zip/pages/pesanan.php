<?php
// =============================================
//  HALAMAN: BUAT PESANAN
// =============================================

require_once __DIR__ . '/../includes/functions.php';

$pageTitle = 'Buat Pesanan';
$activeNav = 'pesanan';

// Ambil daftar layanan dari DB
try {
    $db = getDB();
    $layananList = $db->query("SELECT id_layanan, nama_layanan, harga, berat_minimum FROM layanan ORDER BY id_layanan")->fetchAll();
} catch (Exception $e) {
    $layananList = [];
}

include __DIR__ . '/../includes/header.php';
?>

<!-- PAGE HEADER -->
<section class="page-header">
  <div class="container">
    <div class="section-tag">Buat Pesanan</div>
    <h1>Form Pesanan Laundry</h1>
    <p>Isi data di bawah ini untuk membuat pesanan laundry Anda. Proses cepat &amp; mudah!</p>
  </div>
</section>

<!-- FORM SECTION -->
<section class="form-section">
  <div class="container">
    <div class="row g-4 justify-content-center">

      <!-- FORM -->
      <div class="col-lg-7">
        <div class="form-card">
          <div class="form-section-title"><i class="bi bi-cart-plus me-2" style="color:var(--sky-dark)"></i>Detail Pesanan</div>
          <div class="form-section-sub">Pastikan semua data terisi dengan benar.</div>

          <div class="mb-4">
            <label class="form-label">Nama Pelanggan <span class="req">*</span></label>
            <div class="input-group">
              <span class="input-group-text"><i class="bi bi-person-fill"></i></span>
              <input type="text" class="form-control" id="namaPelanggan" placeholder="Contoh: Siti Rahmawati" required/>
            </div>
          </div>

          <div class="mb-4">
            <label class="form-label">No. WhatsApp <span class="req">*</span></label>
            <div class="input-group">
              <span class="input-group-text"><i class="bi bi-whatsapp"></i></span>
              <input type="tel" class="form-control" id="noWhatsapp" placeholder="Contoh: 08123456789" required/>
            </div>
            <div class="form-text" style="font-size:.8rem;color:var(--text-muted);margin-top:6px;">
              <i class="bi bi-info-circle me-1"></i>Kami akan menghubungi Anda via WhatsApp untuk konfirmasi.
            </div>
          </div>

          <div class="mb-4">
            <label class="form-label">Jenis Layanan <span class="req">*</span></label>
            <select class="form-select" id="jenisLayanan" onchange="updatePreview()">
              <option value="" disabled selected>-- Pilih Jenis Layanan --</option>
              <?php foreach ($layananList as $lay): ?>
                <option value="<?= $lay['id_layanan'] ?>"
                        data-nama="<?= clean($lay['nama_layanan']) ?>"
                        data-harga="<?= $lay['harga'] ?>"
                        data-min="<?= $lay['berat_minimum'] ?>">
                  <?= clean($lay['nama_layanan']) ?> (Min. <?= $lay['berat_minimum'] ?> kg) – Rp <?= number_format($lay['harga'],0,',','.') ?>/kg
                </option>
              <?php endforeach; ?>
              <?php if (empty($layananList)): ?>
                <option value="1" data-nama="Cuci Basah"         data-harga="5000" data-min="8">Cuci Basah (Min. 8 kg) – Rp 5.000/kg</option>
                <option value="2" data-nama="Cuci Kering"        data-harga="7000" data-min="8">Cuci Kering (Min. 8 kg) – Rp 7.000/kg</option>
                <option value="3" data-nama="Cuci Lipat Rapi Wangi" data-harga="6000" data-min="3">Cuci Lipat Rapi Wangi (Min. 3 kg) – Rp 6.000/kg</option>
                <option value="4" data-nama="Cuci Setrika Wangi" data-harga="8000" data-min="3">Cuci Setrika Wangi (Min. 3 kg) – Rp 8.000/kg</option>
                <option value="5" data-nama="Setrika Wangi"      data-harga="6000" data-min="3">Setrika Wangi (Min. 3 kg) – Rp 6.000/kg</option>
              <?php endif; ?>
            </select>
          </div>

          <div class="mb-4">
            <label class="form-label">Berat Pakaian (kg) <span class="req">*</span></label>
            <div class="input-group">
              <span class="input-group-text"><i class="bi bi-box-seam-fill"></i></span>
              <input type="number" class="form-control" id="beratKg" placeholder="Masukkan berat dalam kg" min="0.5" step="0.5" oninput="updatePreview()"/>
            </div>
          </div>

          <!-- PRICE PREVIEW -->
          <div class="price-preview" id="pricePreview">
            <div class="label">Estimasi Total Biaya</div>
            <div class="value" id="previewTotal">Rp 0</div>
            <div class="calc-detail" id="previewDetail"></div>
          </div>

          <div class="mt-4">
            <button class="btn-submit" id="btnSimpan" onclick="simpanPesanan()">
              <i class="bi bi-save2-fill"></i> Simpan Pesanan
            </button>
          </div>

          <div class="mt-3 text-center">
            <a href="<?= BASE_URL ?>/pages/daftar-data.php" style="font-size:.88rem;color:var(--sky-dark);font-weight:600;text-decoration:none;">
              <i class="bi bi-table me-1"></i>Lihat semua data pesanan →
            </a>
          </div>
        </div>
      </div>

      <!-- SIDE INFO -->
      <div class="col-lg-5">
        <div class="info-card">
          <h5><i class="bi bi-info-circle-fill me-2" style="color:var(--sky-dark)"></i>Informasi Layanan</h5>
          <div class="info-item">
            <i class="bi bi-clock-fill"></i>
            <div class="info-text"><strong>Jam Operasional</strong><span>Senin – Minggu, 07.00 – 21.00 WIB</span></div>
          </div>
          <div class="info-item">
            <i class="bi bi-truck"></i>
            <div class="info-text"><strong>Antar Jemput</strong><span>Tersedia untuk area Kecamatan Sidoarjo</span></div>
          </div>
          <div class="info-item">
            <i class="bi bi-lightning-charge-fill"></i>
            <div class="info-text"><strong>Proses Cepat</strong><span>Selesai dalam 24–48 jam kerja</span></div>
          </div>
          <div class="info-item mb-0">
            <i class="bi bi-shield-check-fill"></i>
            <div class="info-text"><strong>Garansi Kepuasan</strong><span>Komplain ditangani segera dan profesional</span></div>
          </div>
        </div>

        <div class="info-card">
          <h5><i class="bi bi-tags-fill me-2" style="color:var(--sky-dark)"></i>Daftar Harga Cepat</h5>
          <table class="table table-sm mb-0" style="font-size:.87rem;">
            <tbody>
              <?php foreach ($layananList as $lay): ?>
              <tr>
                <td><?= clean($lay['nama_layanan']) ?> (<?= $lay['berat_minimum'] ?> kg)</td>
                <td class="text-end fw-bold" style="color:var(--sky-dark)">Rp <?= number_format($lay['harga'],0,',','.') ?>/kg</td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($layananList)): ?>
              <tr><td>Cuci Basah (8 kg)</td><td class="text-end fw-bold" style="color:var(--sky-dark)">Rp 5.000/kg</td></tr>
              <tr><td>Cuci Kering (8 kg)</td><td class="text-end fw-bold" style="color:var(--sky-dark)">Rp 7.000/kg</td></tr>
              <tr><td>Cuci Setrika Wangi (3 kg)</td><td class="text-end fw-bold" style="color:var(--sky-dark)">Rp 8.000/kg</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- TOAST -->
<div class="toast-container" id="toastContainer"></div>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<script>
// ── Kalkulasi harga ───────────────────────────
function updatePreview() {
  const sel    = document.getElementById('jenisLayanan');
  const opt    = sel.options[sel.selectedIndex];
  const berat  = parseFloat(document.getElementById('beratKg').value) || 0;
  const preview = document.getElementById('pricePreview');

  if (!sel.value || berat <= 0) { preview.classList.remove('show'); return; }

  const harga = parseFloat(opt.dataset.harga);
  const min   = parseFloat(opt.dataset.min);
  const beratFinal = Math.max(berat, min);
  const total = beratFinal * harga;

  document.getElementById('previewTotal').textContent  = 'Rp ' + total.toLocaleString('id-ID');
  document.getElementById('previewDetail').innerHTML =
    `${beratFinal} kg × Rp ${harga.toLocaleString('id-ID')}/kg` +
    (berat < min ? ` <em>(berat minimum ${min} kg berlaku)</em>` : '');

  preview.classList.add('show');
}

// ── Simpan pesanan via API ────────────────────
async function simpanPesanan() {
  const nama    = document.getElementById('namaPelanggan').value.trim();
  const wa      = document.getElementById('noWhatsapp').value.trim();
  const sel     = document.getElementById('jenisLayanan');
  const layanan = sel.value;
  const berat   = parseFloat(document.getElementById('beratKg').value);

  if (!nama)    { showToast('error','Oops!','Nama pelanggan wajib diisi.'); return; }
  if (!wa)      { showToast('error','Oops!','No. WhatsApp wajib diisi.'); return; }
  if (!layanan) { showToast('error','Oops!','Silakan pilih jenis layanan.'); return; }
  if (!berat || berat <= 0) { showToast('error','Oops!','Berat pakaian harus diisi dengan benar.'); return; }

  const btn = document.getElementById('btnSimpan');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Menyimpan...';

  try {
    const res = await fetch(BASE_URL . '/api/simpan_pesanan.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nama_pelanggan: nama, no_wa: wa, id_layanan: parseInt(layanan), berat_kg: berat })
    });
    const data = await res.json();

    if (data.status === 'success') {
      showToast('success', 'Pesanan Tersimpan!', data.message);
      // Reset form
      document.getElementById('namaPelanggan').value = '';
      document.getElementById('noWhatsapp').value    = '';
      document.getElementById('jenisLayanan').value  = '';
      document.getElementById('beratKg').value       = '';
      document.getElementById('pricePreview').classList.remove('show');
    } else {
      showToast('error', 'Gagal!', data.message);
    }
  } catch (e) {
    showToast('error', 'Error!', 'Tidak dapat terhubung ke server.');
  }

  btn.disabled = false;
  btn.innerHTML = '<i class="bi bi-save2-fill"></i> Simpan Pesanan';
}

// ── Toast notification ────────────────────────
function showToast(type, title, message) {
  const cont  = document.getElementById('toastContainer');
  const icon  = type === 'success' ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill';
  const color = type === 'success' ? 'var(--sky-dark)' : '#e53e3e';
  const el = document.createElement('div');
  el.className = 'custom-toast';
  el.innerHTML = `
    <i class="bi ${icon} toast-icon" style="color:${color}"></i>
    <div class="toast-text"><strong>${title}</strong><span>${message}</span></div>
    <button onclick="this.parentElement.remove()" style="margin-left:auto;background:none;border:none;font-size:1.1rem;cursor:pointer;color:#999">×</button>
  `;
  cont.appendChild(el);
  setTimeout(() => { if (el.parentElement) el.remove(); }, 4000);
}
</script>
