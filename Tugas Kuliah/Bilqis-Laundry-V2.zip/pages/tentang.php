<?php
// =============================================
//  HALAMAN: TENTANG
// =============================================

require_once __DIR__ . '/../includes/functions.php';

$pageTitle = 'Tentang Kami';
$activeNav = 'tentang';

include __DIR__ . '/../includes/header.php';
?>

<!-- PAGE HEADER -->
<section class="page-header">
  <div class="container">
    <div class="section-tag">Tentang Kami</div>
    <h1>Kenali Bilqis Laundry</h1>
    <p>Laundry terpercaya yang melayani masyarakat Kecamatan Sidoarjo sejak 2022.</p>
  </div>
</section>

<!-- TENTANG SECTION -->
<section style="padding:80px 0;background:var(--white);">
  <div class="container">
    <div class="row align-items-center g-5">
      <div class="col-lg-6">
        <div class="hero-illustration">
          <div class="circle-bg" style="width:300px;height:300px;">
            <i class="bi bi-basket2-fill" style="font-size:7rem;color:var(--sky-dark);"></i>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="section-tag">Siapa Kami</div>
        <h2 class="section-title">Bilqis Laundry – Solusi Cucian Anda</h2>
        <p style="color:var(--text-muted);line-height:1.8;margin-bottom:20px;">
          Bilqis Laundry berdiri sejak 2022 di Kecamatan Sidoarjo. Kami hadir sebagai solusi laundry terpercaya yang
          mengutamakan kebersihan, kerapian, dan kepuasan pelanggan. Dengan teknologi mesin modern dan deterjen premium,
          setiap pakaian dirawat dengan penuh perhatian.
        </p>
        <p style="color:var(--text-muted);line-height:1.8;">
          Kami melayani berbagai jenis laundry mulai dari cuci basah, cuci kering, hingga layanan setrika wangi.
          Tim kami yang berpengalaman siap memastikan pakaian Anda kembali bersih, wangi, dan rapi tepat waktu.
        </p>
        <div class="d-flex flex-wrap gap-3 mt-4">
          <a href="<?= isLoggedIn() ? BASE_URL . '/pelanggan/pesanan_baru.php' : BASE_URL . '/auth/login.php' ?>" class="btn-primary-sky"><i class="bi bi-cart-plus"></i> Pesan Sekarang</a>
          <a href="<?= BASE_URL ?>/pages/kontak.php" class="btn-outline-sky"><i class="bi bi-telephone"></i> Hubungi Kami</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- VISI MISI -->
<section style="padding:60px 0;background:var(--sky-pale);">
  <div class="container">
    <div class="row g-4">
      <div class="col-md-6">
        <div class="feature-card">
          <div class="feature-icon"><i class="bi bi-eye-fill"></i></div>
          <div class="feature-title">Visi Kami</div>
          <div class="feature-desc">Menjadi laundry pilihan utama masyarakat Sidoarjo yang dikenal atas kualitas, kepercayaan, dan pelayanan yang ramah.</div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="feature-card">
          <div class="feature-icon"><i class="bi bi-bullseye"></i></div>
          <div class="feature-title">Misi Kami</div>
          <div class="feature-desc">Memberikan hasil cucian terbaik dengan harga terjangkau, proses cepat, dan pelayanan yang profesional kepada setiap pelanggan.</div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>