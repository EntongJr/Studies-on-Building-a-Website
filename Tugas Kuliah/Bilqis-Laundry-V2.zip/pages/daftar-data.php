<?php
// =============================================
//  HALAMAN: DAFTAR DATA PESANAN
// =============================================

require_once __DIR__ . '/../includes/functions.php';

$pageTitle = 'Data Pesanan';
$activeNav = 'data';

// Ambil data langsung dari database
try {
  $db = getDB();

  $pesanan = $db->query("
        SELECT
            p.id_pesanan,
            p.tanggal_pesanan,
            pl.nama_pelanggan,
            GROUP_CONCAT(l.nama_layanan SEPARATOR ', ') AS layanan_list,
            p.berat_cucian,
            p.total_harga,
            sp.nama_status
        FROM pesanan p
        JOIN pelanggan pl ON p.id_pelanggan = pl.id_pelanggan
        JOIN status_pesanan sp ON p.id_status = sp.id_status
        LEFT JOIN detail_pesanan dp ON p.id_pesanan = dp.id_pesanan
        LEFT JOIN layanan l ON dp.id_layanan = l.id_layanan
        GROUP BY p.id_pesanan
        ORDER BY p.tanggal_pesanan DESC
    ")->fetchAll();

  $statusList = $db->query("SELECT * FROM status_pesanan ORDER BY id_status")->fetchAll();
} catch (Exception $e) {
  $pesanan    = [];
  $statusList = [];
}

include __DIR__ . '/../includes/header.php';
?>

<!-- PAGE HEADER -->
<section class="page-header">
  <div class="container">
    <div class="section-tag">Data Pesanan</div>
    <h1>Daftar Semua Pesanan</h1>
    <p>Kelola dan pantau seluruh data pesanan pelanggan Bilqis Laundry.</p>
  </div>
</section>

<section class="data-section">
  <div class="container">

    <!-- STATS MINI -->
    <div class="row g-3 mb-4">
      <?php
      $total    = count($pesanan);
      $menunggu = count(array_filter($pesanan, fn($r) => $r['nama_status'] === 'Menunggu'));
      $proses   = count(array_filter($pesanan, fn($r) => in_array($r['nama_status'], ['Diproses', 'Dicuci', 'Disetrika'])));
      $selesai  = count(array_filter($pesanan, fn($r) => in_array($r['nama_status'], ['Selesai', 'Sudah Diambil'])));
      ?>
      <div class="col-6 col-md-3">
        <div class="stat-mini">
          <div class="num"><?= $total ?></div>
          <div class="lbl">Total Pesanan</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-mini">
          <div class="num"><?= $menunggu ?></div>
          <div class="lbl">Menunggu</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-mini">
          <div class="num"><?= $proses ?></div>
          <div class="lbl">Diproses</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-mini">
          <div class="num"><?= $selesai ?></div>
          <div class="lbl">Selesai</div>
        </div>
      </div>
    </div>

    <!-- SEARCH -->
    <div class="controls-bar mb-3">
      <div class="row g-3 align-items-center">
        <div class="col-md-6">
          <input type="text" class="search-input" id="searchInput"
            placeholder="🔍 Cari nama pelanggan, layanan, atau status..."
            oninput="filterTable()" />
        </div>
        <!-- <div class="col-md-6 d-flex justify-content-md-end gap-2">
          <button class="btn-action btn-export" onclick="exportCSV()">
            <i class="bi bi-download"></i> Export CSV
          </button>
        </div> -->
      </div>
    </div>

    <!-- TABLE -->
    <div class="table-card">
      <div class="table-responsive">
        <table class="table data-table" id="tabelPesanan">
          <thead>
            <tr>
              <th>No</th>
              <th>Tanggal Pesanan</th>
              <th>Nama Pelanggan</th>
              <th>Layanan</th>
              <th>Berat (kg)</th>
              <th>Status</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody id="tableBody">
            <?php if (empty($pesanan)): ?>
              <tr>
                <td colspan="7" class="text-center py-5 text-muted">
                  <i class="bi bi-inbox" style="font-size:2rem;display:block;margin-bottom:.5rem"></i>
                  Belum ada data pesanan.
                </td>
              </tr>
            <?php else: ?>
              <?php foreach ($pesanan as $i => $p):
                $s = $p['nama_status'];
                $badgeClass = match (true) {
                  in_array($s, ['Selesai', 'Sudah Diambil']) => 'status-selesai',
                  in_array($s, ['Diproses', 'Dicuci', 'Disetrika']) => 'status-proses',
                  $s === 'Menunggu' => 'status-menunggu',
                  default => 'status-menunggu'
                };
              ?>
                <tr class="data-row">
                  <td><?= $i + 1 ?></td>
                  <td style="font-size:.85rem;color:var(--text-muted)">
                    <?= date('d M Y', strtotime($p['tanggal_pesanan'])) ?><br>
                    <small><?= date('H:i', strtotime($p['tanggal_pesanan'])) ?></small>
                  </td>
                  <td><strong><?= htmlspecialchars($p['nama_pelanggan']) ?></strong></td>
                  <td><?= htmlspecialchars($p['layanan_list'] ?? '-') ?></td>
                  <td><?= $p['berat_cucian'] ? number_format((float)$p['berat_cucian'], 1) . ' kg' : '-' ?></td>
                  <td><span class="status-badge <?= $badgeClass ?>"><?= htmlspecialchars($s) ?></span></td>
                  <td style="font-weight:700;color:var(--sky-dark)">
                    <?= $p['total_harga'] ? 'Rp ' . number_format((float)$p['total_harga'], 0, ',', '.') : '-' ?>
                  </td>

                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</section>

<!-- TOAST -->
<div class="toast-container" id="toastContainer"></div>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<script>
  // ── Filter tabel ──────────────────────────────
  function filterTable() {
    const keyword = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.querySelectorAll('#tableBody .data-row');
    rows.forEach(row => {
      row.style.display = row.textContent.toLowerCase().includes(keyword) ? '' : 'none';
    });
  }

  // ── Update Status ─────────────────────────────
  function gantiStatus(idPesanan) {
    const statusList = <?= json_encode($statusList) ?>;
    const opts = statusList.map(s =>
      `<option value="${s.id_status}">${s.nama_status}</option>`
    ).join('');

    const overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:9999;display:flex;align-items:center;justify-content:center';
    overlay.innerHTML = `
    <div style="background:#fff;border-radius:20px;padding:32px;min-width:320px;box-shadow:0 8px 40px rgba(0,0,0,.2)">
      <h6 style="font-weight:800;margin-bottom:16px">Update Status Pesanan</h6>
      <p style="font-size:.85rem;color:#666;margin-bottom:12px">ID: <code>${idPesanan}</code></p>
      <select class="form-select" id="selectStatus">${opts}</select>
      <div class="d-flex gap-2 mt-4">
        <button class="btn btn-primary rounded-pill px-4" onclick="doUpdateStatus('${idPesanan}')">Simpan</button>
        <button class="btn btn-secondary rounded-pill px-4" onclick="this.closest('div[style*=fixed]').remove()">Batal</button>
      </div>
    </div>`;
    document.body.appendChild(overlay);
  }

  function doUpdateStatus(idPesanan) {
    const idStatus = document.getElementById('selectStatus').value;
    document.querySelector('div[style*="position:fixed"]').remove();

    fetch(BASE_URL . '/api/update_status.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          id_pesanan: idPesanan,
          id_status: idStatus
        })
      })
      .then(r => r.json())
      .then(data => {
        if (data.status === 'success') {
          showToast('success', 'Berhasil!', 'Status pesanan diperbarui.');
          setTimeout(() => location.reload(), 1200);
        } else {
          showToast('error', 'Gagal!', data.message ?? 'Terjadi kesalahan.');
        }
      })
      .catch(() => showToast('error', 'Error!', 'Tidak dapat terhubung ke server.'));
  }

  // ── Hapus Pesanan ─────────────────────────────
  function hapusPesanan(idPesanan) {
    if (!confirm(`Hapus pesanan ${idPesanan}? Tindakan ini tidak bisa dibatalkan.`)) return;

    fetch(BASE_URL . '/api/get_pesanan.php', {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          id_pesanan: idPesanan
        })
      })
      .then(r => r.json())
      .then(data => {
        if (data.status === 'success') {
          showToast('success', 'Dihapus!', 'Pesanan berhasil dihapus.');
          setTimeout(() => location.reload(), 1200);
        } else {
          showToast('error', 'Gagal!', data.message ?? 'Terjadi kesalahan.');
        }
      })
      .catch(() => showToast('error', 'Error!', 'Tidak dapat terhubung ke server.'));
  }

  // ── Export CSV ────────────────────────────────
  function exportCSV() {
    const rows = document.querySelectorAll('#tableBody .data-row');
    if (!rows.length) {
      showToast('error', 'Tidak ada data', 'Belum ada pesanan untuk diexport.');
      return;
    }
    const header = ['No', 'Tanggal Pesanan', 'Nama Pelanggan', 'Layanan', 'Berat (kg)', 'Status', 'Total'];
    const data = Array.from(rows).map(row => {
      const cells = row.querySelectorAll('td');
      return [
        cells[0].textContent.trim(),
        cells[1].textContent.trim().replace(/\s+/g, ' '),
        cells[2].textContent.trim(),
        cells[3].textContent.trim(),
        cells[4].textContent.trim(),
        cells[5].textContent.trim(),
        cells[6].textContent.trim(),
      ];
    });
    const csv = [header, ...data].map(r => r.map(c => `"${c}"`).join(',')).join('\n');
    const blob = new Blob([csv], {
      type: 'text/csv;charset=utf-8;'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pesanan_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  // ── Toast ─────────────────────────────────────
  function showToast(type, title, msg) {
    const cont = document.getElementById('toastContainer');
    const icon = type === 'success' ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill';
    const color = type === 'success' ? 'var(--sky-dark)' : '#e53e3e';
    const el = document.createElement('div');
    el.className = 'custom-toast';
    el.innerHTML = `
    <i class="bi ${icon} toast-icon" style="color:${color}"></i>
    <div class="toast-text"><strong>${title}</strong><span>${msg}</span></div>
    <button onclick="this.parentElement.remove()" style="margin-left:auto;background:none;border:none;font-size:1.1rem;cursor:pointer;color:#999">×</button>`;
    cont.appendChild(el);
    setTimeout(() => {
      if (el.parentElement) el.remove();
    }, 4000);
  }
</script>