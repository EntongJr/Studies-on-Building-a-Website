<?php
// =============================================
//  HALAMAN: KONTAK
// =============================================

require_once __DIR__ . '/../includes/functions.php';

$pageTitle = 'Kontak';
$activeNav = 'kontak';

include __DIR__ . '/../includes/header.php';
?>

<!-- PAGE HEADER -->
<section class="page-header">
  <div class="container">
    <div class="section-tag">Kontak</div>
    <h1>Hubungi Kami</h1>
    <p>Ada pertanyaan atau ingin mengetahui lebih lanjut? Kami siap membantu Anda.</p>
  </div>
</section>

<!-- KONTAK SECTION -->
<section style="padding:80px 0;background:var(--white);">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-6 col-md-8">

        <div class="text-center mb-4">
          <div class="section-tag mx-auto" style="display:inline-block">Informasi Kontak</div>
          <h2 class="section-title">Cara Menghubungi Kami</h2>
          <p style="color:var(--text-muted)">Kami melayani dengan ramah dan siap menjawab pertanyaan Anda.</p>
        </div>

        <div class="info-card">
          <div class="info-item">
            <i class="bi bi-geo-alt-fill"></i>
            <div class="info-text">
              <strong>Alamat</strong>
              <span>Jl. Diponegoro No. 12, Kecamatan Sidoarjo, Jawa Timur</span>
            </div>
          </div>
          <div class="info-item">
            <i class="bi bi-whatsapp" style="color:#25D366"></i>
            <div class="info-text">
              <strong>WhatsApp</strong>
              <span>0821-3148-5350 (Balas dalam 1 jam)</span>
            </div>
          </div>
          <div class="info-item">
            <i class="bi bi-clock-fill"></i>
            <div class="info-text">
              <strong>Jam Operasional</strong>
              <span>Senin – Minggu, 07.00 – 21.00 WIB</span>
            </div>
          </div>
          <div class="info-item mb-0">
            <i class="bi bi-envelope-fill"></i>
            <div class="info-text">
              <strong>Email</strong>
              <span>bilqislaundry@gmail.com</span>
            </div>
          </div>
        </div>

        <div class="text-center mt-4">
          <a href="https://wa.me/<?= WA_NUMBER ?>?text=Halo%20Bilqis%20Laundry%2C%20saya%20ingin%20bertanya."
            class="btn-primary-sky" target="_blank">
            <i class="bi bi-whatsapp"></i> Chat WhatsApp Sekarang
          </a>
        </div>

      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>