# Bilqis Laundry – PHP Version

Program laundry yang dikonversi dari HTML statis ke PHP dengan koneksi `db_laundry`.

## Struktur Folder

```
bilqis_laundry/
├── index.php                  ← Beranda
├── migrate.sql                ← Jalankan ini DULU di HeidiSQL/phpMyAdmin
│
├── includes/
│   ├── config.php             ← Konfigurasi DB & konstanta
│   ├── db.php                 ← Koneksi PDO (singleton)
│   ├── functions.php          ← Helper: rupiah(), clean(), dll
│   ├── header.php             ← Komponen navbar + <head>
│   └── footer.php             ← Komponen footer + WA float
│
├── pages/
│   ├── tentang.php            ← Halaman Tentang
│   ├── layanan.php            ← Daftar layanan (dari DB)
│   ├── pesanan.php            ← Form buat pesanan → simpan ke DB
│   ├── daftar-data.php        ← Tabel semua pesanan (CRUD)
│   └── kontak.php             ← Kontak + lacak pesanan by no. WA
│
├── api/
│   ├── simpan_pesanan.php     ← POST: simpan pesanan baru
│   ├── get_layanan.php        ← GET:  daftar layanan (JSON)
│   ├── get_pesanan.php        ← GET/DELETE: daftar & hapus pesanan
│   └── update_status.php      ← POST/PATCH: update status pesanan
│
└── assets/
    └── css/
        └── style.css          ← Semua CSS global
```

## Setup Langkah demi Langkah

### 1. Taruh folder di Laragon

Salin folder `bilqis_laundry/` ke:
```
C:\laragon\www\bilqis_laundry\
```

### 2. Konfigurasi database

Edit `includes/config.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');          // kosong jika default Laragon
define('DB_NAME', 'db_laundry');
```

### 3. Jalankan migrasi SQL

Buka HeidiSQL → pilih database `db_laundry` → jalankan isi file `migrate.sql`.

Script ini akan:
- Menambahkan kolom yang diperlukan (berat_dihitung, harga_per_kg, dll)
- Mengisi data awal layanan (5 jenis)
- Mengisi data awal status pesanan (Menunggu, Diproses, Selesai)

### 4. Akses di browser

```
http://localhost/bilqis_laundry/
```

## Fitur Utama

| Halaman        | Fitur                                                    |
|----------------|----------------------------------------------------------|
| Beranda        | Statistik live dari DB (jumlah pelanggan, layanan)       |
| Layanan        | Daftar harga otomatis dari tabel `layanan`               |
| Pesanan        | Form simpan pesanan → DB (tabel pesanan + detail_pesanan)|
| Data           | CRUD pesanan: lihat detail, ganti status, hapus, export CSV |
| Kontak         | Lacak pesanan by No. WhatsApp                            |

## API Endpoints

| Method | URL                      | Fungsi                      |
|--------|--------------------------|-----------------------------|
| POST   | /api/simpan_pesanan.php  | Simpan pesanan baru         |
| GET    | /api/get_layanan.php     | Ambil daftar layanan (JSON) |
| GET    | /api/get_pesanan.php     | Ambil semua pesanan         |
| GET    | /api/get_pesanan.php?search=... | Filter pesanan      |
| DELETE | /api/get_pesanan.php     | Hapus pesanan (body JSON)   |
| POST   | /api/update_status.php   | Update status pesanan       |
