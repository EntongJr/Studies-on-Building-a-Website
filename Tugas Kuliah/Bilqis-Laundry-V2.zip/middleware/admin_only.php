<?php
require_once __DIR__ . '/auth.php';
requireRole([ROLE_ADMIN]);
