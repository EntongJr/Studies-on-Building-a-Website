<?php
// =============================================
//  MIDDLEWARE: auth.php
//  Cek apakah user sudah login
// =============================================

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../includes/config.php';

function requireLogin(?string $redirect = null): void {
    if ($redirect === null) {
        $redirect = BASE_URL . '/auth/login.php';
    }
    if (empty($_SESSION['user_id'])) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        header('Location: ' . $redirect);
        exit;
    }
}

function requireRole(array $roles, ?string $redirect = null): void {
    requireLogin($redirect);
    if (!in_array($_SESSION['role'] ?? '', $roles, true)) {
        header('Location: ' . BASE_URL . '/auth/unauthorized.php');
        exit;
    }
}

function isLoggedIn(): bool {
    return !empty($_SESSION['user_id']);
}

function currentRole(): string {
    return $_SESSION['role'] ?? ROLE_GUEST;
}

function currentUser(): array {
    return [
        'id'    => $_SESSION['user_id']   ?? null,
        'nama'  => $_SESSION['user_nama'] ?? 'Tamu',
        'email' => $_SESSION['user_email'] ?? '',
        'role'  => $_SESSION['role']      ?? ROLE_GUEST,
    ];
}
