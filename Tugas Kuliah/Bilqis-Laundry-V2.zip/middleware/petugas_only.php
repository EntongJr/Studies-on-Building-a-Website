<?php
require_once __DIR__ . '/auth.php';
requireRole([ROLE_PETUGAS, ROLE_ADMIN]);
