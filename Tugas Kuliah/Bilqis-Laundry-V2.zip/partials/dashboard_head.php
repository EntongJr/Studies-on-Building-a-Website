<?php
// =============================================
//  PARTIAL: dashboard_head.php
//  Include di <head> semua halaman dashboard
// =============================================
?>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet"/>
<link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet"/>
<style>
:root {
  --sky:#0ea5e9; --sky-dark:#0284c7; --sky-light:#e0f2fe;
  --sidebar-w:260px; --topbar-h:64px;
}
* { box-sizing:border-box; }
body { font-family:'Poppins',sans-serif; background:#f8fafc; margin:0; }

/* SIDEBAR */
.sidebar {
  position:fixed; top:0; left:0; height:100vh; width:var(--sidebar-w);
  background:linear-gradient(180deg,#0c1a2e 0%,#0f2744 100%);
  display:flex; flex-direction:column; z-index:1000;
  transition:transform .3s;
}
.sidebar-brand {
  padding:1.25rem 1.5rem;
  border-bottom:1px solid rgba(255,255,255,.08);
  color:#fff;
  font-weight:700; font-size:1.1rem;
  display:flex; align-items:center; gap:.6rem;
}
.sidebar-brand .icon { font-size:1.4rem; color:var(--sky); }
.sidebar-nav { flex:1; overflow-y:auto; padding:.75rem 0; }
.sidebar-nav a {
  display:flex; align-items:center; gap:.75rem;
  padding:.65rem 1.5rem; color:rgba(255,255,255,.65);
  text-decoration:none; font-size:.875rem; font-weight:500;
  transition:all .2s; border-left:3px solid transparent;
}
.sidebar-nav a:hover { color:#fff; background:rgba(255,255,255,.06); }
.sidebar-nav a.active { color:#fff; background:rgba(14,165,233,.15); border-left-color:var(--sky); }
.sidebar-nav .nav-section {
  padding:.5rem 1.5rem .25rem;
  font-size:.7rem; font-weight:600; letter-spacing:.08em;
  color:rgba(255,255,255,.35); text-transform:uppercase;
}
.sidebar-footer {
  padding:1rem 1.5rem;
  border-top:1px solid rgba(255,255,255,.08);
}
.sidebar-footer a {
  color:rgba(255,255,255,.6); font-size:.85rem;
  text-decoration:none; display:flex; align-items:center; gap:.5rem;
}
.sidebar-footer a:hover { color:#fff; }

/* TOPBAR */
.topbar {
  position:fixed; top:0; left:var(--sidebar-w); right:0;
  height:var(--topbar-h);
  background:#fff; border-bottom:1px solid #e5e7eb;
  display:flex; align-items:center; justify-content:space-between;
  padding:0 1.5rem; z-index:999;
}
.topbar .menu-toggle { display:none; }

/* MAIN CONTENT */
.main-content {
  margin-left:var(--sidebar-w);
  padding-top:var(--topbar-h);
  min-height:100vh;
}
.page-content { padding:1.5rem; }

/* CARDS */
.stat-card {
  background:#fff; border-radius:16px;
  padding:1.25rem 1.5rem;
  box-shadow:0 1px 3px rgba(0,0,0,.06);
  border:1px solid #f0f0f0;
}
.stat-card .stat-icon {
  width:48px; height:48px; border-radius:12px;
  display:flex; align-items:center; justify-content:center;
  font-size:1.4rem;
}
.stat-card .stat-val { font-size:1.6rem; font-weight:700; }
.stat-card .stat-lbl { font-size:.8rem; color:#6b7280; }

/* TABLES */
.card { border-radius:16px; border:1px solid #f0f0f0; box-shadow:0 1px 3px rgba(0,0,0,.06); }
.card-header { background:#fff; border-bottom:1px solid #f0f0f0; padding:1rem 1.25rem; border-radius:16px 16px 0 0 !important; }
table.dataTable td, table.dataTable th { vertical-align:middle; }
.badge { font-weight:500; }

/* RESPONSIVE */
@media (max-width:991px) {
  .sidebar { transform:translateX(-100%); }
  .sidebar.open { transform:translateX(0); }
  .main-content { margin-left:0; }
  .topbar { left:0; }
  .topbar .menu-toggle { display:block; }
}

/* WhatsApp Float */
.wa-float { position: fixed; bottom: 28px; right: 28px; z-index: 9999; width: 58px; height: 58px; border-radius: 50%; background: #25D366; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 1.7rem; text-decoration: none; box-shadow: 0 6px 24px rgba(37,211,102,.5); transition: transform .25s, box-shadow .25s; animation: pulse-wa 2.5s ease-in-out infinite; }
.wa-float:hover { transform: scale(1.12); color: #fff; box-shadow: 0 10px 36px rgba(37,211,102,.65); }
@keyframes pulse-wa { 0%,100%{box-shadow:0 6px 24px rgba(37,211,102,.5)} 50%{box-shadow:0 6px 32px rgba(37,211,102,.85)} }
</style>
