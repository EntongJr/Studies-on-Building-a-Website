<?php
// =============================================
//  PARTIAL: Admin Topbar
// =============================================
$user = currentUser();
?>
<div class="topbar">
  <button class="btn btn-sm btn-light menu-toggle" id="menuToggle"><i class="bi bi-list fs-5"></i></button>
  <div class="d-flex align-items-center gap-3">
    <span class="text-muted d-none d-md-inline" style="font-size:.85rem"><i class="bi bi-clock me-1"></i><?= date('d M Y') ?></span>
    <div class="d-flex align-items-center gap-2">
      <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,#0ea5e9,#0284c7);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:600;font-size:.9rem;">
        <?= strtoupper(substr($user['nama'],0,1)) ?>
      </div>
      <div style="font-size:.85rem">
        <div class="fw-600"><?= htmlspecialchars($user['nama']) ?></div>
        <div class="text-muted" style="font-size:.75rem">Administrator</div>
      </div>
    </div>
  </div>
</div>
