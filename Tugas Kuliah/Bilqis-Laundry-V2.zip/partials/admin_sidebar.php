<?php
// =============================================
//  PARTIAL: Admin Sidebar
//  $activeNav harus sudah di-set sebelum include
// =============================================
$keluhanBaru = 0;
try {
    $keluhanBaru = getDB()->query("SELECT COUNT(*) FROM keluhan WHERE status_keluhan='baru'")->fetchColumn();
} catch(Exception $e) {}
?>
<div class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <i class="bi bi-basket2-fill icon"></i>
    <div>Bilqis Laundry<br><small style="font-size:.7rem;font-weight:400;opacity:.7">Panel Admin</small></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section">Utama</div>
    <a href="<?= BASE_URL ?>/admin/dashboard.php"  class="<?= ($activeNav??'')==='dashboard'  ?'active':'' ?>"><i class="bi bi-grid-1x2"></i> Dashboard</a>
    <div class="nav-section">Kelola Data</div>
    <a href="<?= BASE_URL ?>/admin/pesanan.php"    class="<?= ($activeNav??'')==='pesanan'    ?'active':'' ?>"><i class="bi bi-bag-check"></i> Pesanan</a>
    <a href="<?= BASE_URL ?>/admin/pelanggan.php"  class="<?= ($activeNav??'')==='pelanggan'  ?'active':'' ?>"><i class="bi bi-people"></i> Pelanggan</a>
    <a href="<?= BASE_URL ?>/admin/petugas.php"    class="<?= ($activeNav??'')==='petugas'    ?'active':'' ?>"><i class="bi bi-person-badge"></i> Petugas</a>
    <a href="<?= BASE_URL ?>/admin/layanan.php"    class="<?= ($activeNav??'')==='layanan'    ?'active':'' ?>"><i class="bi bi-tags"></i> Layanan</a>
    <a href="<?= BASE_URL ?>/admin/promo.php"      class="<?= ($activeNav??'')==='promo'      ?'active':'' ?>"><i class="bi bi-gift"></i> Promo</a>
    <a href="<?= BASE_URL ?>/admin/pembayaran.php" class="<?= ($activeNav??'')==='pembayaran' ?'active':'' ?>"><i class="bi bi-cash-stack"></i> Pembayaran</a>
    <a href="<?= BASE_URL ?>/admin/jabatan.php"    class="<?= ($activeNav??'')==='jabatan'    ?'active':'' ?>"><i class="bi bi-briefcase"></i> Jabatan</a>
    <div class="nav-section">Lainnya</div>
    <a href="<?= BASE_URL ?>/admin/keluhan.php"    class="<?= ($activeNav??'')==='keluhan'    ?'active':'' ?>">
      <i class="bi bi-chat-dots"></i> Keluhan
      <?php if ($keluhanBaru > 0): ?>
        <span class="badge bg-danger ms-auto"><?= $keluhanBaru ?></span>
      <?php endif; ?>
    </a>
    <a href="<?= BASE_URL ?>/admin/laporan.php"    class="<?= ($activeNav??'')==='laporan'    ?'active':'' ?>"><i class="bi bi-bar-chart"></i> Laporan</a>
  </nav>
  <div class="sidebar-footer">
    <a href="<?= BASE_URL ?>/auth/logout.php"><i class="bi bi-box-arrow-left"></i> Logout</a>
  </div>
</div>
