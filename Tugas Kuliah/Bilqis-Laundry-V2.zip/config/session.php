<?php
// =============================================
//  SESSION CONFIG – Bilqis Laundry
// =============================================

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 86400 * 30,
        'path'     => '/',
        'secure'   => false,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

define('ROLE_GUEST',      'guest');
define('ROLE_PELANGGAN',  'pelanggan');
define('ROLE_PETUGAS',    'petugas');
define('ROLE_ADMIN',      'admin');
