<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/admin_only.php';
require_once __DIR__ . '/../includes/functions.php';

$db  = getDB();
$activeNav = 'laporan';

$bulan  = $_GET['bulan'] ?? date('m');
$tahun  = $_GET['tahun'] ?? date('Y');

// Export CSV
if (isset($_GET['export']) && $_GET['export'] == 'csv') {

  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename="laporan-' . $bulan . '-' . $tahun . '.csv"');

  $output = fopen('php://output', 'w');

  // Header kolom
  fputcsv($output, [
    'ID Pesanan',
    'Pelanggan',
    'Metode Pembayaran',
    'Jumlah Bayar',
    'Tanggal Bayar',
    'Status'
  ]);

  $export = $db->prepare("
        SELECT p.id_pesanan,
               pl.nama_pelanggan,
               mp.nama_metode,
               py.jumlah_bayar,
               py.tanggal_bayar,
               sp.nama_status
        FROM pembayaran py
        JOIN pesanan p ON py.id_pesanan = p.id_pesanan
        JOIN pelanggan pl ON p.id_pelanggan = pl.id_pelanggan
        JOIN metode_pembayaran mp ON py.id_metode = mp.id_metode
        JOIN status_pesanan sp ON p.id_status = sp.id_status
        WHERE MONTH(py.tanggal_bayar)=?
        AND YEAR(py.tanggal_bayar)=?
        ORDER BY py.tanggal_bayar DESC
    ");

  $export->execute([$bulan, $tahun]);

  while ($r = $export->fetch(PDO::FETCH_ASSOC)) {

    fputcsv($output, [
      $r['id_pesanan'],
      $r['nama_pelanggan'],
      $r['nama_metode'],
      $r['jumlah_bayar'],
      date('d-m-Y', strtotime($r['tanggal_bayar'])),
      $r['nama_status']
    ]);
  }

  fclose($output);
  exit;
}



// Laporan bulan ini
$laporan = $db->prepare("
    SELECT p.id_pesanan, pl.nama_pelanggan, py.jumlah_bayar,
           mp.nama_metode, py.tanggal_bayar, sp.nama_status
    FROM pembayaran py
    JOIN pesanan p ON py.id_pesanan = p.id_pesanan
    JOIN pelanggan pl ON p.id_pelanggan = pl.id_pelanggan
    JOIN metode_pembayaran mp ON py.id_metode = mp.id_metode
    JOIN status_pesanan sp ON p.id_status = sp.id_status
    WHERE MONTH(py.tanggal_bayar) = ? AND YEAR(py.tanggal_bayar) = ?
    ORDER BY py.tanggal_bayar DESC
");
$laporan->execute([$bulan, $tahun]);
$rows = $laporan->fetchAll();

$totalBulanIni = array_sum(array_column($rows, 'jumlah_bayar'));

// Per-bulan chart data (12 bulan terakhir)
$chartData = [];
for ($m = 1; $m <= 12; $m++) {
  $stmt = $db->prepare("SELECT COALESCE(SUM(jumlah_bayar),0) FROM pembayaran WHERE MONTH(tanggal_bayar)=? AND YEAR(tanggal_bayar)=?");
  $stmt->execute([$m, $tahun]);
  $chartData[] = (float)$stmt->fetchColumn();
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Laporan – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>
  <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>
  <?php include __DIR__ . '/../partials/admin_topbar.php'; ?>

  <div class="main-content">
    <div class="page-content">
      <h5 class="fw-700 mb-4">Laporan Transaksi</h5>

      <!-- Filter -->
      <form method="GET" class="row g-2 mb-4">
        <div class="col-auto">
          <select name="bulan" class="form-select">
            <?php
            $namaBulan = ['', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
            for ($i = 1; $i <= 12; $i++): ?>
              <option value="<?= $i ?>" <?= $i == $bulan ? 'selected' : '' ?>><?= $namaBulan[$i] ?></option>
            <?php endfor; ?>
          </select>
        </div>
        <div class="col-auto">
          <select name="tahun" class="form-select">
            <?php for ($y = date('Y'); $y >= 2020; $y--): ?>
              <option value="<?= $y ?>" <?= $y == $tahun ? 'selected' : '' ?>><?= $y ?></option>
            <?php endfor; ?>
          </select>
        </div>

        <div class="col-auto">
          <button type="submit" class="btn btn-primary">
            <i class="bi bi-funnel me-1"></i>Filter
          </button>
        </div>

        <div class="col-auto">
          <a href="?bulan=<?= $bulan ?>&tahun=<?= $tahun ?>&export=csv"
            class="btn btn-success">
            <i class="bi bi-file-earmark-spreadsheet me-1"></i>
            Export CSV
          </a>
        </div>

      </form>

      <!-- Chart -->
      <div class="card mb-4">
        <div class="card-body">
          <h6 class="fw-600 mb-3">Pendapatan Bulanan Tahun <?= $tahun ?></h6>
          <canvas id="chartPendapatan" height="100"></canvas>
        </div>
      </div>

      <!-- Summary -->
      <div class="alert alert-success rounded-3">
        <strong>Total Pendapatan <?= $namaBulan[(int)$bulan] . ' ' . $tahun ?>: <?= rupiah($totalBulanIni) ?></strong>
        (<?= count($rows) ?> transaksi)
      </div>

      <div class="card">
        <div class="card-body">
          <table class="table dt-table">
            <thead class="table-light">
              <tr>
                <th>#</th>
                <th>ID Pesanan</th>
                <th>Pelanggan</th>
                <th>Metode</th>
                <th>Jumlah</th>
                <th>Tanggal</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($rows as $i => $r): ?>
                <tr>
                  <td><?= $i + 1 ?></td>
                  <td><code><?= htmlspecialchars($r['id_pesanan']) ?></code></td>
                  <td><?= htmlspecialchars($r['nama_pelanggan']) ?></td>
                  <td><?= htmlspecialchars($r['nama_metode']) ?></td>
                  <td><?= rupiah((float)$r['jumlah_bayar']) ?></td>
                  <td><?= date('d M Y', strtotime($r['tanggal_bayar'])) ?></td>
                  <td><span class="badge bg-success"><?= htmlspecialchars($r['nama_status']) ?></span></td>
                </tr>
              <?php endforeach; ?>
              <?php if (empty($rows)): ?>
                <tr>
                  <td colspan="7" class="text-center text-muted">Tidak ada data pada bulan ini</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
  <script>
    new Chart(document.getElementById('chartPendapatan'), {
      type: 'bar',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'],
        datasets: [{
          label: 'Pendapatan (Rp)',
          data: <?= json_encode($chartData) ?>,
          backgroundColor: 'rgba(14,165,233,.7)',
          borderRadius: 6,
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          y: {
            ticks: {
              callback: v => 'Rp ' + v.toLocaleString('id')
            }
          }
        }
      }
    });
  </script>
</body>

</html>