<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/admin_only.php';
require_once __DIR__ . '/../includes/functions.php';

$db  = getDB();
$activeNav = 'keluhan';
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'update') {
        $db->prepare("UPDATE keluhan SET status_keluhan=? WHERE id_keluhan=?")
           ->execute([$_POST['status_keluhan'], $_POST['id_keluhan']]);
        $msg = 'success|Status keluhan diperbarui.';
    }
}

$keluhan = $db->query("
    SELECT k.*, p.id_pesanan, pl.nama_pelanggan
    FROM keluhan k
    JOIN pesanan p ON k.id_pesanan = p.id_pesanan
    JOIN pelanggan pl ON p.id_pelanggan = pl.id_pelanggan
    ORDER BY k.tanggal_keluhan DESC
")->fetchAll();

[$msgType,$msgText] = $msg ? explode('|',$msg,2) : ['',''];
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Keluhan – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>
<?php include __DIR__ . '/../partials/admin_topbar.php'; ?>

<div class="main-content"><div class="page-content">
  <h5 class="fw-700 mb-4">Keluhan Pelanggan</h5>

  <?php if ($msgText): ?>
    <div class="alert alert-<?= $msgType==='success'?'success':'danger' ?> alert-dismissible rounded-3">
      <?= htmlspecialchars($msgText) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <div class="card"><div class="card-body">
    <table class="table dt-table">
      <thead class="table-light">
        <tr><th>#</th><th>Pelanggan</th><th>Pesanan</th><th>Isi Keluhan</th><th>Status</th><th>Tanggal</th><th>Aksi</th></tr>
      </thead>
      <tbody>
        <?php foreach ($keluhan as $i => $k): ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td><?= htmlspecialchars($k['nama_pelanggan']) ?></td>
          <td><code><?= htmlspecialchars($k['id_pesanan']) ?></code></td>
          <td><?= htmlspecialchars(substr($k['isi_keluhan'],0,60)) ?>...</td>
          <td>
            <?php $st = strtolower($k['status_keluhan']); ?>
            <span class="badge bg-<?= $st==='selesai'?'success':($st==='diproses'?'primary':'warning') ?>">
              <?= htmlspecialchars($k['status_keluhan']) ?>
            </span>
          </td>
          <td><?= date('d M Y', strtotime($k['tanggal_keluhan'])) ?></td>
          <td>
            <button class="btn btn-sm btn-info rounded-pill text-white" onclick="updateKeluhan('<?= $k['id_keluhan'] ?>','<?= $k['status_keluhan'] ?>','<?= htmlspecialchars(addslashes($k['isi_keluhan'])) ?>')">
              <i class="bi bi-eye"></i> Detail
            </button>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div></div>
</div></div>

<!-- Modal Detail -->
<div class="modal fade" id="modalDetail" tabindex="-1">
  <div class="modal-dialog"><div class="modal-content rounded-4">
    <form method="POST">
      <input type="hidden" name="action" value="update"/>
      <input type="hidden" name="id_keluhan" id="kId"/>
      <div class="modal-header"><h5 class="modal-title">Detail Keluhan</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label fw-600">Isi Keluhan</label>
          <div id="kIsi" class="p-3 bg-light rounded-3" style="white-space:pre-wrap"></div>
        </div>
        <div class="mb-3">
          <label class="form-label">Update Status</label>
          <select name="status_keluhan" id="kStatus" class="form-select">
            <option value="baru">Baru</option>
            <option value="diproses">Diproses</option>
            <option value="selesai">Selesai</option>
          </select>
        </div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button><button type="submit" class="btn btn-primary">Update Status</button></div>
    </form>
  </div></div>
</div>

<?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
<script>
function updateKeluhan(id, status, isi) {
  document.getElementById('kId').value    = id;
  document.getElementById('kStatus').value = status;
  document.getElementById('kIsi').textContent = isi;
  new bootstrap.Modal(document.getElementById('modalDetail')).show();
}
</script>
</body></html>
