<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/admin_only.php';
require_once __DIR__ . '/../includes/functions.php';

$db  = getDB();
$msg = '';
$activeNav = 'layanan';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  if ($action === 'tambah') {
    $last = $db->query("SELECT id_layanan FROM layanan ORDER BY id_layanan DESC LIMIT 1")->fetchColumn();
    $num  = $last ? (int)substr($last, 3) + 1 : 1;
    $id   = 'LYN' . str_pad($num, 3, '0', STR_PAD_LEFT);

    $db->prepare("INSERT INTO layanan (id_layanan,nama_layanan,harga_perkg,estimasi_hari,deskripsi) VALUES (?,?,?,?,?)")
      ->execute([$id, $_POST['nama_layanan'], $_POST['harga_perkg'], $_POST['estimasi_hari'], $_POST['deskripsi']]);
    $msg = 'success|Layanan berhasil ditambahkan.';
  }
  if ($action === 'edit') {
    $db->prepare("UPDATE layanan SET nama_layanan=?,harga_perkg=?,estimasi_hari=?,deskripsi=? WHERE id_layanan=?")
      ->execute([$_POST['nama_layanan'], $_POST['harga_perkg'], $_POST['estimasi_hari'], $_POST['deskripsi'], $_POST['id']]);
    $msg = 'success|Layanan berhasil diperbarui.';
  }
  if ($action === 'hapus') {
    $db->prepare("DELETE FROM layanan WHERE id_layanan=?")->execute([$_POST['id']]);
    $msg = 'success|Layanan berhasil dihapus.';
  }
}

$layanan = $db->query("SELECT * FROM layanan ORDER BY nama_layanan")->fetchAll();
[$msgType, $msgText] = $msg ? explode('|', $msg, 2) : ['', ''];
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Kelola Layanan – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
</head>

<body>
  <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>
  <?php include __DIR__ . '/../partials/admin_topbar.php'; ?>

  <div class="main-content">
    <div class="page-content">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="fw-700 mb-0">Kelola Layanan</h5>
        <button class="btn btn-primary rounded-pill" data-bs-toggle="modal" data-bs-target="#modalTambah">
          <i class="bi bi-plus-lg me-1"></i>Tambah Layanan
        </button>
      </div>

      <?php if ($msgText): ?>
        <div class="alert alert-<?= $msgType === 'success' ? 'success' : 'danger' ?> alert-dismissible rounded-3">
          <?= htmlspecialchars($msgText) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>

      <div class="card">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table dt-table">
              <thead class="table-light">
                <tr>
                  <th>#</th>
                  <th>Nama Layanan</th>
                  <th>Harga/Kg</th>
                  <th>Estimasi</th>
                  <th>Deskripsi</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($layanan as $i => $l): ?>
                  <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= htmlspecialchars($l['nama_layanan']) ?></td>
                    <td><?= rupiah((float)$l['harga_perkg']) ?></td>
                    <td><?= $l['estimasi_hari'] ?> hari</td>
                    <td><?= htmlspecialchars(substr($l['deskripsi'] ?? '', 0, 50)) ?></td>
                    <td>
                      <button class="btn btn-sm btn-warning rounded-pill" onclick="editLayanan(<?= htmlspecialchars(json_encode($l)) ?>)"><i class="bi bi-pencil"></i></button>
                      <button class="btn btn-sm btn-danger rounded-pill" onclick="hapus('<?= $l['id_layanan'] ?>')"><i class="bi bi-trash"></i></button>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal Tambah -->
  <div class="modal fade" id="modalTambah" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content rounded-4">
        <form method="POST">
          <input type="hidden" name="action" value="tambah" />
          <div class="modal-header">
            <h5 class="modal-title">Tambah Layanan</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3"><label class="form-label">Nama Layanan</label><input type="text" name="nama_layanan" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">Harga per Kg (Rp)</label><input type="number" name="harga_perkg" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">Estimasi Hari</label><input type="number" name="estimasi_hari" class="form-control" value="2" /></div>
            <div class="mb-3"><label class="form-label">Deskripsi</label><textarea name="deskripsi" class="form-control" rows="2"></textarea></div>
          </div>
          <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button><button type="submit" class="btn btn-primary">Simpan</button></div>
        </form>
      </div>
    </div>
  </div>

  <!-- Modal Edit -->
  <div class="modal fade" id="modalEdit" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content rounded-4">
        <form method="POST">
          <input type="hidden" name="action" value="edit" />
          <input type="hidden" name="id" id="eId" />
          <div class="modal-header">
            <h5 class="modal-title">Edit Layanan</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3"><label class="form-label">Nama Layanan</label><input type="text" name="nama_layanan" id="eNama" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">Harga per Kg (Rp)</label><input type="number" name="harga_perkg" id="eHarga" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">Estimasi Hari</label><input type="number" name="estimasi_hari" id="eEst" class="form-control" /></div>
            <div class="mb-3"><label class="form-label">Deskripsi</label><textarea name="deskripsi" id="eDesk" class="form-control" rows="2"></textarea></div>
          </div>
          <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button><button type="submit" class="btn btn-primary">Perbarui</button></div>
        </form>
      </div>
    </div>
  </div>

  <form method="POST" id="fHapus" style="display:none"><input type="hidden" name="action" value="hapus" /><input type="hidden" name="id" id="hId" /></form>

  <?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
  <script>
    function editLayanan(l) {
      document.getElementById('eId').value = l.id_layanan;
      document.getElementById('eNama').value = l.nama_layanan;
      document.getElementById('eHarga').value = l.harga_perkg;
      document.getElementById('eEst').value = l.estimasi_hari;
      document.getElementById('eDesk').value = l.deskripsi || '';
      new bootstrap.Modal(document.getElementById('modalEdit')).show();
    }

    function hapus(id) {
      Swal.fire({
          title: 'Hapus layanan ini?',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonText: 'Hapus',
          confirmButtonColor: '#ef4444'
        })
        .then(r => {
          if (r.isConfirmed) {
            document.getElementById('hId').value = id;
            document.getElementById('fHapus').submit();
          }
        });
    }
  </script>
</body>

</html>