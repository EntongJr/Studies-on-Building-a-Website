<?php
// =============================================
//  ADMIN DASHBOARD
// =============================================

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/admin_only.php';
require_once __DIR__ . '/../includes/functions.php';

$user = currentUser();
$db   = getDB();

// Stats
$totalPelanggan = $db->query("SELECT COUNT(*) FROM pelanggan")->fetchColumn();
$totalPesanan   = $db->query("SELECT COUNT(*) FROM pesanan")->fetchColumn();
$totalLayanan   = $db->query("SELECT COUNT(*) FROM layanan")->fetchColumn();
$pendapatan     = $db->query("SELECT COALESCE(SUM(jumlah_bayar),0) FROM pembayaran")->fetchColumn();
$pesananHariIni = $db->query("SELECT COUNT(*) FROM pesanan WHERE DATE(tanggal_pesanan)=CURDATE()")->fetchColumn();
$keluhanBaru    = $db->query("SELECT COUNT(*) FROM keluhan WHERE status_keluhan='baru'")->fetchColumn();

// 5 pesanan terbaru
$pesananTerbaru = $db->query("
    SELECT p.id_pesanan, pl.nama_pelanggan, sp.nama_status,
           p.total_harga, p.tanggal_pesanan
    FROM pesanan p
    JOIN pelanggan pl ON p.id_pelanggan = pl.id_pelanggan
    JOIN status_pesanan sp ON p.id_status = sp.id_status
    ORDER BY p.tanggal_pesanan DESC LIMIT 8
")->fetchAll();

$activeNav = 'dashboard';
$pageTitle = 'Dashboard Admin';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title><?= $pageTitle ?> – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <i class="bi bi-basket2-fill icon"></i>
    <div>Bilqis Laundry<br><small style="font-size:.7rem;font-weight:400;opacity:.7">Panel Admin</small></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section">Utama</div>
    <a href="<?= BASE_URL ?>/admin/dashboard.php" class="<?= $activeNav==='dashboard'?'active':'' ?>">
      <i class="bi bi-grid-1x2"></i> Dashboard
    </a>
    <div class="nav-section">Kelola Data</div>
    <a href="<?= BASE_URL ?>/admin/pesanan.php"   class="<?= $activeNav==='pesanan'  ?'active':'' ?>"><i class="bi bi-bag-check"></i> Pesanan</a>
    <a href="<?= BASE_URL ?>/admin/pelanggan.php" class="<?= $activeNav==='pelanggan'?'active':'' ?>"><i class="bi bi-people"></i> Pelanggan</a>
    <a href="<?= BASE_URL ?>/admin/petugas.php"   class="<?= $activeNav==='petugas'  ?'active':'' ?>"><i class="bi bi-person-badge"></i> Petugas</a>
    <a href="<?= BASE_URL ?>/admin/layanan.php"   class="<?= $activeNav==='layanan'  ?'active':'' ?>"><i class="bi bi-tags"></i> Layanan</a>
    <a href="<?= BASE_URL ?>/admin/promo.php"     class="<?= $activeNav==='promo'    ?'active':'' ?>"><i class="bi bi-gift"></i> Promo</a>
    <a href="<?= BASE_URL ?>/admin/pembayaran.php"class="<?= $activeNav==='pembayaran'?'active':'' ?>"><i class="bi bi-cash-stack"></i> Pembayaran</a>
    <div class="nav-section">Lainnya</div>
    <a href="<?= BASE_URL ?>/admin/keluhan.php"   class="<?= $activeNav==='keluhan'  ?'active':'' ?>">
      <i class="bi bi-chat-dots"></i> Keluhan
      <?php if ($keluhanBaru > 0): ?>
        <span class="badge bg-danger ms-auto"><?= $keluhanBaru ?></span>
      <?php endif; ?>
    </a>
    <a href="<?= BASE_URL ?>/admin/laporan.php"   class="<?= $activeNav==='laporan'  ?'active':'' ?>"><i class="bi bi-bar-chart"></i> Laporan</a>
  </nav>
  <div class="sidebar-footer">
    <a href="<?= BASE_URL ?>/auth/logout.php"><i class="bi bi-box-arrow-left"></i> Logout</a>
  </div>
</div>

<!-- TOPBAR -->
<div class="topbar">
  <button class="btn btn-sm btn-light menu-toggle" id="menuToggle"><i class="bi bi-list fs-5"></i></button>
  <div class="d-flex align-items-center gap-3">
    <span class="text-muted" style="font-size:.85rem"><i class="bi bi-clock me-1"></i><?= date('d M Y') ?></span>
    <div class="d-flex align-items-center gap-2">
      <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,#0ea5e9,#0284c7);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:600;font-size:.9rem;">
        <?= strtoupper(substr($user['nama'],0,1)) ?>
      </div>
      <div style="font-size:.85rem">
        <div class="fw-600"><?= htmlspecialchars($user['nama']) ?></div>
        <div class="text-muted" style="font-size:.75rem">Administrator</div>
      </div>
    </div>
  </div>
</div>

<!-- MAIN -->
<div class="main-content">
  <div class="page-content">
    <h5 class="fw-700 mb-1">Dashboard</h5>
    <p class="text-muted mb-4" style="font-size:.85rem">Selamat datang, <?= htmlspecialchars($user['nama']) ?>!</p>

    <!-- STATS -->
    <div class="row g-3 mb-4">
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <div class="stat-icon" style="background:#e0f2fe;color:#0ea5e9"><i class="bi bi-bag-check"></i></div>
            <span class="badge bg-primary rounded-pill"><?= $pesananHariIni ?> hari ini</span>
          </div>
          <div class="stat-val"><?= $totalPesanan ?></div>
          <div class="stat-lbl">Total Pesanan</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <div class="stat-icon" style="background:#dcfce7;color:#16a34a"><i class="bi bi-people"></i></div>
          </div>
          <div class="stat-val"><?= $totalPelanggan ?></div>
          <div class="stat-lbl">Pelanggan</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <div class="stat-icon" style="background:#fef9c3;color:#ca8a04"><i class="bi bi-tags"></i></div>
          </div>
          <div class="stat-val"><?= $totalLayanan ?></div>
          <div class="stat-lbl">Layanan</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <div class="stat-icon" style="background:#fce7f3;color:#db2777"><i class="bi bi-cash-stack"></i></div>
          </div>
          <div class="stat-val" style="font-size:1.2rem"><?= rupiah((float)$pendapatan) ?></div>
          <div class="stat-lbl">Total Pendapatan</div>
        </div>
      </div>
    </div>

    <!-- RECENT ORDERS -->
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="mb-0 fw-600"><i class="bi bi-clock-history me-2 text-primary"></i>Pesanan Terbaru</h6>
        <a href="<?= BASE_URL ?>/admin/pesanan.php" class="btn btn-sm btn-outline-primary rounded-pill">Lihat Semua</a>
      </div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover mb-0">
            <thead class="table-light">
              <tr>
                <th>ID Pesanan</th>
                <th>Pelanggan</th>
                <th>Status</th>
                <th>Total</th>
                <th>Tanggal</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($pesananTerbaru as $p): ?>
              <tr>
                <td><code><?= htmlspecialchars($p['id_pesanan']) ?></code></td>
                <td><?= htmlspecialchars($p['nama_pelanggan']) ?></td>
                <td>
                  <?php
                  $s = $p['nama_status'];
                  $badge = match(true) {
                    str_contains($s,'Selesai') || str_contains($s,'Diambil') => 'success',
                    str_contains($s,'Diproses') || str_contains($s,'Dicuci') => 'primary',
                    str_contains($s,'Menunggu') => 'warning',
                    default => 'secondary'
                  };
                  ?>
                  <span class="badge bg-<?= $badge ?>"><?= htmlspecialchars($s) ?></span>
                </td>
                <td><?= $p['total_harga'] ? rupiah((float)$p['total_harga']) : '-' ?></td>
                <td><?= date('d M Y', strtotime($p['tanggal_pesanan'])) ?></td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($pesananTerbaru)): ?>
              <tr><td colspan="5" class="text-center text-muted py-4">Belum ada pesanan</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</div>

<?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
</body>
</html>
