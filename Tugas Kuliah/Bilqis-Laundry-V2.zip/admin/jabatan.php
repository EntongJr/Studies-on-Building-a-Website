<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/admin_only.php';
require_once __DIR__ . '/../includes/functions.php';

$db  = getDB();
$msg = '';
$activeNav = 'jabatan';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';

  if ($action === 'tambah') {
    $last = $db->query("SELECT id_jabatan FROM jabatan ORDER BY id_jabatan DESC LIMIT 1")->fetchColumn();
    $num  = $last ? (int)substr($last, 3) + 1 : 1;
    $id   = 'JBT' . str_pad($num, 3, '0', STR_PAD_LEFT);

    $db->prepare("INSERT INTO jabatan (id_jabatan,nama_jabatan) VALUES (?,?)")
      ->execute([$id, $_POST['nama_jabatan']]);
    $msg = 'success|Jabatan berhasil ditambahkan.';
  }

  if ($action === 'edit') {
    $db->prepare("UPDATE jabatan SET nama_jabatan=? WHERE id_jabatan=?")
      ->execute([$_POST['nama_jabatan'], $_POST['id']]);
    $msg = 'success|Jabatan berhasil diperbarui.';
  }

  if ($action === 'hapus') {
    // Cek apakah jabatan dipakai petugas
    $cek = $db->prepare("SELECT COUNT(*) FROM petugas WHERE id_jabatan=?");
    $cek->execute([$_POST['id']]);
    if ($cek->fetchColumn() > 0) {
      $msg = 'error|Jabatan tidak bisa dihapus karena masih digunakan oleh petugas.';
    } else {
      $db->prepare("DELETE FROM jabatan WHERE id_jabatan=?")->execute([$_POST['id']]);
      $msg = 'success|Jabatan berhasil dihapus.';
    }
  }
}

$jabatan = $db->query("
    SELECT j.*, COUNT(p.id_petugas) AS jumlah_petugas
    FROM jabatan j
    LEFT JOIN petugas p ON j.id_jabatan = p.id_jabatan
    GROUP BY j.id_jabatan
    ORDER BY j.nama_jabatan
")->fetchAll();

[$msgType, $msgText] = $msg ? explode('|', $msg, 2) : ['', ''];
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Kelola Jabatan – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
</head>

<body>
  <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>
  <?php include __DIR__ . '/../partials/admin_topbar.php'; ?>

  <div class="main-content">
    <div class="page-content">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h5 class="fw-700 mb-0">Kelola Jabatan</h5>
          <p class="text-muted mb-0" style="font-size:.85rem">Jabatan menentukan role login petugas</p>
        </div>
        <button class="btn btn-primary rounded-pill" data-bs-toggle="modal" data-bs-target="#modalTambah">
          <i class="bi bi-plus-lg me-1"></i>Tambah Jabatan
        </button>
      </div>

      <?php if ($msgText): ?>
        <div class="alert alert-<?= $msgType === 'success' ? 'success' : 'danger' ?> alert-dismissible rounded-3">
          <?= htmlspecialchars($msgText) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>

      <!-- Info role -->
      <div class="alert alert-info rounded-3 mb-4" style="font-size:.85rem">
        <i class="bi bi-info-circle me-1"></i>
        Jabatan dengan nama <strong>Admin</strong> akan diberikan akses penuh sebagai Administrator.
        Jabatan lainnya akan mendapat akses sebagai Petugas biasa.
      </div>

      <div class="card">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table dt-table">
              <thead class="table-light">
                <tr>
                  <th>#</th>
                  <th>ID Jabatan</th>
                  <th>Nama Jabatan</th>
                  <th>Role</th>
                  <th>Jumlah Petugas</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($jabatan as $i => $j):
                  $isAdmin = strtolower($j['nama_jabatan']) === 'admin';
                ?>
                  <tr>
                    <td><?= $i + 1 ?></td>
                    <td><code><?= htmlspecialchars($j['id_jabatan']) ?></code></td>
                    <td><?= htmlspecialchars($j['nama_jabatan']) ?></td>
                    <td>
                      <span class="badge bg-<?= $isAdmin ? 'danger' : 'primary' ?>">
                        <?= $isAdmin ? 'Admin' : 'Petugas' ?>
                      </span>
                    </td>
                    <td>
                      <span class="badge bg-secondary"><?= $j['jumlah_petugas'] ?> petugas</span>
                    </td>
                    <td>
                      <button class="btn btn-sm btn-warning rounded-pill"
                        onclick="editJabatan('<?= $j['id_jabatan'] ?>','<?= htmlspecialchars($j['nama_jabatan']) ?>')">
                        <i class="bi bi-pencil"></i>
                      </button>
                      <?php if ($j['jumlah_petugas'] == 0): ?>
                        <button class="btn btn-sm btn-danger rounded-pill" onclick="hapus('<?= $j['id_jabatan'] ?>')">
                          <i class="bi bi-trash"></i>
                        </button>
                      <?php else: ?>
                        <button class="btn btn-sm btn-outline-secondary rounded-pill" disabled title="Masih digunakan">
                          <i class="bi bi-trash"></i>
                        </button>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal Tambah -->
  <div class="modal fade" id="modalTambah" tabindex="-1">
    <div class="modal-dialog modal-sm">
      <div class="modal-content rounded-4">
        <form method="POST">
          <input type="hidden" name="action" value="tambah" />
          <div class="modal-header">
            <h5 class="modal-title">Tambah Jabatan</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <label class="form-label">Nama Jabatan</label>
            <input type="text" name="nama_jabatan" class="form-control" placeholder="cth: Petugas Cuci" required />
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-primary">Simpan</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Modal Edit -->
  <div class="modal fade" id="modalEdit" tabindex="-1">
    <div class="modal-dialog modal-sm">
      <div class="modal-content rounded-4">
        <form method="POST">
          <input type="hidden" name="action" value="edit" />
          <input type="hidden" name="id" id="eId" />
          <div class="modal-header">
            <h5 class="modal-title">Edit Jabatan</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <label class="form-label">Nama Jabatan</label>
            <input type="text" name="nama_jabatan" id="eNama" class="form-control" required />
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-primary">Perbarui</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <form method="POST" id="fHapus" style="display:none">
    <input type="hidden" name="action" value="hapus" />
    <input type="hidden" name="id" id="hId" />
  </form>

  <?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
  <script>
    function editJabatan(id, nama) {
      document.getElementById('eId').value = id;
      document.getElementById('eNama').value = nama;
      new bootstrap.Modal(document.getElementById('modalEdit')).show();
    }

    function hapus(id) {
      Swal.fire({
        title: 'Hapus jabatan ini?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Hapus',
        confirmButtonColor: '#ef4444'
      }).then(r => {
        if (r.isConfirmed) {
          document.getElementById('hId').value = id;
          document.getElementById('fHapus').submit();
        }
      });
    }
  </script>
</body>

</html>