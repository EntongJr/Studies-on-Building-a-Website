<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/admin_only.php';
require_once __DIR__ . '/../includes/functions.php';

$db  = getDB();
$msg = '';
$activeNav = 'promo';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  if ($action === 'tambah') {
    $last = $db->query("SELECT id_promo FROM promo ORDER BY id_promo DESC LIMIT 1")->fetchColumn();
    $num  = $last ? (int)substr($last, 3) + 1 : 1;
    $id   = 'PRO' . str_pad($num, 3, '0', STR_PAD_LEFT);

    $db->prepare("INSERT INTO promo (id_promo,nama_promo,diskon,tanggal_mulai,tanggal_selesai) VALUES (?,?,?,?,?)")
      ->execute([$id, $_POST['nama_promo'], $_POST['diskon'], $_POST['tanggal_mulai'], $_POST['tanggal_selesai']]);
    $msg = 'success|Promo berhasil ditambahkan.';
  }
  if ($action === 'edit') {
    $db->prepare("UPDATE promo SET nama_promo=?,diskon=?,tanggal_mulai=?,tanggal_selesai=? WHERE id_promo=?")
      ->execute([$_POST['nama_promo'], $_POST['diskon'], $_POST['tanggal_mulai'], $_POST['tanggal_selesai'], $_POST['id']]);
    $msg = 'success|Promo berhasil diperbarui.';
  }
  if ($action === 'hapus') {
    $db->prepare("DELETE FROM promo WHERE id_promo=?")->execute([$_POST['id']]);
    $msg = 'success|Promo berhasil dihapus.';
  }
}

$promos = $db->query("SELECT * FROM promo ORDER BY tanggal_mulai DESC")->fetchAll();
[$msgType, $msgText] = $msg ? explode('|', $msg, 2) : ['', ''];
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Kelola Promo – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
</head>

<body>
  <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>
  <?php include __DIR__ . '/../partials/admin_topbar.php'; ?>

  <div class="main-content">
    <div class="page-content">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="fw-700 mb-0">Kelola Promo</h5>
        <button class="btn btn-primary rounded-pill" data-bs-toggle="modal" data-bs-target="#modalTambah">
          <i class="bi bi-plus-lg me-1"></i>Tambah Promo
        </button>
      </div>

      <?php if ($msgText): ?>
        <div class="alert alert-<?= $msgType === 'success' ? 'success' : 'danger' ?> alert-dismissible rounded-3">
          <?= htmlspecialchars($msgText) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>

      <div class="card">
        <div class="card-body">
          <table class="table dt-table">
            <thead class="table-light">
              <tr>
                <th>#</th>
                <th>Nama Promo</th>
                <th>Diskon (%)</th>
                <th>Mulai</th>
                <th>Selesai</th>
                <th>Status</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($promos as $i => $p):
                $now   = date('Y-m-d');
                $aktif = $now >= $p['tanggal_mulai'] && $now <= $p['tanggal_selesai'];
              ?>
                <tr>
                  <td><?= $i + 1 ?></td>
                  <td><?= htmlspecialchars($p['nama_promo']) ?></td>
                  <td><?= $p['diskon'] ?>%</td>
                  <td><?= date('d M Y', strtotime($p['tanggal_mulai'])) ?></td>
                  <td><?= date('d M Y', strtotime($p['tanggal_selesai'])) ?></td>
                  <td><span class="badge bg-<?= $aktif ? 'success' : 'secondary' ?>"><?= $aktif ? 'Aktif' : 'Tidak Aktif' ?></span></td>
                  <td>
                    <button class="btn btn-sm btn-warning rounded-pill" onclick="editPromo(<?= htmlspecialchars(json_encode($p)) ?>)"><i class="bi bi-pencil"></i></button>
                    <button class="btn btn-sm btn-danger rounded-pill" onclick="hapus('<?= $p['id_promo'] ?>')"><i class="bi bi-trash"></i></button>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="modalTambah" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content rounded-4">
        <form method="POST">
          <input type="hidden" name="action" value="tambah" />
          <div class="modal-header">
            <h5 class="modal-title">Tambah Promo</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3"><label class="form-label">Nama Promo</label><input type="text" name="nama_promo" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">Diskon (%)</label><input type="number" name="diskon" step="0.01" min="0" max="100" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">Tanggal Mulai</label><input type="date" name="tanggal_mulai" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">Tanggal Selesai</label><input type="date" name="tanggal_selesai" class="form-control" required /></div>
          </div>
          <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button><button type="submit" class="btn btn-primary">Simpan</button></div>
        </form>
      </div>
    </div>
  </div>

  <div class="modal fade" id="modalEdit" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content rounded-4">
        <form method="POST">
          <input type="hidden" name="action" value="edit" />
          <input type="hidden" name="id" id="eId" />
          <div class="modal-header">
            <h5 class="modal-title">Edit Promo</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3"><label class="form-label">Nama Promo</label><input type="text" name="nama_promo" id="eNama" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">Diskon (%)</label><input type="number" name="diskon" id="eDiskon" step="0.01" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">Tanggal Mulai</label><input type="date" name="tanggal_mulai" id="eMulai" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">Tanggal Selesai</label><input type="date" name="tanggal_selesai" id="eSelesai" class="form-control" required /></div>
          </div>
          <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button><button type="submit" class="btn btn-primary">Perbarui</button></div>
        </form>
      </div>
    </div>
  </div>

  <form method="POST" id="fHapus" style="display:none"><input type="hidden" name="action" value="hapus" /><input type="hidden" name="id" id="hId" /></form>

  <?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
  <script>
    function editPromo(p) {
      document.getElementById('eId').value = p.id_promo;
      document.getElementById('eNama').value = p.nama_promo;
      document.getElementById('eDiskon').value = p.diskon;
      document.getElementById('eMulai').value = p.tanggal_mulai;
      document.getElementById('eSelesai').value = p.tanggal_selesai;
      new bootstrap.Modal(document.getElementById('modalEdit')).show();
    }

    function hapus(id) {
      Swal.fire({
          title: 'Hapus promo ini?',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonText: 'Hapus',
          confirmButtonColor: '#ef4444'
        })
        .then(r => {
          if (r.isConfirmed) {
            document.getElementById('hId').value = id;
            document.getElementById('fHapus').submit();
          }
        });
    }
  </script>
</body>

</html>