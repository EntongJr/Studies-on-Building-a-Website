<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/admin_only.php';
require_once __DIR__ . '/../includes/functions.php';

$db  = getDB();
$msg = '';
$activeNav = 'petugas';
$curUser = currentUser();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';

  if ($action === 'tambah') {
    $last = $db->query("SELECT id_petugas FROM petugas ORDER BY id_petugas DESC LIMIT 1")->fetchColumn();
    $num  = $last ? (int)substr($last, 3) + 1 : 1;
    $id   = 'PTG' . str_pad($num, 3, '0', STR_PAD_LEFT);

    $hash = password_hash($_POST['sandi'], PASSWORD_DEFAULT);
    $db->prepare("INSERT INTO petugas (id_petugas,id_jabatan,nama_petugas,email,sandi,no_telepon,alamat,gaji) VALUES (?,?,?,?,?,?,?,?)")
      ->execute([$id, $_POST['id_jabatan'], $_POST['nama_petugas'], $_POST['email'], $hash, $_POST['no_telepon'], $_POST['alamat'], $_POST['gaji']]);
    $msg = 'success|Petugas berhasil ditambahkan.';
  }
  if ($action === 'edit') {
    $db->prepare("UPDATE petugas SET id_jabatan=?,nama_petugas=?,email=?,no_telepon=?,alamat=?,gaji=? WHERE id_petugas=?")
      ->execute([$_POST['id_jabatan'], $_POST['nama_petugas'], $_POST['email'], $_POST['no_telepon'], $_POST['alamat'], $_POST['gaji'], $_POST['id']]);
    if (!empty($_POST['sandi'])) {
      $db->prepare("UPDATE petugas SET sandi=? WHERE id_petugas=?")
        ->execute([password_hash($_POST['sandi'], PASSWORD_DEFAULT), $_POST['id']]);
    }
    $msg = 'success|Data petugas berhasil diperbarui.';
  }
  if ($action === 'hapus') {
    // Tidak boleh hapus diri sendiri
    if ($_POST['id'] === $curUser['id']) {
      $msg = 'error|Tidak bisa menghapus akun sendiri.';
    } else {
      $db->prepare("DELETE FROM petugas WHERE id_petugas=?")->execute([$_POST['id']]);
      $msg = 'success|Petugas berhasil dihapus.';
    }
  }
}

$petugasList = $db->query("SELECT p.*,j.nama_jabatan FROM petugas p JOIN jabatan j ON p.id_jabatan=j.id_jabatan ORDER BY p.nama_petugas")->fetchAll();
$jabatanList = $db->query("SELECT * FROM jabatan ORDER BY nama_jabatan")->fetchAll();
[$msgType, $msgText] = $msg ? explode('|', $msg, 2) : ['', ''];
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Kelola Petugas – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
</head>

<body>
  <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>
  <?php include __DIR__ . '/../partials/admin_topbar.php'; ?>

  <div class="main-content">
    <div class="page-content">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="fw-700 mb-0">Kelola Petugas</h5>
        <button class="btn btn-primary rounded-pill" data-bs-toggle="modal" data-bs-target="#modalTambah">
          <i class="bi bi-plus-lg me-1"></i>Tambah Petugas
        </button>
      </div>

      <?php if ($msgText): ?>
        <div class="alert alert-<?= $msgType === 'success' ? 'success' : 'danger' ?> alert-dismissible rounded-3">
          <?= htmlspecialchars($msgText) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>

      <div class="card">
        <div class="card-body">
          <table class="table dt-table">
            <thead class="table-light">
              <tr>
                <th>#</th>
                <th>Nama</th>
                <th>Jabatan</th>
                <th>Email</th>
                <th>No. Telp</th>
                <th>Gaji</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($petugasList as $i => $p): ?>
                <tr>
                  <td><?= $i + 1 ?></td>
                  <td><?= htmlspecialchars($p['nama_petugas']) ?></td>
                  <td><span class="badge bg-<?= strtolower($p['nama_jabatan']) === 'admin' ? 'danger' : 'primary' ?>"><?= htmlspecialchars($p['nama_jabatan']) ?></span></td>
                  <td><?= htmlspecialchars($p['email']) ?></td>
                  <td><?= htmlspecialchars($p['no_telepon'] ?? '-') ?></td>
                  <td><?= $p['gaji'] ? rupiah((float)$p['gaji']) : '-' ?></td>
                  <td>
                    <button class="btn btn-sm btn-warning rounded-pill" onclick="editPetugas(<?= htmlspecialchars(json_encode($p)) ?>)"><i class="bi bi-pencil"></i></button>
                    <?php if ($p['id_petugas'] !== $curUser['id']): ?>
                      <button class="btn btn-sm btn-danger rounded-pill" onclick="hapus('<?= $p['id_petugas'] ?>')"><i class="bi bi-trash"></i></button>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal Tambah -->
  <div class="modal fade" id="modalTambah" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content rounded-4">
        <form method="POST">
          <input type="hidden" name="action" value="tambah" />
          <div class="modal-header">
            <h5 class="modal-title">Tambah Petugas</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3"><label class="form-label">Jabatan</label>
              <select name="id_jabatan" class="form-select" required>
                <?php foreach ($jabatanList as $j): ?><option value="<?= $j['id_jabatan'] ?>"><?= htmlspecialchars($j['nama_jabatan']) ?></option><?php endforeach; ?>
              </select>
            </div>
            <div class="mb-3"><label class="form-label">Nama Petugas</label><input type="text" name="nama_petugas" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">No. Telepon</label><input type="text" name="no_telepon" class="form-control" /></div>
            <div class="mb-3"><label class="form-label">Alamat</label><textarea name="alamat" class="form-control" rows="2"></textarea></div>
            <div class="mb-3"><label class="form-label">Gaji</label><input type="number" name="gaji" class="form-control" /></div>
            <div class="mb-3"><label class="form-label">Password</label><input type="password" name="sandi" class="form-control" required /></div>
          </div>
          <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button><button type="submit" class="btn btn-primary">Simpan</button></div>
        </form>
      </div>
    </div>
  </div>

  <!-- Modal Edit -->
  <div class="modal fade" id="modalEdit" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content rounded-4">
        <form method="POST">
          <input type="hidden" name="action" value="edit" />
          <input type="hidden" name="id" id="eId" />
          <div class="modal-header">
            <h5 class="modal-title">Edit Petugas</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3"><label class="form-label">Jabatan</label>
              <select name="id_jabatan" id="eJabatan" class="form-select">
                <?php foreach ($jabatanList as $j): ?><option value="<?= $j['id_jabatan'] ?>"><?= htmlspecialchars($j['nama_jabatan']) ?></option><?php endforeach; ?>
              </select>
            </div>
            <div class="mb-3"><label class="form-label">Nama Petugas</label><input type="text" name="nama_petugas" id="eNama" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" id="eEmail" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">No. Telepon</label><input type="text" name="no_telepon" id="eTelp" class="form-control" /></div>
            <div class="mb-3"><label class="form-label">Alamat</label><textarea name="alamat" id="eAlamat" class="form-control" rows="2"></textarea></div>
            <div class="mb-3"><label class="form-label">Gaji</label><input type="number" name="gaji" id="eGaji" class="form-control" /></div>
            <div class="mb-3"><label class="form-label">Password Baru <small class="text-muted">(kosongkan jika tidak diubah)</small></label><input type="password" name="sandi" class="form-control" /></div>
          </div>
          <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button><button type="submit" class="btn btn-primary">Perbarui</button></div>
        </form>
      </div>
    </div>
  </div>

  <form method="POST" id="fHapus" style="display:none"><input type="hidden" name="action" value="hapus" /><input type="hidden" name="id" id="hId" /></form>

  <?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
  <script>
    function editPetugas(p) {
      document.getElementById('eId').value = p.id_petugas;
      document.getElementById('eJabatan').value = p.id_jabatan;
      document.getElementById('eNama').value = p.nama_petugas;
      document.getElementById('eEmail').value = p.email;
      document.getElementById('eTelp').value = p.no_telepon || '';
      document.getElementById('eAlamat').value = p.alamat || '';
      document.getElementById('eGaji').value = p.gaji || '';
      new bootstrap.Modal(document.getElementById('modalEdit')).show();
    }

    function hapus(id) {
      Swal.fire({
          title: 'Hapus petugas ini?',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonText: 'Hapus',
          confirmButtonColor: '#ef4444'
        })
        .then(r => {
          if (r.isConfirmed) {
            document.getElementById('hId').value = id;
            document.getElementById('fHapus').submit();
          }
        });
    }
  </script>
</body>

</html>