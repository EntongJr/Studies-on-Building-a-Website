<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/admin_only.php';
require_once __DIR__ . '/../includes/functions.php';

$db  = getDB();
$activeNav = 'pembayaran';
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  if ($action === 'tambah') {
    $last = $db->query("SELECT id_pembayaran FROM pembayaran ORDER BY id_pembayaran DESC LIMIT 1")->fetchColumn();
    $num  = $last ? (int)substr($last, 3) + 1 : 1;
    $id   = 'PAY' . str_pad($num, 3, '0', STR_PAD_LEFT);

    $db->prepare("INSERT INTO pembayaran (id_pembayaran,id_pesanan,id_metode,tanggal_bayar,jumlah_bayar) VALUES (?,?,?,NOW(),?)")
      ->execute([$id, $_POST['id_pesanan'], $_POST['id_metode'], $_POST['jumlah_bayar']]);
    // Update status_pembayaran di pesanan
    $db->prepare("UPDATE pesanan SET status_pembayaran='Lunas' WHERE id_pesanan=?")
      ->execute([$_POST['id_pesanan']]);
    $msg = 'success|Pembayaran berhasil dicatat.';
  }

  if ($action === 'update_status') {

    $status = $_POST['status_pembayaran'];
    $idPesanan = $_POST['id_pesanan'];

    $db->prepare("UPDATE pesanan SET status_pembayaran=? WHERE id_pesanan=?")
      ->execute([$status, $idPesanan]);

    $msg = 'success|Status pembayaran berhasil diperbarui.';
  }

  if ($action === 'hapus') {
    $db->prepare("DELETE FROM pembayaran WHERE id_pembayaran=?")->execute([$_POST['id']]);
    $msg = 'success|Pembayaran berhasil dihapus.';
  }
}

$pembayaran = $db->query("
    SELECT py.*, pl.nama_pelanggan, mp.nama_metode, p.status_pembayaran
    FROM pembayaran py
    JOIN pesanan p ON py.id_pesanan = p.id_pesanan
    JOIN pelanggan pl ON p.id_pelanggan = pl.id_pelanggan
    JOIN metode_pembayaran mp ON py.id_metode = mp.id_metode
    ORDER BY py.tanggal_bayar DESC
")->fetchAll();

$metodePembayaran = $db->query("SELECT * FROM metode_pembayaran")->fetchAll();
$pesananBelumBayar = $db->query("
    SELECT p.id_pesanan, pl.nama_pelanggan, p.total_harga
    FROM pesanan p
    JOIN pelanggan pl ON p.id_pelanggan=pl.id_pelanggan
    WHERE p.status_pembayaran='Belum Lunas' OR p.status_pembayaran IS NULL OR p.status_pembayaran=''
    ORDER BY p.tanggal_pesanan DESC
")->fetchAll();

[$msgType, $msgText] = $msg ? explode('|', $msg, 2) : ['', ''];
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Pembayaran – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
</head>

<body>
  <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>
  <?php include __DIR__ . '/../partials/admin_topbar.php'; ?>

  <div class="main-content">
    <div class="page-content">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="fw-700 mb-0">Kelola Pembayaran</h5>
        <button class="btn btn-primary rounded-pill" data-bs-toggle="modal" data-bs-target="#modalTambah">
          <i class="bi bi-plus-lg me-1"></i>Catat Pembayaran
        </button>
      </div>

      <?php if ($msgText): ?>
        <div class="alert alert-<?= $msgType === 'success' ? 'success' : 'danger' ?> alert-dismissible rounded-3">
          <?= htmlspecialchars($msgText) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>

      <div class="card">
        <div class="card-body">
          <table class="table dt-table">
            <thead class="table-light">
              <tr>
                <th>#</th>
                <th>ID Bayar</th>
                <th>Pesanan</th>
                <th>Pelanggan</th>
                <th>Metode</th>
                <th>Jumlah</th>
                <th>Tanggal</th>
                <th>Status</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($pembayaran as $i => $p): ?>
                <tr>
                  <td><?= $i + 1 ?></td>
                  <td><code><?= htmlspecialchars($p['id_pembayaran']) ?></code></td>
                  <td><code><?= htmlspecialchars($p['id_pesanan']) ?></code></td>
                  <td><?= htmlspecialchars($p['nama_pelanggan']) ?></td>
                  <td><span class="badge bg-info text-dark"><?= htmlspecialchars($p['nama_metode']) ?></span></td>
                  <td><?= rupiah((float)$p['jumlah_bayar']) ?></td>
                  <td><?= date('d M Y H:i', strtotime($p['tanggal_bayar'])) ?></td>
                  <td>
                    <?php if ($p['status_pembayaran'] == 'Lunas'): ?>
                      <span class="badge bg-success">Lunas</span>
                    <?php else: ?>
                      <span class="badge bg-danger">Belum Lunas</span>
                    <?php endif; ?>
                  </td>
                  <td class="d-flex gap-1">

                    <button
                      class="btn btn-sm btn-warning rounded-pill"
                      onclick="editStatus('<?= $p['id_pesanan'] ?>','<?= $p['status_pembayaran'] ?>')">
                      <i class="bi bi-pencil-square"></i>
                    </button>

                    <button class="btn btn-sm btn-danger rounded-pill"
                      onclick="hapus('<?= $p['id_pembayaran'] ?>')">
                      <i class="bi bi-trash"></i>
                    </button>

                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="modalTambah" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content rounded-4">
        <form method="POST">
          <input type="hidden" name="action" value="tambah" />
          <div class="modal-header">
            <h5 class="modal-title">Catat Pembayaran</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3"><label class="form-label">Pesanan</label>
              <select name="id_pesanan" class="form-select" required>
                <option value="">-- Pilih Pesanan --</option>
                <?php foreach ($pesananBelumBayar as $p): ?>
                  <option value="<?= $p['id_pesanan'] ?>"><?= htmlspecialchars($p['id_pesanan'] . ' – ' . $p['nama_pelanggan']) ?> (<?= rupiah((float)$p['total_harga']) ?>)</option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="mb-3"><label class="form-label">Metode Pembayaran</label>
              <select name="id_metode" class="form-select" required>
                <?php foreach ($metodePembayaran as $m): ?>
                  <option value="<?= $m['id_metode'] ?>"><?= htmlspecialchars($m['nama_metode']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="mb-3"><label class="form-label">Jumlah Bayar (Rp)</label><input type="number" name="jumlah_bayar" class="form-control" required /></div>
          </div>
          <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button><button type="submit" class="btn btn-primary">Simpan</button></div>
        </form>
      </div>
    </div>
  </div>

  <form method="POST" id="fHapus" style="display:none"><input type="hidden" name="action" value="hapus" /><input type="hidden" name="id" id="hId" /></form>

  <div class="modal fade" id="modalStatus" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content rounded-4">

        <form method="POST">

          <input type="hidden" name="action" value="update_status">
          <input type="hidden" name="id_pesanan" id="edit_id_pesanan">

          <div class="modal-header">
            <h5 class="modal-title">Edit Status Pembayaran</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>

          <div class="modal-body">

            <label class="form-label">Status Pembayaran</label>

            <select name="status_pembayaran" id="edit_status" class="form-select">
              <option value="Lunas">Lunas</option>
              <option value="Belum Lunas">Belum Lunas</option>
            </select>

          </div>

          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">
              Simpan
            </button>
          </div>

        </form>

      </div>
    </div>
  </div>

  <?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
  <script>
    function hapus(id) {
      Swal.fire({
          title: 'Hapus data pembayaran?',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonText: 'Hapus',
          confirmButtonColor: '#ef4444'
        })
        .then(r => {
          if (r.isConfirmed) {
            document.getElementById('hId').value = id;
            document.getElementById('fHapus').submit();
          }
        });
    }

    function editStatus(idPesanan, status) {

      document.getElementById('edit_id_pesanan').value = idPesanan;
      document.getElementById('edit_status').value = status;

      let modal = new bootstrap.Modal(
        document.getElementById('modalStatus')
      );

      modal.show();
    }
  </script>
</body>

</html>