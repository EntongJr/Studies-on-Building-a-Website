<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/admin_only.php';
require_once __DIR__ . '/../includes/functions.php';

$db   = getDB();
$msg  = '';
$activeNav = 'pelanggan';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';

  if ($action === 'tambah') {
    $last = $db->query("SELECT id_pelanggan FROM pelanggan ORDER BY id_pelanggan DESC LIMIT 1")->fetchColumn();
    $num  = $last ? (int)substr($last, 3) + 1 : 1;
    $id   = 'PLG' . str_pad($num, 3, '0', STR_PAD_LEFT);

    $hash  = password_hash($_POST['sandi'], PASSWORD_DEFAULT);
    $stmt  = $db->prepare("INSERT INTO pelanggan (id_pelanggan,nama_pelanggan,email,sandi,no_telepon,alamat) VALUES (?,?,?,?,?,?)");
    $stmt->execute([$id, $_POST['nama_pelanggan'], $_POST['email'], $hash, $_POST['no_telepon'], $_POST['alamat']]);
    $msg = 'success|Pelanggan berhasil ditambahkan.';
  }

  if ($action === 'edit') {
    $stmt = $db->prepare("UPDATE pelanggan SET nama_pelanggan=?,email=?,no_telepon=?,alamat=? WHERE id_pelanggan=?");
    $stmt->execute([$_POST['nama_pelanggan'], $_POST['email'], $_POST['no_telepon'], $_POST['alamat'], $_POST['id']]);
    if (!empty($_POST['sandi'])) {
      $db->prepare("UPDATE pelanggan SET sandi=? WHERE id_pelanggan=?")
        ->execute([password_hash($_POST['sandi'], PASSWORD_DEFAULT), $_POST['id']]);
    }
    $msg = 'success|Data pelanggan berhasil diperbarui.';
  }

  if ($action === 'hapus') {
    $db->prepare("DELETE FROM pelanggan WHERE id_pelanggan=?")->execute([$_POST['id']]);
    $msg = 'success|Pelanggan berhasil dihapus.';
  }
}

$pelanggan = $db->query("SELECT * FROM pelanggan ORDER BY nama_pelanggan")->fetchAll();
[$msgType, $msgText] = $msg ? explode('|', $msg, 2) : ['', ''];
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Kelola Pelanggan – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
</head>

<body>
  <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>
  <?php include __DIR__ . '/../partials/admin_topbar.php'; ?>

  <div class="main-content">
    <div class="page-content">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h5 class="fw-700 mb-0">Kelola Pelanggan</h5>
          <p class="text-muted mb-0" style="font-size:.85rem">Total: <?= count($pelanggan) ?> pelanggan</p>
        </div>
        <button class="btn btn-primary rounded-pill" data-bs-toggle="modal" data-bs-target="#modalTambah">
          <i class="bi bi-plus-lg me-1"></i>Tambah Pelanggan
        </button>
      </div>

      <?php if ($msgText): ?>
        <div class="alert alert-<?= $msgType === 'success' ? 'success' : 'danger' ?> alert-dismissible rounded-3">
          <?= htmlspecialchars($msgText) ?>
          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>

      <div class="card">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table dt-table">
              <thead class="table-light">
                <tr>
                  <th>#</th>
                  <th>Nama</th>
                  <th>Email</th>
                  <th>No. Telepon</th>
                  <th>Alamat</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($pelanggan as $i => $p): ?>
                  <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= htmlspecialchars($p['nama_pelanggan']) ?></td>
                    <td><?= htmlspecialchars($p['email']) ?></td>
                    <td><?= htmlspecialchars($p['no_telepon'] ?? '-') ?></td>
                    <td><?= htmlspecialchars(substr($p['alamat'] ?? '-', 0, 40)) ?></td>
                    <td>
                      <button class="btn btn-sm btn-warning rounded-pill" onclick="editPelanggan(<?= htmlspecialchars(json_encode($p)) ?>)">
                        <i class="bi bi-pencil"></i>
                      </button>
                      <button class="btn btn-sm btn-danger rounded-pill" onclick="hapusPelanggan('<?= $p['id_pelanggan'] ?>')">
                        <i class="bi bi-trash"></i>
                      </button>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal Tambah -->
  <div class="modal fade" id="modalTambah" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content rounded-4">
        <form method="POST">
          <input type="hidden" name="action" value="tambah" />
          <div class="modal-header">
            <h5 class="modal-title">Tambah Pelanggan</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3"><label class="form-label">Nama Lengkap</label><input type="text" name="nama_pelanggan" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">No. Telepon</label><input type="text" name="no_telepon" class="form-control" /></div>
            <div class="mb-3"><label class="form-label">Alamat</label><textarea name="alamat" class="form-control" rows="2"></textarea></div>
            <div class="mb-3"><label class="form-label">Password</label><input type="password" name="sandi" class="form-control" required /></div>
          </div>
          <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button><button type="submit" class="btn btn-primary">Simpan</button></div>
        </form>
      </div>
    </div>
  </div>

  <!-- Modal Edit -->
  <div class="modal fade" id="modalEdit" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content rounded-4">
        <form method="POST">
          <input type="hidden" name="action" value="edit" />
          <input type="hidden" name="id" id="editId" />
          <div class="modal-header">
            <h5 class="modal-title">Edit Pelanggan</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3"><label class="form-label">Nama Lengkap</label><input type="text" name="nama_pelanggan" id="editNama" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" id="editEmail" class="form-control" required /></div>
            <div class="mb-3"><label class="form-label">No. Telepon</label><input type="text" name="no_telepon" id="editTelp" class="form-control" /></div>
            <div class="mb-3"><label class="form-label">Alamat</label><textarea name="alamat" id="editAlamat" class="form-control" rows="2"></textarea></div>
            <div class="mb-3"><label class="form-label">Password Baru <small class="text-muted">(kosongkan jika tidak diubah)</small></label><input type="password" name="sandi" class="form-control" /></div>
          </div>
          <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button><button type="submit" class="btn btn-primary">Perbarui</button></div>
        </form>
      </div>
    </div>
  </div>

  <!-- Form hapus -->
  <form method="POST" id="formHapus" style="display:none">
    <input type="hidden" name="action" value="hapus" />
    <input type="hidden" name="id" id="hapusId" />
  </form>

  <?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
  <script>
    function editPelanggan(p) {
      document.getElementById('editId').value = p.id_pelanggan;
      document.getElementById('editNama').value = p.nama_pelanggan;
      document.getElementById('editEmail').value = p.email;
      document.getElementById('editTelp').value = p.no_telepon || '';
      document.getElementById('editAlamat').value = p.alamat || '';
      new bootstrap.Modal(document.getElementById('modalEdit')).show();
    }

    function hapusPelanggan(id) {
      Swal.fire({
        title: 'Hapus pelanggan ini?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, hapus!',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#ef4444'
      }).then(r => {
        if (r.isConfirmed) {
          document.getElementById('hapusId').value = id;
          document.getElementById('formHapus').submit();
        }
      });
    }
  </script>
</body>

</html>