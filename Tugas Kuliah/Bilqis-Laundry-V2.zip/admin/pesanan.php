<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/admin_only.php';
require_once __DIR__ . '/../includes/functions.php';

$db  = getDB();
$msg = '';
$activeNav = 'pesanan';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'update_status') {
        $db->prepare("UPDATE pesanan SET id_status=? WHERE id_pesanan=?")
           ->execute([$_POST['id_status'], $_POST['id_pesanan']]);
        $msg = 'success|Status pesanan berhasil diperbarui.';
    }
    if ($action === 'hapus') {
        $db->prepare("DELETE FROM detail_pesanan WHERE id_pesanan=?")->execute([$_POST['id']]);
        $db->prepare("DELETE FROM pembayaran WHERE id_pesanan=?")->execute([$_POST['id']]);
        $db->prepare("DELETE FROM keluhan WHERE id_pesanan=?")->execute([$_POST['id']]);
        $db->prepare("DELETE FROM pesanan WHERE id_pesanan=?")->execute([$_POST['id']]);
        $msg = 'success|Pesanan berhasil dihapus.';
    }
}

$pesanan = $db->query("
    SELECT p.*, pl.nama_pelanggan, pt.nama_petugas, sp.nama_status
    FROM pesanan p
    LEFT JOIN pelanggan pl ON p.id_pelanggan = pl.id_pelanggan
    LEFT JOIN petugas pt ON p.id_petugas = pt.id_petugas
    LEFT JOIN status_pesanan sp ON p.id_status = sp.id_status
    ORDER BY p.tanggal_pesanan DESC
")->fetchAll();

$statusList = $db->query("SELECT * FROM status_pesanan ORDER BY id_status")->fetchAll();
[$msgType,$msgText] = $msg ? explode('|',$msg,2) : ['',''];

function statusBadge(string $s): string {
    return match(true) {
        str_contains($s,'Selesai') || str_contains($s,'Diambil') => 'success',
        str_contains($s,'Diproses') || str_contains($s,'Dicuci') || str_contains($s,'Setrika') => 'primary',
        str_contains($s,'Menunggu') => 'warning',
        default => 'secondary'
    };
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Kelola Pesanan – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>
<?php include __DIR__ . '/../partials/admin_topbar.php'; ?>

<div class="main-content"><div class="page-content">
  <h5 class="fw-700 mb-4">Kelola Pesanan</h5>

  <?php if ($msgText): ?>
    <div class="alert alert-<?= $msgType==='success'?'success':'danger' ?> alert-dismissible rounded-3">
      <?= htmlspecialchars($msgText) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <div class="card"><div class="card-body">
    <div class="table-responsive">
      <table class="table dt-table">
        <thead class="table-light">
          <tr><th>#</th><th>ID Pesanan</th><th>Pelanggan</th><th>Petugas</th><th>Status</th><th>Total</th><th>Tanggal</th><th>Aksi</th></tr>
        </thead>
        <tbody>
          <?php foreach ($pesanan as $i => $p): ?>
          <tr>
            <td><?= $i+1 ?></td>
            <td><code><?= htmlspecialchars($p['id_pesanan']) ?></code></td>
            <td><?= htmlspecialchars($p['nama_pelanggan'] ?? '-') ?></td>
            <td><?= htmlspecialchars($p['nama_petugas'] ?? '-') ?></td>
            <td><span class="badge bg-<?= statusBadge($p['nama_status']??'') ?>"><?= htmlspecialchars($p['nama_status']??'-') ?></span></td>
            <td><?= $p['total_harga'] ? rupiah((float)$p['total_harga']) : '-' ?></td>
            <td><?= date('d M Y', strtotime($p['tanggal_pesanan'])) ?></td>
            <td>
              <button class="btn btn-sm btn-info rounded-pill text-white" onclick="updateStatus('<?= $p['id_pesanan'] ?>','<?= $p['id_status'] ?>')">
                <i class="bi bi-arrow-repeat"></i>
              </button>
              <button class="btn btn-sm btn-danger rounded-pill" onclick="hapus('<?= $p['id_pesanan'] ?>')"><i class="bi bi-trash"></i></button>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div></div>
</div></div>

<!-- Modal Update Status -->
<div class="modal fade" id="modalStatus" tabindex="-1">
  <div class="modal-dialog"><div class="modal-content rounded-4">
    <form method="POST">
      <input type="hidden" name="action" value="update_status"/>
      <input type="hidden" name="id_pesanan" id="statusPesananId"/>
      <div class="modal-header"><h5 class="modal-title">Update Status Pesanan</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <label class="form-label">Status Baru</label>
        <select name="id_status" id="statusSelect" class="form-select">
          <?php foreach ($statusList as $s): ?>
            <option value="<?= $s['id_status'] ?>"><?= htmlspecialchars($s['nama_status']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button><button type="submit" class="btn btn-primary">Update</button></div>
    </form>
  </div></div>
</div>

<form method="POST" id="fHapus" style="display:none"><input type="hidden" name="action" value="hapus"/><input type="hidden" name="id" id="hId"/></form>

<?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
<script>
function updateStatus(id, curStatus) {
  document.getElementById('statusPesananId').value = id;
  document.getElementById('statusSelect').value    = curStatus;
  new bootstrap.Modal(document.getElementById('modalStatus')).show();
}
function hapus(id) {
  Swal.fire({title:'Hapus pesanan ini?',text:'Semua data terkait akan ikut terhapus.',icon:'warning',showCancelButton:true,confirmButtonText:'Hapus',confirmButtonColor:'#ef4444'})
  .then(r => { if(r.isConfirmed) { document.getElementById('hId').value=id; document.getElementById('fHapus').submit(); }});
}
</script>
</body></html>
