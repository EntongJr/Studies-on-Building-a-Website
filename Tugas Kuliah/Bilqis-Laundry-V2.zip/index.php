<?php
// =============================================
//  BERANDA – Bilqis Laundry
// =============================================

require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/middleware/auth.php';

$pageTitle = 'Beranda';
$activeNav = 'beranda';

// Ambil jumlah pelanggan & layanan dari DB untuk ditampilkan di stats
try {
  $db = getDB();
  $jumlahPelanggan = $db->query("SELECT COUNT(*) FROM pelanggan")->fetchColumn();
  $jumlahLayanan   = $db->query("SELECT COUNT(*) FROM layanan")->fetchColumn();
  $jumlahPesanan   = $db->query("SELECT COUNT(*) FROM pesanan")->fetchColumn();
} catch (Exception $e) {
  $jumlahPelanggan = '500+';
  $jumlahLayanan   = '5+';
  $jumlahPesanan   = '0';
}

// Ambil promo aktif
try {
  $promoAktif = $db->query("SELECT * FROM promo ORDER BY id_promo DESC LIMIT 1")->fetch();
} catch (Exception $e) {
  $promoAktif = null;
}

include __DIR__ . '/includes/header.php';
?>

<!-- HERO -->
<section class="hero-section">
  <div class="container py-5">
    <div class="row align-items-center g-5">
      <div class="col-lg-6">
        <span class="hero-badge"><i class="bi bi-star-fill me-1"></i> #1 Laundry Terpercaya di Sidoarjo</span>
        <h1 class="hero-title">Cucian <span class="highlight">Bersih,</span><br>Wangi, <span class="highlight">&amp; Rapi</span></h1>
        <p class="hero-desc">Layanan laundry profesional dengan teknologi modern. Pakaian Anda terawat sempurna, siap pakai kapan saja. Melayani seluruh area Kecamatan Sidoarjo.</p>
        <div class="d-flex flex-wrap gap-3">
          <a href="<?= isLoggedIn() ? BASE_URL . '/pelanggan/pesanan_baru.php' : BASE_URL . '/auth/login.php' ?>" class="btn-primary-sky" style="position:relative;z-index:10;"><i class="bi bi-cart-plus"></i> Pesan Sekarang</a>
          <a href="<?= BASE_URL ?>/pages/layanan.php" class="btn-outline-sky"><i class="bi bi-tags"></i> Lihat Harga</a>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="hero-illustration">
          <div class="circle-bg">
            <i class="bi bi-basket2-fill main-icon"></i>
            <div class="float-badge b1">
              <div class="dot"></div> Layanan Aktif
            </div>
            <div class="float-badge b2"><i class="bi bi-star-fill text-warning me-1"></i> 4.9 Rating</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- STATS -->
<section class="stats-section">
  <div class="container">
    <div class="row g-4">
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-number"><?= $jumlahPelanggan > 0 ? $jumlahPelanggan . '+' : '500+' ?></div>
          <div class="stat-label">Pelanggan Puas</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-number"><?= $jumlahLayanan > 0 ? $jumlahLayanan : '5+' ?></div>
          <div class="stat-label">Jenis Layanan</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-number">3 Thn</div>
          <div class="stat-label">Pengalaman</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-number">24 Jam</div>
          <div class="stat-label">Proses Cepat</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- WHY CHOOSE US -->
<section class="why-section">
  <div class="container">
    <div class="text-center mb-5">
      <div class="section-tag">Keunggulan Kami</div>
      <h2 class="section-title">Mengapa Memilih Bilqis Laundry?</h2>
      <p class="text-muted" style="max-width:520px;margin:0 auto;">Kami berkomitmen memberikan hasil terbaik dengan harga yang terjangkau untuk setiap pelanggan setia kami.</p>
    </div>
    <div class="row g-4">
      <div class="col-md-6 col-lg-3">
        <div class="feature-card">
          <div class="feature-icon"><i class="bi bi-droplet-fill"></i></div>
          <div class="feature-title">Cuci Bersih Sempurna</div>
          <div class="feature-desc">Menggunakan deterjen premium ramah lingkungan untuk hasil cuci yang bersih dan bebas noda.</div>
        </div>
      </div>
      <div class="col-md-6 col-lg-3">
        <div class="feature-card">
          <div class="feature-icon"><i class="bi bi-flower3"></i></div>
          <div class="feature-title">Wangi Tahan Lama</div>
          <div class="feature-desc">Pewangi pilihan yang lembut dan tahan lama membuat pakaian Anda segar sepanjang hari.</div>
        </div>
      </div>
      <div class="col-md-6 col-lg-3">
        <div class="feature-card">
          <div class="feature-icon"><i class="bi bi-lightning-charge-fill"></i></div>
          <div class="feature-title">Pengerjaan Cepat</div>
          <div class="feature-desc">Proses laundry diselesaikan dalam 24 jam. Layanan express juga tersedia untuk kebutuhan mendesak.</div>
        </div>
      </div>
      <div class="col-md-6 col-lg-3">
        <div class="feature-card">
          <div class="feature-icon"><i class="bi bi-shield-check-fill"></i></div>
          <div class="feature-title">Aman &amp; Terpercaya</div>
          <div class="feature-desc">Pakaian Anda dirawat dengan penuh tanggung jawab. Garansi kepuasan pelanggan di setiap layanan.</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- PROMO CTA -->
<section class="promo-section">
  <div class="container">
    <div class="promo-card">
      <div class="row align-items-center g-4">
        <div class="col-lg-8">
          <?php if ($promoAktif): ?>
            <h3><?= clean($promoAktif['nama_promo'] ?? 'Siap Cuci Hari Ini? 🧺') ?></h3>
            <p><?= clean($promoAktif['deskripsi'] ?? 'Antar pakaian Anda atau hubungi kami via WhatsApp untuk penjemputan.') ?></p>
          <?php else: ?>
            <h3>Siap Cuci Hari Ini? 🧺</h3>
            <p>Antar pakaian Anda atau hubungi kami via WhatsApp untuk penjemputan. Proses mudah, hasil memuaskan!</p>
          <?php endif; ?>
        </div>
        <div class="col-lg-4 text-lg-end">
          <a href="<?= isLoggedIn() ? BASE_URL . '/pelanggan/pesanan_baru.php' : BASE_URL . '/auth/login.php' ?>" class="btn-white"><i class="bi bi-cart-plus"></i> Buat Pesanan</a>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>