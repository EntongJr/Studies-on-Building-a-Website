<?php
// =============================================
//  API: DAFTAR PESANAN
//  GET  /bilqis_laundry/api/get_pesanan.php
//  GET  ?search=... untuk filter
//  DELETE + body {id_pesanan} untuk hapus
// =============================================

require_once __DIR__ . '/../includes/functions.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $search = trim($_GET['search'] ?? '');
    try {
        $db = getDB();
        $sql = "
            SELECT
                p.id_pesanan,
                pl.nama_pelanggan,
                pl.no_wa,
                l.nama_layanan,
                p.berat_kg,
                p.berat_dihitung,
                p.harga_per_kg,
                p.total_harga,
                sp.nama_status AS status,
                DATE_FORMAT(p.tanggal_pesanan, '%d %M %Y %H:%i') AS tanggal
            FROM pesanan p
            JOIN pelanggan    pl ON p.id_pelanggan = pl.id_pelanggan
            JOIN layanan       l ON p.id_layanan   = l.id_layanan
            JOIN status_pesanan sp ON p.id_status  = sp.id_status
        ";
        $params = [];
        if ($search) {
            $sql .= " WHERE pl.nama_pelanggan LIKE ? OR l.nama_layanan LIKE ? OR sp.nama_status LIKE ?";
            $like = "%{$search}%";
            $params = [$like, $like, $like];
        }
        $sql .= " ORDER BY p.tanggal_pesanan DESC";

        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        // Hitung stats
        $stats = $db->query("
            SELECT sp.nama_status, COUNT(*) as jumlah
            FROM pesanan p
            JOIN status_pesanan sp ON p.id_status = sp.id_status
            GROUP BY sp.id_status, sp.nama_status
        ")->fetchAll();

        jsonResponse(['status' => 'success', 'data' => $rows, 'stats' => $stats]);

    } catch (Exception $e) {
        jsonResponse(['status' => 'error', 'message' => $e->getMessage()], 500);
    }

} elseif ($method === 'DELETE') {
    $input = json_decode(file_get_contents('php://input'), true);
    $idPesanan = (int)($input['id_pesanan'] ?? 0);
    if (!$idPesanan) jsonResponse(['status' => 'error', 'message' => 'id_pesanan tidak valid.'], 422);

    try {
        $db = getDB();
        $db->prepare("DELETE FROM detail_pesanan WHERE id_pesanan = ?")->execute([$idPesanan]);
        $db->prepare("DELETE FROM pesanan        WHERE id_pesanan = ?")->execute([$idPesanan]);
        jsonResponse(['status' => 'success', 'message' => 'Pesanan berhasil dihapus.']);
    } catch (Exception $e) {
        jsonResponse(['status' => 'error', 'message' => $e->getMessage()], 500);
    }

} else {
    jsonResponse(['status' => 'error', 'message' => 'Method tidak diizinkan.'], 405);
}
