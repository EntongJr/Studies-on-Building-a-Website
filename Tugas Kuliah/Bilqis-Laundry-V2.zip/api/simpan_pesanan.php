<?php
// =============================================
//  API: SIMPAN PESANAN
//  POST /bilqis_laundry/api/simpan_pesanan.php
//  Body (JSON): nama_pelanggan, no_wa, id_layanan, berat_kg
// =============================================

require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['status' => 'error', 'message' => 'Method tidak diizinkan.'], 405);
}

// ── Terima input ──────────────────────────────
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    // fallback form POST
    $input = $_POST;
}

$nama       = trim($input['nama_pelanggan'] ?? '');
$noWa       = trim($input['no_wa'] ?? '');
$idLayanan  = (int)($input['id_layanan'] ?? 0);
$beratKg    = (float)($input['berat_kg'] ?? 0);

// ── Validasi ──────────────────────────────────
$errors = [];
if (!$nama)       $errors[] = 'Nama pelanggan wajib diisi.';
if (!$noWa)       $errors[] = 'No. WhatsApp wajib diisi.';
if (!$idLayanan)  $errors[] = 'Pilih jenis layanan.';
if ($beratKg <= 0) $errors[] = 'Berat pakaian harus lebih dari 0 kg.';

if ($errors) {
    jsonResponse(['status' => 'error', 'message' => implode(' ', $errors)], 422);
}

try {
    $db = getDB();

    // ── Cari / buat pelanggan ──────────────────
    $stmt = $db->prepare("SELECT id_pelanggan FROM pelanggan WHERE no_wa = ? LIMIT 1");
    $stmt->execute([$noWa]);
    $pelanggan = $stmt->fetch();

    if ($pelanggan) {
        $idPelanggan = $pelanggan['id_pelanggan'];
    } else {
        $ins = $db->prepare("INSERT INTO pelanggan (nama_pelanggan, no_wa) VALUES (?, ?)");
        $ins->execute([$nama, $noWa]);
        $idPelanggan = $db->lastInsertId();
    }

    // ── Ambil data layanan ─────────────────────
    $lay = $db->prepare("SELECT * FROM layanan WHERE id_layanan = ?");
    $lay->execute([$idLayanan]);
    $layanan = $lay->fetch();

    if (!$layanan) {
        jsonResponse(['status' => 'error', 'message' => 'Layanan tidak ditemukan.'], 404);
    }

    $hargaPerKg  = (float)$layanan['harga'];
    $beratMin    = (float)($layanan['berat_minimum'] ?? 1);
    $beratFinal  = max($beratKg, $beratMin);
    $totalHarga  = $beratFinal * $hargaPerKg;

    // ── Ambil id_status "Menunggu" ─────────────
    $stmtStatus = $db->prepare("SELECT id_status FROM status_pesanan WHERE nama_status = 'Menunggu' LIMIT 1");
    $stmtStatus->execute();
    $statusRow = $stmtStatus->fetch();
    $idStatus = $statusRow ? $statusRow['id_status'] : 1;

    // ── Simpan pesanan ─────────────────────────
    $sqlPesanan = "
        INSERT INTO pesanan
            (id_pelanggan, id_layanan, berat_kg, berat_dihitung, harga_per_kg, total_harga, id_status, tanggal_pesanan)
        VALUES
            (?, ?, ?, ?, ?, ?, ?, NOW())
    ";
    $insPes = $db->prepare($sqlPesanan);
    $insPes->execute([$idPelanggan, $idLayanan, $beratKg, $beratFinal, $hargaPerKg, $totalHarga, $idStatus]);
    $idPesanan = $db->lastInsertId();

    // ── Simpan detail pesanan ──────────────────
    $sqlDetail = "
        INSERT INTO detail_pesanan
            (id_pesanan, id_layanan, berat_kg, harga_per_kg, subtotal)
        VALUES
            (?, ?, ?, ?, ?)
    ";
    $insDetail = $db->prepare($sqlDetail);
    $insDetail->execute([$idPesanan, $idLayanan, $beratFinal, $hargaPerKg, $totalHarga]);

    jsonResponse([
        'status'     => 'success',
        'message'    => "Pesanan {$nama} berhasil disimpan!",
        'id_pesanan' => $idPesanan,
        'total'      => rupiah($totalHarga),
    ]);

} catch (PDOException $e) {
    jsonResponse(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()], 500);
}
