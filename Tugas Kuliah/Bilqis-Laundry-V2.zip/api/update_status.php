<?php
// =============================================
//  API: UPDATE STATUS PESANAN
//  PATCH /bilqis_laundry/api/update_status.php
//  Body (JSON): { id_pesanan, id_status }
// =============================================

require_once __DIR__ . '/../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'PATCH' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['status' => 'error', 'message' => 'Method tidak diizinkan.'], 405);
}

$input     = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$idPesanan = (int)($input['id_pesanan'] ?? 0);
$idStatus  = (int)($input['id_status']  ?? 0);

if (!$idPesanan || !$idStatus) {
    jsonResponse(['status' => 'error', 'message' => 'id_pesanan dan id_status wajib diisi.'], 422);
}

try {
    $db = getDB();
    $stmt = $db->prepare("UPDATE pesanan SET id_status = ? WHERE id_pesanan = ?");
    $stmt->execute([$idStatus, $idPesanan]);

    $status = $db->prepare("SELECT nama_status FROM status_pesanan WHERE id_status = ?");
    $status->execute([$idStatus]);
    $namaStatus = $status->fetchColumn();

    jsonResponse(['status' => 'success', 'message' => 'Status berhasil diperbarui.', 'nama_status' => $namaStatus]);
} catch (Exception $e) {
    jsonResponse(['status' => 'error', 'message' => $e->getMessage()], 500);
}
