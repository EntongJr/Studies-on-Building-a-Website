<?php
// =============================================
//  API: DAFTAR LAYANAN (untuk JS dropdown)
//  GET /bilqis_laundry/api/get_layanan.php
// =============================================

require_once __DIR__ . '/../includes/functions.php';

try {
    $db = getDB();
    $layanan = $db->query("SELECT id_layanan, nama_layanan, harga, berat_minimum FROM layanan ORDER BY id_layanan")->fetchAll();
    jsonResponse(['status' => 'success', 'data' => $layanan]);
} catch (Exception $e) {
    jsonResponse(['status' => 'error', 'message' => $e->getMessage()], 500);
}
