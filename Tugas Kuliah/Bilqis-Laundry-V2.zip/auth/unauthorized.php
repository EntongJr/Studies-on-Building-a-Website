<?php
require_once __DIR__ . '/../includes/config.php';
http_response_code(403);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Akses Ditolak – <?= SITE_NAME ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet"/>
  <style>body{font-family:'Poppins',sans-serif;background:#f0f9ff;display:flex;align-items:center;min-height:100vh;}</style>
</head>
<body>
<div class="container text-center py-5">
  <div style="font-size:5rem;color:#ef4444"><i class="bi bi-shield-x"></i></div>
  <h2 class="mt-3 fw-700">Akses Ditolak</h2>
  <p class="text-muted">Anda tidak memiliki izin untuk mengakses halaman ini.</p>
  <a href="<?= BASE_URL ?>/index.php" class="btn btn-primary rounded-pill px-4">Kembali ke Beranda</a>
</div>
</body>
</html>
