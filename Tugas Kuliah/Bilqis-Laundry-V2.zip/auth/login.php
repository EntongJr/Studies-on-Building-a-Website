<?php
// =============================================
//  HALAMAN LOGIN – Bilqis Laundry
// =============================================

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../middleware/auth.php';

// Jika sudah login, redirect ke dashboard sesuai role
if (isLoggedIn()) {
  redirectByRole(currentRole());
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email    = trim($_POST['email'] ?? '');
  $sandi    = $_POST['sandi'] ?? '';
  $remember = isset($_POST['remember']);

  if (empty($email) || empty($sandi)) {
    $error = 'Email dan password wajib diisi.';
  } else {
    $db = getDB();

    // Cek pelanggan
    $stmt = $db->prepare("SELECT * FROM pelanggan WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($sandi, $user['sandi'])) {
      setSession($user['id_pelanggan'], $user['nama_pelanggan'], $user['email'], ROLE_PELANGGAN, $remember);
      $redirect = $_SESSION['redirect_after_login'] ?? BASE_URL . '/pelanggan/dashboard.php';
      unset($_SESSION['redirect_after_login']);
      header('Location: ' . $redirect);
      exit;
    }

    // Cek petugas
    $stmt = $db->prepare("
            SELECT p.*, j.nama_jabatan
            FROM petugas p
            JOIN jabatan j ON p.id_jabatan = j.id_jabatan
            WHERE p.email = ?
            LIMIT 1
        ");
    $stmt->execute([$email]);
    $petugas = $stmt->fetch();

    if ($petugas && password_verify($sandi, $petugas['sandi'])) {
      $role = (strtolower($petugas['nama_jabatan']) === 'admin') ? ROLE_ADMIN : ROLE_PETUGAS;
      setSession($petugas['id_petugas'], $petugas['nama_petugas'], $petugas['email'], $role, $remember);
      $redirect = $_SESSION['redirect_after_login'] ?? ($role === ROLE_ADMIN
        ? BASE_URL . '/admin/dashboard.php'
        : BASE_URL . '/petugas/dashboard.php');
      unset($_SESSION['redirect_after_login']);
      header('Location: ' . $redirect);
      exit;
    }

    $error = 'Email atau password salah.';
  }
}

function setSession(string $id, string $nama, string $email, string $role, bool $remember): void
{
  $_SESSION['user_id']    = $id;
  $_SESSION['user_nama']  = $nama;
  $_SESSION['user_email'] = $email;
  $_SESSION['role']       = $role;
  if ($remember) {
    session_set_cookie_params(['lifetime' => 86400 * 30]);
    session_regenerate_id(true);
  }
}

function redirectByRole(string $role): void
{
  $map = [
    ROLE_ADMIN      => BASE_URL . '/admin/dashboard.php',
    ROLE_PETUGAS    => BASE_URL . '/petugas/dashboard.php',
    ROLE_PELANGGAN  => BASE_URL . '/pelanggan/dashboard.php',
  ];
  header('Location: ' . ($map[$role] ?? BASE_URL . '/index.php'));
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login – <?= SITE_NAME ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet" />
  <style>
    :root {
      --sky: #0ea5e9;
      --sky-dark: #0284c7;
      --sky-light: #e0f2fe;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #e0f2fe 0%, #f0f9ff 50%, #e0f2fe 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
    }

    .login-card {
      background: #fff;
      border-radius: 20px;
      box-shadow: 0 20px 60px rgba(14, 165, 233, .15);
      overflow: hidden;
      max-width: 420px;
      width: 100%;
      margin: 0 auto;
    }

    .login-header {
      background: linear-gradient(135deg, var(--sky), var(--sky-dark));
      color: #fff;
      padding: 2rem;
      text-align: center;
    }

    .login-header .brand-icon {
      font-size: 2.5rem;
      margin-bottom: .5rem;
    }

    .login-header h4 {
      font-weight: 700;
      margin: 0;
    }

    .login-header p {
      font-size: .85rem;
      opacity: .85;
      margin: .25rem 0 0;
    }

    .login-body {
      padding: 2rem;
    }

    .form-label {
      font-weight: 500;
      font-size: .9rem;
      color: #374151;
    }

    .form-control {
      border-radius: 10px;
      border: 1.5px solid #e5e7eb;
      padding: .65rem 1rem;
      font-size: .9rem;
      transition: border .2s;
    }

    .form-control:focus {
      border-color: var(--sky);
      box-shadow: 0 0 0 3px rgba(14, 165, 233, .15);
    }

    .input-group-text {
      border-radius: 10px 0 0 10px;
      background: var(--sky-light);
      border: 1.5px solid #e5e7eb;
      color: var(--sky-dark);
    }

    .input-group .form-control {
      border-radius: 0 10px 10px 0;
    }

    .btn-login {
      background: linear-gradient(135deg, var(--sky), var(--sky-dark));
      color: #fff;
      border: none;
      border-radius: 10px;
      padding: .75rem;
      font-weight: 600;
      font-size: 1rem;
      width: 100%;
      transition: opacity .2s;
    }

    .btn-login:hover {
      opacity: .9;
      color: #fff;
    }

    .back-link {
      text-align: center;
      margin-top: 1rem;
      font-size: .85rem;
    }

    .back-link a {
      color: var(--sky-dark);
      text-decoration: none;
      font-weight: 500;
    }

    .alert-danger {
      border-radius: 10px;
      font-size: .88rem;
    }

    .toggle-password {
      cursor: pointer;
    }
  </style>
</head>

<body>
  <div class="container px-3">
    <div class="login-card">
      <div class="login-header">
        <div class="brand-icon"><i class="bi bi-basket2-fill"></i></div>
        <h4>Bilqis Laundry</h4>
        <p>Login Terlebih Dauhulu!!</p>
      </div>
      <div class="login-body">
        <?php if ($error): ?>
          <div class="alert alert-danger py-2"><i class="bi bi-exclamation-circle me-1"></i><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" novalidate>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <div class="input-group">
              <span class="input-group-text"><i class="bi bi-envelope"></i></span>
              <input type="email" name="email" class="form-control" placeholder="email@example.com"
                value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required autofocus />
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label">Password</label>
            <div class="input-group">
              <span class="input-group-text"><i class="bi bi-lock"></i></span>
              <input type="password" name="sandi" id="sandi" class="form-control" placeholder="••••••••" required />
              <span class="input-group-text toggle-password" onclick="togglePass()">
                <i class="bi bi-eye" id="eyeIcon"></i>
              </span>
            </div>
          </div>
          <div class="mb-4 d-flex align-items-center justify-content-between">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" name="remember" id="remember" />
              <label class="form-check-label" for="remember" style="font-size:.85rem">Ingat saya</label>
            </div>
          </div>
          <button type="submit" class="btn-login"><i class="bi bi-box-arrow-in-right me-1"></i>Masuk</button>
        </form>
        <div class="back-link mt-3">
          <a href="<?= BASE_URL ?>/index.php"><i class="bi bi-arrow-left me-1"></i>Kembali ke Beranda</a>
        </div>
        <div class="back-link">
          Belum punya akun? <a href="<?= BASE_URL ?>/auth/register.php">Daftar di sini</a>
        </div>
      </div>
    </div>
  </div>
  <script>
    function togglePass() {
      const f = document.getElementById('sandi');
      const i = document.getElementById('eyeIcon');
      if (f.type === 'password') {
        f.type = 'text';
        i.className = 'bi bi-eye-slash';
      } else {
        f.type = 'password';
        i.className = 'bi bi-eye';
      }
    }
  </script>
</body>

</html>