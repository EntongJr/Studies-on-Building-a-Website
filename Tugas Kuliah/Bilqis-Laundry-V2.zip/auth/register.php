<?php
// =============================================
//  HALAMAN REGISTER PELANGGAN
// =============================================

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../middleware/auth.php';

if (isLoggedIn()) {
  header('Location: ' . BASE_URL . '/index.php');
  exit;
}

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nama    = trim($_POST['nama'] ?? '');
  $email   = trim($_POST['email'] ?? '');
  $no_hp   = trim($_POST['no_telepon'] ?? '');
  $alamat  = trim($_POST['alamat'] ?? '');
  $sandi   = $_POST['sandi'] ?? '';
  $konfirm = $_POST['konfirm'] ?? '';

  if (!$nama || !$email || !$sandi) {
    $error = 'Nama, email, dan password wajib diisi.';
  } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $error = 'Format email tidak valid.';
  } elseif (strlen($sandi) < 6) {
    $error = 'Password minimal 6 karakter.';
  } elseif ($sandi !== $konfirm) {
    $error = 'Konfirmasi password tidak cocok.';
  } else {
    $db = getDB();
    $cek = $db->prepare("SELECT id_pelanggan FROM pelanggan WHERE email = ?");
    $cek->execute([$email]);
    if ($cek->fetch()) {
      $error = 'Email sudah terdaftar.';
    } else {
      $last = $db->query("SELECT id_pelanggan FROM pelanggan ORDER BY id_pelanggan DESC LIMIT 1")->fetchColumn();
      $num  = $last ? (int)substr($last, 3) + 1 : 1;
      $id   = 'PLG' . str_pad($num, 3, '0', STR_PAD_LEFT);

      $hash = password_hash($sandi, PASSWORD_DEFAULT);
      $ins  = $db->prepare("INSERT INTO pelanggan (id_pelanggan,nama_pelanggan,email,sandi,no_telepon,alamat) VALUES (?,?,?,?,?,?)");
      $ins->execute([$id, $nama, $email, $hash, $no_hp, $alamat]);
      $success = 'Akun berhasil dibuat! Silakan <a href="' . BASE_URL . '/auth/login.php">login</a>.';
    }
  }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Daftar – <?= SITE_NAME ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet" />
  <style>
    :root {
      --sky: #0ea5e9;
      --sky-dark: #0284c7;
      --sky-light: #e0f2fe;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #e0f2fe, #f0f9ff, #e0f2fe);
      min-height: 100vh;
      display: flex;
      align-items: center;
      padding: 2rem 0;
    }

    .reg-card {
      background: #fff;
      border-radius: 20px;
      box-shadow: 0 20px 60px rgba(14, 165, 233, .15);
      max-width: 460px;
      width: 100%;
      margin: 0 auto;
      overflow: hidden;
    }

    .reg-header {
      background: linear-gradient(135deg, var(--sky), var(--sky-dark));
      color: #fff;
      padding: 1.5rem 2rem;
      text-align: center;
    }

    .reg-body {
      padding: 2rem;
    }

    .form-control {
      border-radius: 10px;
      border: 1.5px solid #e5e7eb;
    }

    .form-control:focus {
      border-color: var(--sky);
      box-shadow: 0 0 0 3px rgba(14, 165, 233, .15);
    }

    .input-group-text {
      background: var(--sky-light);
      border: 1.5px solid #e5e7eb;
      color: var(--sky-dark);
      border-radius: 10px 0 0 10px;
    }

    .input-group .form-control {
      border-radius: 0 10px 10px 0;
    }

    .btn-daftar {
      background: linear-gradient(135deg, var(--sky), var(--sky-dark));
      color: #fff;
      border: none;
      border-radius: 10px;
      padding: .75rem;
      font-weight: 600;
      width: 100%;
    }

    .btn-daftar:hover {
      opacity: .9;
      color: #fff;
    }
  </style>
</head>

<body>
  <div class="container px-3">
    <div class="reg-card">
      <div class="reg-header">
        <i class="bi bi-person-plus-fill" style="font-size:2rem"></i>
        <h5 class="mt-1 mb-0 fw-700">Daftar Akun Pelanggan</h5>
      </div>
      <div class="reg-body">
        <?php if ($error): ?>
          <div class="alert alert-danger py-2 rounded-3"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
          <div class="alert alert-success py-2 rounded-3"><?= $success ?></div>
        <?php else: ?>
          <form method="POST">
            <div class="mb-3">
              <label class="form-label fw-500">Nama Lengkap <span class="text-danger">*</span></label>
              <div class="input-group">
                <span class="input-group-text"><i class="bi bi-person"></i></span>
                <input type="text" name="nama" class="form-control" placeholder="Nama lengkap" value="<?= htmlspecialchars($_POST['nama'] ?? '') ?>" required />
              </div>
            </div>
            <div class="mb-3">
              <label class="form-label fw-500">Email <span class="text-danger">*</span></label>
              <div class="input-group">
                <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                <input type="email" name="email" class="form-control" placeholder="email@example.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required />
              </div>
            </div>
            <div class="mb-3">
              <label class="form-label fw-500">No. Telepon</label>
              <div class="input-group">
                <span class="input-group-text"><i class="bi bi-telephone"></i></span>
                <input type="text" name="no_telepon" class="form-control" placeholder="08xxxxxxxxxx" value="<?= htmlspecialchars($_POST['no_telepon'] ?? '') ?>" />
              </div>
            </div>
            <div class="mb-3">
              <label class="form-label fw-500">Alamat</label>
              <textarea name="alamat" class="form-control" rows="2" placeholder="Alamat lengkap"><?= htmlspecialchars($_POST['alamat'] ?? '') ?></textarea>
            </div>
            <div class="mb-3">
              <label class="form-label fw-500">Password <span class="text-danger">*</span></label>
              <div class="input-group">
                <span class="input-group-text"><i class="bi bi-lock"></i></span>
                <input type="password" name="sandi" class="form-control" placeholder="Min. 6 karakter" required />
              </div>
            </div>
            <div class="mb-4">
              <label class="form-label fw-500">Konfirmasi Password <span class="text-danger">*</span></label>
              <div class="input-group">
                <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                <input type="password" name="konfirm" class="form-control" placeholder="Ulangi password" required />
              </div>
            </div>
            <button type="submit" class="btn-daftar"><i class="bi bi-person-check me-1"></i>Daftar Sekarang</button>
          </form>
        <?php endif; ?>
        <div class="text-center mt-3" style="font-size:.85rem">
          Sudah punya akun? <a href="<?= BASE_URL ?>/auth/login.php" style="color:var(--sky-dark);font-weight:500">Login di sini</a>
        </div>
      </div>
    </div>
  </div>
</body>

</html>