<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/petugas_only.php';
require_once __DIR__ . '/../includes/functions.php';

$db   = getDB();
$user = currentUser();
$msg  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';

  if ($action === 'update_status') {
    $db->prepare("UPDATE pesanan SET id_status=? WHERE id_pesanan=?")
      ->execute([$_POST['id_status'], $_POST['id_pesanan']]);
    $msg = 'success|Status pesanan berhasil diperbarui.';
  }

  if ($action === 'update_berat_total') {
    $idPesanan   = $_POST['id_pesanan'];
    $beratFinal  = (float)$_POST['berat_final'];
    $totalBaru   = (float)$_POST['total_baru'];

    // Update berat dan total di tabel pesanan
    $db->prepare("UPDATE pesanan SET berat_cucian=?, total_harga=? WHERE id_pesanan=?")
      ->execute([$beratFinal, $totalBaru, $idPesanan]);

    // Update subtotal di detail_pesanan
    $db->prepare("UPDATE detail_pesanan SET subtotal=? WHERE id_pesanan=?")
      ->execute([$totalBaru, $idPesanan]);

    // Update jumlah_bayar di pembayaran jika sudah ada
    $db->prepare("UPDATE pembayaran SET jumlah_bayar=? WHERE id_pesanan=?")
      ->execute([$totalBaru, $idPesanan]);

    $msg = 'success|Berat dan total pembayaran berhasil diperbarui.';
  }
}

$pesanan = $db->query("
    SELECT p.*, pl.nama_pelanggan, pl.no_telepon, sp.nama_status,
          GROUP_CONCAT(DISTINCT l.nama_layanan SEPARATOR ', ') AS layanan_list,
          (SELECT jumlah_bayar FROM pembayaran 
          WHERE id_pesanan = p.id_pesanan LIMIT 1) AS jumlah_bayar,
          (SELECT mp2.nama_metode FROM pembayaran py2
          JOIN metode_pembayaran mp2 ON py2.id_metode = mp2.id_metode
          WHERE py2.id_pesanan = p.id_pesanan LIMIT 1) AS nama_metode
    FROM pesanan p
    JOIN pelanggan pl ON p.id_pelanggan = pl.id_pelanggan
    JOIN status_pesanan sp ON p.id_status = sp.id_status
    LEFT JOIN detail_pesanan dp ON p.id_pesanan = dp.id_pesanan
    LEFT JOIN layanan l ON dp.id_layanan = l.id_layanan
    GROUP BY p.id_pesanan
    ORDER BY p.tanggal_pesanan DESC
")->fetchAll();

$statusList = $db->query("SELECT * FROM status_pesanan ORDER BY id_status")->fetchAll();
[$msgType, $msgText] = $msg ? explode('|', $msg, 2) : ['', ''];
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Daftar Pesanan – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
</head>

<body>

  <div class="sidebar" id="sidebar">
    <div class="sidebar-brand">
      <i class="bi bi-basket2-fill icon"></i>
      <div>Bilqis Laundry<br><small style="font-size:.7rem;font-weight:400;opacity:.7">Panel Petugas</small></div>
    </div>
    <nav class="sidebar-nav">
      <a href="<?= BASE_URL ?>/petugas/dashboard.php"><i class="bi bi-grid-1x2"></i> Dashboard</a>
      <a href="<?= BASE_URL ?>/petugas/pesanan.php" class="active"><i class="bi bi-bag-check"></i> Pesanan</a>
    </nav>
    <div class="sidebar-footer">
      <a href="<?= BASE_URL ?>/auth/logout.php"><i class="bi bi-box-arrow-left"></i> Logout</a>
    </div>
  </div>

  <div class="topbar">
    <button class="btn btn-sm btn-light menu-toggle" id="menuToggle"><i class="bi bi-list fs-5"></i></button>
    <div class="d-flex align-items-center gap-2">
      <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,#0ea5e9,#0284c7);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:600;">
        <?= strtoupper(substr($user['nama'], 0, 1)) ?>
      </div>
      <div style="font-size:.85rem">
        <div class="fw-600"><?= htmlspecialchars($user['nama']) ?></div>
        <div class="text-muted" style="font-size:.75rem">Petugas</div>
      </div>
    </div>
  </div>

  <div class="main-content">
    <div class="page-content">
      <h5 class="fw-700 mb-4">Daftar Semua Pesanan</h5>

      <?php if ($msgText): ?>
        <div class="alert alert-<?= $msgType === 'success' ? 'success' : 'danger' ?> alert-dismissible rounded-3">
          <?= htmlspecialchars($msgText) ?>
          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>

      <div class="card">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table dt-table">
              <thead class="table-light">
                <tr>
                  <th>#</th>
                  <th>ID Pesanan</th>
                  <th>Pelanggan</th>
                  <th>Layanan</th>
                  <th>Berat</th>
                  <th>Total</th>
                  <th>Metode</th>
                  <th>Status</th>
                  <th>Pembayaran</th>
                  <th>Tanggal</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($pesanan as $i => $p):
                  $s = $p['nama_status'];
                  $b = match (true) {
                    str_contains($s, 'Selesai') || str_contains($s, 'Diambil') => 'success',
                    str_contains($s, 'Diproses') || str_contains($s, 'Dicuci') || str_contains($s, 'Setrika') => 'primary',
                    str_contains($s, 'Menunggu') => 'warning',
                    default => 'secondary'
                  };
                  $bayar = $p['status_pembayaran'] ?? 'Belum Lunas';
                ?>
                  <tr>
                    <td><?= $i + 1 ?></td>
                    <td><code><?= htmlspecialchars($p['id_pesanan']) ?></code></td>
                    <td>
                      <div class="fw-600"><?= htmlspecialchars($p['nama_pelanggan']) ?></div>
                    </td>
                    <td><small><?= htmlspecialchars($p['layanan_list'] ?? '-') ?></small></td>
                    <td><?= $p['berat_cucian'] ?? '-' ?> kg</td>
                    <td class="fw-600"><?= $p['total_harga'] ? rupiah((float)$p['total_harga']) : '-' ?></td>
                    <td><small><?= htmlspecialchars($p['nama_metode'] ?? '-') ?></small></td>
                    <td><span class="badge bg-<?= $b ?>"><?= htmlspecialchars($s) ?></span></td>
                    <td><span class="badge bg-<?= $bayar === 'Lunas' ? 'success' : 'danger' ?>"><?= htmlspecialchars($bayar) ?></span></td>
                    <td><?= date('d M Y', strtotime($p['tanggal_pesanan'])) ?></td>
                    <td>
                      <div class="d-flex gap-1">
                        <button class="btn btn-sm btn-primary rounded-pill"
                          onclick="updateStatus('<?= $p['id_pesanan'] ?>','<?= $p['id_status'] ?>')"
                          title="Update Status">
                          <i class="bi bi-arrow-repeat"></i>
                        </button>
                        <button class="btn btn-sm btn-warning rounded-pill"
                          onclick="editBeratTotal('<?= $p['id_pesanan'] ?>',<?= (float)($p['berat_cucian'] ?? 0) ?>,<?= (float)($p['total_harga'] ?? 0) ?>)"
                          title="Edit Berat & Total">
                          <i class="bi bi-pencil"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal Update Status -->
  <div class="modal fade" id="modalStatus" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content rounded-4">
        <form method="POST">
          <input type="hidden" name="action" value="update_status" />
          <input type="hidden" name="id_pesanan" id="statusId" />
          <div class="modal-header">
            <h5 class="modal-title">Update Status Pesanan</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <label class="form-label fw-600">Status Baru</label>
            <select name="id_status" id="statusSel" class="form-select form-select-lg">
              <?php foreach ($statusList as $s): ?>
                <option value="<?= $s['id_status'] ?>"><?= htmlspecialchars($s['nama_status']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-primary rounded-pill px-4">
              <i class="bi bi-check-lg me-1"></i>Update Status
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Modal Edit Berat & Total -->
  <div class="modal fade" id="modalBeratTotal" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content rounded-4">
        <form method="POST">
          <input type="hidden" name="action" value="update_berat_total" />
          <input type="hidden" name="id_pesanan" id="btId" />
          <div class="modal-header">
            <h5 class="modal-title"><i class="bi bi-pencil me-2"></i>Edit Berat & Total Pembayaran</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="alert alert-info rounded-3" style="font-size:.85rem">
              <i class="bi bi-info-circle me-1"></i>
              Perubahan ini akan memperbarui berat, total pesanan, dan jumlah pembayaran secara otomatis.
            </div>
            <div class="mb-3">
              <label class="form-label fw-600">Berat Final (kg)</label>
              <div class="input-group">
                <input type="number" name="berat_final" id="btBerat"
                  class="form-control" step="0.1" min="0.1" required />
                <span class="input-group-text">kg</span>
              </div>
            </div>
            <div class="mb-3">
              <label class="form-label fw-600">Total Pembayaran (Rp)</label>
              <div class="input-group">
                <span class="input-group-text">Rp</span>
                <input type="number" name="total_baru" id="btTotal"
                  class="form-control" step="1000" min="0" required />
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-warning rounded-pill px-4">
              <i class="bi bi-save me-1"></i>Simpan Perubahan
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
  <script>
    function updateStatus(id, curId) {
      document.getElementById('statusId').value = id;
      document.getElementById('statusSel').value = curId;
      new bootstrap.Modal(document.getElementById('modalStatus')).show();
    }

    function editBeratTotal(id, berat, total) {
      document.getElementById('btId').value = id;
      document.getElementById('btBerat').value = berat;
      document.getElementById('btTotal').value = total;
      new bootstrap.Modal(document.getElementById('modalBeratTotal')).show();
    }
  </script>
</body>

</html>