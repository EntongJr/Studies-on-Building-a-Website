<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../middleware/petugas_only.php';
require_once __DIR__ . '/../includes/functions.php';

$db   = getDB();
$user = currentUser();
$activeNav = 'dashboard';

$totalPesanan   = $db->query("SELECT COUNT(*) FROM pesanan")->fetchColumn();
$pesananProses  = $db->query("SELECT COUNT(*) FROM pesanan p JOIN status_pesanan s ON p.id_status=s.id_status WHERE s.nama_status NOT IN ('Selesai','Sudah Diambil')")->fetchColumn();
$pesananSelesai = $db->query("SELECT COUNT(*) FROM pesanan p JOIN status_pesanan s ON p.id_status=s.id_status WHERE s.nama_status IN ('Selesai','Sudah Diambil')")->fetchColumn();

$pesanan = $db->query("
    SELECT p.*, pl.nama_pelanggan, pl.no_telepon, sp.nama_status
    FROM pesanan p
    JOIN pelanggan pl ON p.id_pelanggan = pl.id_pelanggan
    JOIN status_pesanan sp ON p.id_status = sp.id_status
    ORDER BY p.tanggal_pesanan DESC
    LIMIT 20
")->fetchAll();

$statusList = $db->query("SELECT * FROM status_pesanan ORDER BY id_status")->fetchAll();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_status') {
  $db->prepare("UPDATE pesanan SET id_status=? WHERE id_pesanan=?")
    ->execute([$_POST['id_status'], $_POST['id_pesanan']]);
  header('Location: ' . BASE_URL . '/petugas/dashboard.php?updated=1');
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Dashboard Petugas – Bilqis Laundry</title>
  <?php include __DIR__ . '/../partials/dashboard_head.php'; ?>
</head>

<body>

  <div class="sidebar" id="sidebar">
    <div class="sidebar-brand">
      <i class="bi bi-basket2-fill icon"></i>
      <div>Bilqis Laundry<br><small style="font-size:.7rem;font-weight:400;opacity:.7">Panel Petugas</small></div>
    </div>
    <nav class="sidebar-nav">
      <a href="<?= BASE_URL ?>/petugas/dashboard.php" class="active"><i class="bi bi-grid-1x2"></i> Dashboard</a>
      <a href="<?= BASE_URL ?>/petugas/pesanan.php"><i class="bi bi-bag-check"></i> Pesanan</a>
    </nav>
    <div class="sidebar-footer">
      <a href="<?= BASE_URL ?>/auth/logout.php"><i class="bi bi-box-arrow-left"></i> Logout</a>
    </div>
  </div>

  <div class="topbar">
    <button class="btn btn-sm btn-light menu-toggle" id="menuToggle"><i class="bi bi-list fs-5"></i></button>
    <div class="d-flex align-items-center gap-2">
      <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,#0ea5e9,#0284c7);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:600;">
        <?= strtoupper(substr($user['nama'], 0, 1)) ?>
      </div>
      <div style="font-size:.85rem">
        <div class="fw-600"><?= htmlspecialchars($user['nama']) ?></div>
        <div class="text-muted" style="font-size:.75rem">Petugas Laundry</div>
      </div>
    </div>
  </div>

  <div class="main-content">
    <div class="page-content">
      <h5 class="fw-700 mb-1">Dashboard Petugas</h5>
      <p class="text-muted mb-4" style="font-size:.85rem">Selamat datang, <?= htmlspecialchars($user['nama']) ?>!</p>

      <?php if (isset($_GET['updated'])): ?>
        <div class="alert alert-success rounded-3">Status pesanan berhasil diperbarui.</div>
      <?php endif; ?>

      <div class="row g-3 mb-4">
        <div class="col-4">
          <div class="stat-card text-center">
            <div class="stat-val"><?= $totalPesanan ?></div>
            <div class="stat-lbl">Total Pesanan</div>
          </div>
        </div>
        <div class="col-4">
          <div class="stat-card text-center">
            <div class="stat-val text-warning"><?= $pesananProses ?></div>
            <div class="stat-lbl">Dalam Proses</div>
          </div>
        </div>
        <div class="col-4">
          <div class="stat-card text-center">
            <div class="stat-val text-success"><?= $pesananSelesai ?></div>
            <div class="stat-lbl">Selesai</div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h6 class="mb-0 fw-600">Pesanan Terbaru</h6>
        </div>
        <div class="card-body p-0">
          <div class="table-responsive">
            <table class="table table-hover mb-0">
              <thead class="table-light">
                <tr>
                  <th>ID</th>
                  <th>Pelanggan</th>
                  <th>Telp</th>
                  <th>Status</th>
                  <th>Berat</th>
                  <th>Tanggal</th>
                  <th>Update</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($pesanan as $p):
                  $s = $p['nama_status'];
                  $b = match (true) {
                    str_contains($s, 'Selesai') || str_contains($s, 'Diambil') => 'success',
                    str_contains($s, 'Diproses') || str_contains($s, 'Dicuci') => 'primary',
                    str_contains($s, 'Menunggu') => 'warning',
                    default => 'secondary'
                  };
                ?>
                  <tr>
                    <td><code><?= htmlspecialchars($p['id_pesanan']) ?></code></td>
                    <td><?= htmlspecialchars($p['nama_pelanggan']) ?></td>
                    <td><?= htmlspecialchars($p['no_telepon'] ?? '-') ?></td>
                    <td><span class="badge bg-<?= $b ?>"><?= htmlspecialchars($s) ?></span></td>
                    <td><?= $p['berat_cucian'] ?? '-' ?> kg</td>
                    <td><?= date('d M', strtotime($p['tanggal_pesanan'])) ?></td>
                    <td>
                      <button class="btn btn-sm btn-outline-primary rounded-pill"
                        onclick="setStatus('<?= $p['id_pesanan'] ?>','<?= $p['id_status'] ?>')">
                        <i class="bi bi-arrow-repeat"></i>
                      </button>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal Update Status -->
  <div class="modal fade" id="modalStatus" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content rounded-4">
        <form method="POST">
          <input type="hidden" name="action" value="update_status" />
          <input type="hidden" name="id_pesanan" id="statusId" />
          <div class="modal-header">
            <h5 class="modal-title">Update Status Pesanan</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <select name="id_status" id="statusSel" class="form-select">
              <?php foreach ($statusList as $s): ?>
                <option value="<?= $s['id_status'] ?>"><?= htmlspecialchars($s['nama_status']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button><button type="submit" class="btn btn-primary">Update</button></div>
        </form>
      </div>
    </div>
  </div>

  <?php include __DIR__ . '/../partials/dashboard_scripts.php'; ?>
  <script>
    function setStatus(id, curId) {
      document.getElementById('statusId').value = id;
      document.getElementById('statusSel').value = curId;
      new bootstrap.Modal(document.getElementById('modalStatus')).show();
    }
  </script>
</body>

</html>